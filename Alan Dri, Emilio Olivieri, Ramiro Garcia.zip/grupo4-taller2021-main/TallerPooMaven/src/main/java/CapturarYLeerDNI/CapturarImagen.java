package CapturarYLeerDNI;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamResolution;

import JPanelWebCam.JPanelWebCam;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 */

/**
 *Toma la foto utilizando el archivo jar, JPanelWebCam, el mismo debe ser importado,
 *	 el mismo debe ser importado para el correcto funcionamiento del sistema. 
 */
public class CapturarImagen extends JFrame implements Runnable {
	
	/**
	 * clase obtenida desde el archivo camaraweb.jar
	 */
	private Webcam webcam;
	/**
	 * etiquetra label1
	 */
	private JLabel label1;
	/**
	 * panel lamina
	 */
	private JPanel lamina;
	/**
	 * panel de la camara web
	 */
	private JPanelWebCam panelcamara;
	/**
	 * objeto tipo leerDNI
	 */
	private LeerDNI leerDNI;
	/**
	 * boton boton
	 */
	private JButton boton;
	/**
	 * panel para boton
	 */
	private JPanel laminaBoton;
	
	/**
	 * @param leerDNI
	 * Crea un objeto de tipo CapturarImagen
	 */
	public CapturarImagen(LeerDNI leerDNI) {
		this.leerDNI = leerDNI;
	}
	
	@Override
	public void run() {
		setVisible(true);
		setLocationRelativeTo(null);
		webcam = Webcam.getDefault();
		webcam.setViewSize(WebcamResolution.VGA.getSize());
		panelcamara = new JPanelWebCam();

		webcam.open();
		setExtendedState(MAXIMIZED_BOTH);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		lamina = new JPanel();
		lamina.setLayout(new BorderLayout());

		laminaBoton = new JPanel();
		label1 = new JLabel();
		JButton btn = new JButton("caputar ");

		label1.setSize(300, 233);
		lamina.add(label1, BorderLayout.EAST);
		lamina.add(panelcamara, BorderLayout.CENTER);
		laminaBoton.add(btn, BorderLayout.WEST);
		boton = new JButton("continuar");
		laminaBoton.add(boton, BorderLayout.EAST);
		lamina.add(laminaBoton, BorderLayout.SOUTH);
		add(lamina);

		btn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				webcam.open();
				BufferedImage imagen = webcam.getImage();
				label1.setIcon(new ImageIcon(imagen));
				try {
					ImageIO.write(webcam.getImage(), "PNG", new File("src\\main\\java\\imagenDNI.png"));
				} catch (IOException ex) {
					ex.printStackTrace();
				}
				webcam.close();
				boton.setEnabled(true);
			}
		});
		boton.setEnabled(false);
		boton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Thread hilo_leerDNI = new Thread(leerDNI);
				hilo_leerDNI.start();
				dispose();
			}
		});
	}
	
	/**
	 * @return devuelve un objeto de tipo leerDNI
	 */
	public LeerDNI getLeerDNI() {
		return this.leerDNI;
	}
}