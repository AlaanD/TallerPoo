package CapturarYLeerDNI;

import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import Taller.CamaraElectoral;
import Taller.Elector;
import VentanaModelo.VentanaVotoCamaraV2;
import VentanaModelo.VentanaVotoDiputado;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 */

/**
 * Lee la imagen tomada por la clase CapturaImagen y utilizando Tesseract
 * extrae el dni de la foto y lo compara con el DNI ingresado en el campo de texto.
 */
public class LeerDNI extends JFrame implements Runnable{
	
	/**
	 * entero dni
	 */
	private int dni;
	/**
	 * panel lamina
	 */
	private JPanel lamina;
	/**
	 * boton boton
	 */
	private JButton boton;
	/**
	 * objeto tipo camara electoral llamado padron
	 */
	private CamaraElectoral padron;
	/**
	 * objeto tipo elector llamado elector
	 */
	private Elector elector;
	/**
	 * string campo de texto
	 */
	private String campoTexto;
	
	
	/**
	 * @param padron lista padron electoral
	 * @param elector lista de electores
	 * @param campoTexto string del campo de texto
	 * 
	 * Crea un obejto de tipó LeerDNI
	 */
	public LeerDNI(CamaraElectoral padron ,Optional<Elector> elector, String campoTexto) {
		this.padron = padron;
		this.elector = elector.get();
		this.campoTexto = campoTexto;
	}
	
	@Override
	public void run() {
		setSize(600, 300);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		lamina= new JPanel();
		lamina.setLayout(null);
		JLabel etiqueta =new JLabel("Esperar que el Boton se active\n");

		boton= new JButton("Continuar");

		etiqueta.setBounds(210, 60, 500, 30);
		boton.setBounds(240, 100, 100, 40);
		lamina.add(etiqueta);
		lamina.add(boton);
		add(lamina);
		setVisible(true);
		setLocationRelativeTo(null);
		
		boton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				if (dni == Integer.parseInt(campoTexto)) {
					if(elector != null) {
						switch (elector.getDomicilio().getProvincia()) {
							case "Corrientes": {
								VentanaVotoDiputado vvd =  new VentanaVotoDiputado(elector, padron, padron.getControlaDistrito().get(0));
								break;
							}
							case "Buenos Aires": {
								VentanaVotoDiputado vvd= new VentanaVotoDiputado(elector, padron,padron.getControlaDistrito().get(1));
								break;
							}
							case "CABA": {
								VentanaVotoDiputado vvd= new VentanaVotoDiputado(elector, padron,padron.getControlaDistrito().get(2));
								break;
							}
							case "Misiones": {
								VentanaVotoDiputado vvd= new VentanaVotoDiputado(elector, padron,padron.getControlaDistrito().get(3));
								break;
							}
							case "Entre Rios": {
								VentanaVotoDiputado vvd = new VentanaVotoDiputado(elector, padron, padron.getControlaDistrito().get(4));
								break;
							}
							default:
								break;
						}
					}else {
						JOptionPane.showMessageDialog(null,
								"El elector no se encuentra en el padron electoral");
						VentanaVotoCamaraV2 ventanaV = new VentanaVotoCamaraV2(padron);
						Thread hilo = new Thread(ventanaV);
						hilo.start();
					}
				} else {
					JOptionPane.showMessageDialog(null,
							"El numero de DNI ingresado no coincide con el de la foto");
					VentanaVotoCamaraV2 ventanaV = new VentanaVotoCamaraV2(padron);
					Thread hilo = new Thread(ventanaV);
					hilo.start();
				}
			}
		});
		
		boton.setEnabled(false);
		ITesseract imagen = new Tesseract();
		imagen.setLanguage("spa");
		try {
			String str = imagen.doOCR(new File("src\\main\\java\\imagenDNI.png"));
			String[] datos= str.split(" ");
			Pattern pattern = Pattern.compile("([M||m]?[F||f]?\\d{1,2}\\.?\\d{3}\\.?\\d{3})");
			Matcher matcher = pattern.matcher(str);
			
			for (String string : datos) {
				if(string.length()>8) {
					matcher = pattern.matcher(string);
					if(matcher.find()) {
						separarDNI(string);
					}
				}
			}
		} catch (TesseractException e) {
			e.printStackTrace();
		}
		boton.setEnabled(true);
		
	}
	
	/**
	 * @param dni string dni
	 * quita los caracteres que no sean numeros
	 *
	 */
	private void separarDNI(String dni) {
		String cadena = "";
		String [] doc= dni.split("[^0-9]");
		for (int i = 0; i < doc.length; i++) {
			if(doc[i].matches("[0-9]*"))
				cadena += doc[i];
		}
		try{
			this.dni = Integer.parseInt(cadena);
		}catch(Exception e){
			this.dni = 0;
			System.out.println(this.dni);
		}
		System.out.println(this.dni);
	}

	/**
	 * @return dni
	 * Metodo getDni
	 */
	public int getDNI() {
		return this.dni;
	}
}