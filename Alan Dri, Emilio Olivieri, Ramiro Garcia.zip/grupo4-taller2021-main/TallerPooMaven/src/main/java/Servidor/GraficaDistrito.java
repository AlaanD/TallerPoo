package Servidor;

import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *
 */

/**
 * Se encarga de crear los graficos para cada distrito.
 */
public class GraficaDistrito extends JFrame {

	/**
	 * panel contentPane
	 */
	private JPanel contentPane;

	/**
	 * @param nombre del distrito que llama a la grafica
	 * @param referenciavalor1 nombre del valor1 
	 * @param referenciavalor2 nombre del valor2
	 * @param valor1 representa la cantidad elementos referenciados por referenciavalor1
	 * @param valor2 representa la cantidad elementos referenciados por referenciavalor2
	 * @param posicion establece la posicion de las ventanas en pantalla
	 */
	public GraficaDistrito(String nombre,String referenciavalor1,String referenciavalor2,int valor1,int valor2,boolean posicion) {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 650, 730);

		if(posicion) {
			setBounds(100, 100, 650, 730);
		}else{
			setBounds(655, 100, 650, 730);
		}
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout());
		
		JPanel panel = new JPanel();
		DefaultPieDataset<String> datos = new DefaultPieDataset<>();
		datos.setValue(referenciavalor1, valor1);
		datos.setValue(referenciavalor2, valor2);
		
		JFreeChart grafico = ChartFactory.createPieChart("Grafico por distrito "+ nombre,datos, true, true,false);
		ChartPanel panelgrafico = new ChartPanel(grafico);
		panelgrafico.setMouseWheelEnabled(true);
		panelgrafico.setPreferredSize(new Dimension(500,500));

		panel.add(panelgrafico);
		contentPane.add(panel,BorderLayout.CENTER);
	
		JButton btnCerrar=new JButton("Cerrar");
		JPanel panelbtn = new JPanel();
		panelbtn.add(btnCerrar);
		add(panelbtn,BorderLayout.SOUTH);
		setVisible(true);
		btnCerrar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		repaint();
		pack();
	}
}
