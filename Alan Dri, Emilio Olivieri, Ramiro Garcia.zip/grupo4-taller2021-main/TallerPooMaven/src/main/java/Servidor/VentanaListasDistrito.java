package Servidor;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.border.EtchedBorder;
import Taller.CamaraElectoral;
import Taller.Distrito;
import java.awt.Color;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 * 
 */

/**
 * Crea un JFrame de las listas de los distritos.
 * Nos muestra la cantidad de votos por lista, discriminando diputados y si corresponde de senadores.
 */
public class VentanaListasDistrito extends JFrame {

	/**
	 * panel contentPane elemento del frame
	 */
	private JPanel contentPane;
	/**
	 * etiqueta cantidad de diputados perteneciente a la lista 1, utilizado en el frame
	 */
	private JLabel cantidadDiputadosLista1;
	/**
	 * etiqueta cantidad de diputados perteneciente a la lista 2, utilizado en el frame
	 */
	private JLabel cantidadDiputadosLista2;
	/**
	 * etiqueta cantidad de diputados perteneciente a la lista 3, utilizado en el frame
	 */
	private JLabel cantidadDiputadosLista3;
	/**
	 * etiqueta cantidad de diputados perteneciente a la lista 4, utilizado en el frame
	 */
	private JLabel cantidadDiputadosLista4;

	/**
	 * etiqueta cantidad de senadores perteneciente a la lista 1, utilizado en el frame
	 */
	private JLabel cantidadSenadoresLista1;
	/**
	 * etiqueta cantidad de senadores perteneciente a la lista 2, utilizado en el frame
	 */
	private JLabel cantidadSenadoresLista2;
	/**
	 * etiqueta cantidad de senadores perteneciente a la lista 3, utilizado en el frame
	 */
	private JLabel cantidadSenadoresLista3;
	/**
	 * etiqueta cantidad de senadores perteneciente a la lista 4, utilizado en el frame
	 */
	private JLabel cantidadSenadoresLista4;

	

	/**
	 * @param distrito, que se va a usar en la ventana
	 * @param infoDelDistrtito, los datos del distrito
	 * @param senadores, true si es que vota senadores, 
	 * 					false si no se vota sendores
	 * 
	 * 
	 */
	public VentanaListasDistrito(Distrito distrito, int infoDelDistrtito[], boolean senadores) {
		if (senadores) {
			setTitle(distrito.getNombre());
			setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			setBounds(100, 100, 801, 751);
			contentPane = new JPanel();
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(contentPane);
			contentPane.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

			JPanel panel = new JPanel();
			contentPane.add(panel);
			panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

			JPanel panel_1 = new JPanel();
			panel_1.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(0, 0, 0), new Color(0, 0, 0)));
			GridBagLayout gbl_panel_1 = new GridBagLayout();
			gbl_panel_1.columnWidths = new int[] { 0, 0, 65, 0, 111, 101, 0, 110, 0, 0, 0, 0, 0 };
			gbl_panel_1.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0 };
			gbl_panel_1.columnWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0,
					Double.MIN_VALUE };
			gbl_panel_1.rowWeights = new double[] { 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE };
			panel_1.setLayout(gbl_panel_1);

			JSeparator separator = new JSeparator();
			separator.setOrientation(SwingConstants.VERTICAL);
			separator.setForeground(Color.BLACK);
			separator.setBackground(Color.BLACK);
			GridBagConstraints gbc_separator = new GridBagConstraints();
			gbc_separator.gridheight = 7;
			gbc_separator.insets = new Insets(0, 0, 0, 5);
			gbc_separator.gridx = 3;
			gbc_separator.gridy = 0;
			panel_1.add(separator, gbc_separator);

			JLabel nombreLista1 = new JLabel("Nombre Lista");
			GridBagConstraints gbc_nombreLista1 = new GridBagConstraints();
			gbc_nombreLista1.insets = new Insets(0, 0, 5, 5);
			gbc_nombreLista1.gridx = 2;
			gbc_nombreLista1.gridy = 1;
			panel_1.add(nombreLista1, gbc_nombreLista1);

			JLabel lblNewLabel_3 = new JLabel("Diputados");
			GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
			gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_3.gridx = 4;
			gbc_lblNewLabel_3.gridy = 1;
			panel_1.add(lblNewLabel_3, gbc_lblNewLabel_3);

			JLabel lblNewLabel_4 = new JLabel("    Senadores");
			GridBagConstraints gbc_lblNewLabel_4 = new GridBagConstraints();
			gbc_lblNewLabel_4.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_4.gridx = 5;
			gbc_lblNewLabel_4.gridy = 1;
			panel_1.add(lblNewLabel_4, gbc_lblNewLabel_4);

			JLabel lblNewLabel = new JLabel("   Votos de diputados");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.BOTH;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 7;
			gbc_lblNewLabel.gridy = 1;
			panel_1.add(lblNewLabel, gbc_lblNewLabel);

			JLabel lblNewLabel_1 = new JLabel("Votos de Senadores");
			GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
			gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_1.gridx = 8;
			gbc_lblNewLabel_1.gridy = 1;
			panel_1.add(lblNewLabel_1, gbc_lblNewLabel_1);

			JLabel nombeLista = new JLabel(distrito.getListasAVotar().get(0).getNombre());
			GridBagConstraints gbc_nombeLista = new GridBagConstraints();
			gbc_nombeLista.insets = new Insets(0, 0, 5, 5);
			gbc_nombeLista.gridx = 2;
			gbc_nombeLista.gridy = 2;
			panel_1.add(nombeLista, gbc_nombeLista);

			JLabel diputado1Lista1 = new JLabel(distrito.getListasAVotar().get(0).getDiputado().get(0).getNombre());
			GridBagConstraints gbc_diputado1Lista1 = new GridBagConstraints();
			gbc_diputado1Lista1.insets = new Insets(0, 0, 5, 5);
			gbc_diputado1Lista1.gridx = 4;
			gbc_diputado1Lista1.gridy = 2;
			panel_1.add(diputado1Lista1, gbc_diputado1Lista1);

			JLabel senador1Lista1 = new JLabel(distrito.getListasAVotar().get(0).getSenador().get(0).getNombre());
			GridBagConstraints gbc_senador1Lista1 = new GridBagConstraints();
			gbc_senador1Lista1.insets = new Insets(0, 0, 5, 5);
			gbc_senador1Lista1.gridx = 5;
			gbc_senador1Lista1.gridy = 2;
			panel_1.add(senador1Lista1, gbc_senador1Lista1);

			cantidadDiputadosLista1 = new JLabel(infoDelDistrtito[3] + " ");
			GridBagConstraints gbc_cantidadDiputados = new GridBagConstraints();
			gbc_cantidadDiputados.insets = new Insets(0, 0, 5, 5);
			gbc_cantidadDiputados.gridx = 7;
			gbc_cantidadDiputados.gridy = 2;
			panel_1.add(cantidadDiputadosLista1, gbc_cantidadDiputados);

			cantidadSenadoresLista1 = new JLabel(infoDelDistrtito[4] + " ");
			GridBagConstraints gbc_cantidadSenadores = new GridBagConstraints();
			gbc_cantidadSenadores.insets = new Insets(0, 0, 5, 5);
			gbc_cantidadSenadores.gridx = 8;
			gbc_cantidadSenadores.gridy = 2;
			panel_1.add(cantidadSenadoresLista1, gbc_cantidadSenadores);

			JLabel diputado2Lista1 = new JLabel(distrito.getListasAVotar().get(1).getDiputado().get(0).getNombre());
			GridBagConstraints gbc_diputado2Lista1 = new GridBagConstraints();
			gbc_diputado2Lista1.insets = new Insets(0, 0, 5, 5);
			gbc_diputado2Lista1.gridx = 4;
			gbc_diputado2Lista1.gridy = 3;
			panel_1.add(diputado2Lista1, gbc_diputado2Lista1);

			JLabel senador2Lista1 = new JLabel(distrito.getListasAVotar().get(0).getSenador().get(1).getNombre());
			GridBagConstraints gbc_senador2Lista1 = new GridBagConstraints();
			gbc_senador2Lista1.insets = new Insets(0, 0, 5, 5);
			gbc_senador2Lista1.gridx = 5;
			gbc_senador2Lista1.gridy = 3;
			panel_1.add(senador2Lista1, gbc_senador2Lista1);

			JLabel diputado3Lista1 = new JLabel(distrito.getListasAVotar().get(0).getDiputado().get(2).getNombre());
			GridBagConstraints gbc_diputado3Lista1 = new GridBagConstraints();
			gbc_diputado3Lista1.insets = new Insets(0, 0, 5, 5);
			gbc_diputado3Lista1.gridx = 4;
			gbc_diputado3Lista1.gridy = 4;
			panel_1.add(diputado3Lista1, gbc_diputado3Lista1);

			JLabel senador3Lista1 = new JLabel(distrito.getListasAVotar().get(0).getSenador().get(2).getNombre());
			GridBagConstraints gbc_senador3Lista1 = new GridBagConstraints();
			gbc_senador3Lista1.insets = new Insets(0, 0, 5, 5);
			gbc_senador3Lista1.gridx = 5;
			gbc_senador3Lista1.gridy = 4;
			panel_1.add(senador3Lista1, gbc_senador3Lista1);

			JLabel diputado4Lista1 = new JLabel(distrito.getListasAVotar().get(0).getDiputado().get(3).getNombre());
			diputado4Lista1.setHorizontalAlignment(SwingConstants.CENTER);
			GridBagConstraints gbc_diputado4Lista1 = new GridBagConstraints();
			gbc_diputado4Lista1.fill = GridBagConstraints.BOTH;
			gbc_diputado4Lista1.insets = new Insets(0, 0, 5, 5);
			gbc_diputado4Lista1.gridx = 4;
			gbc_diputado4Lista1.gridy = 5;
			panel_1.add(diputado4Lista1, gbc_diputado4Lista1);

			JLabel diputado5Lista1 = new JLabel(distrito.getListasAVotar().get(0).getDiputado().get(4).getNombre());
			GridBagConstraints gbc_diputado5Lista1 = new GridBagConstraints();
			gbc_diputado5Lista1.insets = new Insets(0, 0, 0, 5);
			gbc_diputado5Lista1.gridx = 4;
			gbc_diputado5Lista1.gridy = 6;
			panel_1.add(diputado5Lista1, gbc_diputado5Lista1);
			panel.add(panel_1);

			JPanel panel_1_1 = new JPanel();
			panel_1_1.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(0, 0, 0), new Color(0, 0, 0)));
			contentPane.add(panel_1_1);
			GridBagLayout gbl_panel_1_1 = new GridBagLayout();
			gbl_panel_1_1.columnWidths = new int[] { 0, 0, 65, 0, 104, 111, 0, 110, 0, 0, 0, 0, 0 };
			gbl_panel_1_1.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0 };
			gbl_panel_1_1.columnWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0,
					Double.MIN_VALUE };
			gbl_panel_1_1.rowWeights = new double[] { 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE };
			panel_1_1.setLayout(gbl_panel_1_1);

			JSeparator separator_1 = new JSeparator();
			separator_1.setOrientation(SwingConstants.VERTICAL);
			separator_1.setForeground(Color.BLACK);
			separator_1.setBackground(Color.BLACK);
			GridBagConstraints gbc_separator_1 = new GridBagConstraints();
			gbc_separator_1.gridheight = 7;
			gbc_separator_1.insets = new Insets(0, 0, 0, 5);
			gbc_separator_1.gridx = 3;
			gbc_separator_1.gridy = 0;
			panel_1_1.add(separator_1, gbc_separator_1);

			JLabel lblNewLabel_2_1 = new JLabel("Nombre Lista");
			GridBagConstraints gbc_lblNewLabel_2_1 = new GridBagConstraints();
			gbc_lblNewLabel_2_1.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_2_1.gridx = 2;
			gbc_lblNewLabel_2_1.gridy = 1;
			panel_1_1.add(lblNewLabel_2_1, gbc_lblNewLabel_2_1);

			JLabel lblNewLabel_3_1 = new JLabel("Diputados");
			GridBagConstraints gbc_lblNewLabel_3_1 = new GridBagConstraints();
			gbc_lblNewLabel_3_1.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_3_1.gridx = 4;
			gbc_lblNewLabel_3_1.gridy = 1;
			panel_1_1.add(lblNewLabel_3_1, gbc_lblNewLabel_3_1);

			JLabel lblNewLabel_4_1 = new JLabel("    Senadores");
			GridBagConstraints gbc_lblNewLabel_4_1 = new GridBagConstraints();
			gbc_lblNewLabel_4_1.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_4_1.gridx = 5;
			gbc_lblNewLabel_4_1.gridy = 1;
			panel_1_1.add(lblNewLabel_4_1, gbc_lblNewLabel_4_1);

			JLabel lblNewLabel_5 = new JLabel("   Votos de diputados");
			GridBagConstraints gbc_lblNewLabel_5 = new GridBagConstraints();
			gbc_lblNewLabel_5.fill = GridBagConstraints.BOTH;
			gbc_lblNewLabel_5.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_5.gridx = 7;
			gbc_lblNewLabel_5.gridy = 1;
			panel_1_1.add(lblNewLabel_5, gbc_lblNewLabel_5);

			JLabel lblNewLabel_1_1 = new JLabel("Votos de Senadores");
			GridBagConstraints gbc_lblNewLabel_1_1 = new GridBagConstraints();
			gbc_lblNewLabel_1_1.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_1_1.gridx = 8;
			gbc_lblNewLabel_1_1.gridy = 1;
			panel_1_1.add(lblNewLabel_1_1, gbc_lblNewLabel_1_1);

			JLabel nombeLista_1 = new JLabel(distrito.getListasAVotar().get(1).getNombre());
			GridBagConstraints gbc_nombeLista_1 = new GridBagConstraints();
			gbc_nombeLista_1.insets = new Insets(0, 0, 5, 5);
			gbc_nombeLista_1.gridx = 2;
			gbc_nombeLista_1.gridy = 2;
			panel_1_1.add(nombeLista_1, gbc_nombeLista_1);

			JLabel diputado1Lista2 = new JLabel(distrito.getListasAVotar().get(1).getDiputado().get(0).getNombre());
			GridBagConstraints gbc_diputado1Lista2 = new GridBagConstraints();
			gbc_diputado1Lista2.insets = new Insets(0, 0, 5, 5);
			gbc_diputado1Lista2.gridx = 4;
			gbc_diputado1Lista2.gridy = 2;
			panel_1_1.add(diputado1Lista2, gbc_diputado1Lista2);

			JLabel senador1Lista2 = new JLabel(distrito.getListasAVotar().get(1).getSenador().get(0).getNombre());
			GridBagConstraints gbc_senador1Lista2 = new GridBagConstraints();
			gbc_senador1Lista2.insets = new Insets(0, 0, 5, 5);
			gbc_senador1Lista2.gridx = 5;
			gbc_senador1Lista2.gridy = 2;
			panel_1_1.add(senador1Lista2, gbc_senador1Lista2);

			cantidadDiputadosLista2 = new JLabel(infoDelDistrtito[5] + " ");
			GridBagConstraints gbc_cantidadDiputados_1 = new GridBagConstraints();
			gbc_cantidadDiputados_1.insets = new Insets(0, 0, 5, 5);
			gbc_cantidadDiputados_1.gridx = 7;
			gbc_cantidadDiputados_1.gridy = 2;
			panel_1_1.add(cantidadDiputadosLista2, gbc_cantidadDiputados_1);

			cantidadSenadoresLista2 = new JLabel(infoDelDistrtito[6] + " ");
			GridBagConstraints gbc_cantidadSenadores_1 = new GridBagConstraints();
			gbc_cantidadSenadores_1.insets = new Insets(0, 0, 5, 5);
			gbc_cantidadSenadores_1.gridx = 8;
			gbc_cantidadSenadores_1.gridy = 2;
			panel_1_1.add(cantidadSenadoresLista2, gbc_cantidadSenadores_1);

			JLabel diputado2Lista2 = new JLabel(distrito.getListasAVotar().get(1).getDiputado().get(1).getNombre());
			GridBagConstraints gbc_diputado2Lista2 = new GridBagConstraints();
			gbc_diputado2Lista2.insets = new Insets(0, 0, 5, 5);
			gbc_diputado2Lista2.gridx = 4;
			gbc_diputado2Lista2.gridy = 3;
			panel_1_1.add(diputado2Lista2, gbc_diputado2Lista2);

			JLabel senador2Lista2 = new JLabel(distrito.getListasAVotar().get(1).getSenador().get(1).getNombre());
			GridBagConstraints gbc_senador2Lista2 = new GridBagConstraints();
			gbc_senador2Lista2.insets = new Insets(0, 0, 5, 5);
			gbc_senador2Lista2.gridx = 5;
			gbc_senador2Lista2.gridy = 3;
			panel_1_1.add(senador2Lista2, gbc_senador2Lista2);

			JLabel diputado3Lista2 = new JLabel(distrito.getListasAVotar().get(1).getDiputado().get(2).getNombre());
			GridBagConstraints gbc_diputado3Lista2 = new GridBagConstraints();
			gbc_diputado3Lista2.insets = new Insets(0, 0, 5, 5);
			gbc_diputado3Lista2.gridx = 4;
			gbc_diputado3Lista2.gridy = 4;
			panel_1_1.add(diputado3Lista2, gbc_diputado3Lista2);

			JLabel senador3Lista2 = new JLabel(distrito.getListasAVotar().get(1).getSenador().get(2).getNombre());
			GridBagConstraints gbc_senador3Lista2 = new GridBagConstraints();
			gbc_senador3Lista2.insets = new Insets(0, 0, 5, 5);
			gbc_senador3Lista2.gridx = 5;
			gbc_senador3Lista2.gridy = 4;
			panel_1_1.add(senador3Lista2, gbc_senador3Lista2);

			JLabel diputado4Lista2 = new JLabel(distrito.getListasAVotar().get(1).getDiputado().get(3).getNombre());
			diputado4Lista2.setHorizontalAlignment(SwingConstants.CENTER);
			GridBagConstraints gbc_diputado4Lista2 = new GridBagConstraints();
			gbc_diputado4Lista2.fill = GridBagConstraints.BOTH;
			gbc_diputado4Lista2.insets = new Insets(0, 0, 5, 5);
			gbc_diputado4Lista2.gridx = 4;
			gbc_diputado4Lista2.gridy = 5;
			panel_1_1.add(diputado4Lista2, gbc_diputado4Lista2);

			JLabel diputado5Lista2 = new JLabel(distrito.getListasAVotar().get(1).getDiputado().get(4).getNombre());
			GridBagConstraints gbc_diputado5Lista2 = new GridBagConstraints();
			gbc_diputado5Lista2.insets = new Insets(0, 0, 0, 5);
			gbc_diputado5Lista2.gridx = 4;
			gbc_diputado5Lista2.gridy = 6;
			panel_1_1.add(diputado5Lista2, gbc_diputado5Lista2);

			JPanel panel_1_2 = new JPanel();
			panel_1_2.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(0, 0, 0), new Color(0, 0, 0)));
			contentPane.add(panel_1_2);
			GridBagLayout gbl_panel_1_2 = new GridBagLayout();
			gbl_panel_1_2.columnWidths = new int[] { 0, 0, 65, 0, 107, 104, 0, 110, 0, 0, 0, 0, 0 };
			gbl_panel_1_2.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0 };
			gbl_panel_1_2.columnWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0,
					Double.MIN_VALUE };
			gbl_panel_1_2.rowWeights = new double[] { 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE };
			panel_1_2.setLayout(gbl_panel_1_2);

			JSeparator separator_2 = new JSeparator();
			separator_2.setOrientation(SwingConstants.VERTICAL);
			separator_2.setForeground(Color.BLACK);
			separator_2.setBackground(Color.BLACK);
			GridBagConstraints gbc_separator_2 = new GridBagConstraints();
			gbc_separator_2.gridheight = 7;
			gbc_separator_2.insets = new Insets(0, 0, 0, 5);
			gbc_separator_2.gridx = 3;
			gbc_separator_2.gridy = 0;
			panel_1_2.add(separator_2, gbc_separator_2);

			JLabel lblNewLabel_2_2 = new JLabel("Nombre Lista");
			GridBagConstraints gbc_lblNewLabel_2_2 = new GridBagConstraints();
			gbc_lblNewLabel_2_2.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_2_2.gridx = 2;
			gbc_lblNewLabel_2_2.gridy = 1;
			panel_1_2.add(lblNewLabel_2_2, gbc_lblNewLabel_2_2);

			JLabel lblNewLabel_3_2 = new JLabel("Diputados");
			GridBagConstraints gbc_lblNewLabel_3_2 = new GridBagConstraints();
			gbc_lblNewLabel_3_2.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_3_2.gridx = 4;
			gbc_lblNewLabel_3_2.gridy = 1;
			panel_1_2.add(lblNewLabel_3_2, gbc_lblNewLabel_3_2);

			JLabel lblNewLabel_4_2 = new JLabel("    Senadores");
			GridBagConstraints gbc_lblNewLabel_4_2 = new GridBagConstraints();
			gbc_lblNewLabel_4_2.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_4_2.gridx = 5;
			gbc_lblNewLabel_4_2.gridy = 1;
			panel_1_2.add(lblNewLabel_4_2, gbc_lblNewLabel_4_2);

			JLabel lblNewLabel_6 = new JLabel("   Votos de diputados");
			GridBagConstraints gbc_lblNewLabel_6 = new GridBagConstraints();
			gbc_lblNewLabel_6.fill = GridBagConstraints.BOTH;
			gbc_lblNewLabel_6.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_6.gridx = 7;
			gbc_lblNewLabel_6.gridy = 1;
			panel_1_2.add(lblNewLabel_6, gbc_lblNewLabel_6);

			JLabel lblNewLabel_1_2 = new JLabel("Votos de Senadores");
			GridBagConstraints gbc_lblNewLabel_1_2 = new GridBagConstraints();
			gbc_lblNewLabel_1_2.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_1_2.gridx = 8;
			gbc_lblNewLabel_1_2.gridy = 1;
			panel_1_2.add(lblNewLabel_1_2, gbc_lblNewLabel_1_2);

			JLabel nombeLista_2 = new JLabel(distrito.getListasAVotar().get(2).getNombre());
			GridBagConstraints gbc_nombeLista_2 = new GridBagConstraints();
			gbc_nombeLista_2.insets = new Insets(0, 0, 5, 5);
			gbc_nombeLista_2.gridx = 2;
			gbc_nombeLista_2.gridy = 2;
			panel_1_2.add(nombeLista_2, gbc_nombeLista_2);

			JLabel diputado1Lista3 = new JLabel(distrito.getListasAVotar().get(2).getDiputado().get(0).getNombre());
			GridBagConstraints gbc_diputado1Lista3 = new GridBagConstraints();
			gbc_diputado1Lista3.insets = new Insets(0, 0, 5, 5);
			gbc_diputado1Lista3.gridx = 4;
			gbc_diputado1Lista3.gridy = 2;
			panel_1_2.add(diputado1Lista3, gbc_diputado1Lista3);

			JLabel senador1Lista3 = new JLabel(distrito.getListasAVotar().get(2).getSenador().get(0).getNombre());
			GridBagConstraints gbc_senador1Lista3 = new GridBagConstraints();
			gbc_senador1Lista3.insets = new Insets(0, 0, 5, 5);
			gbc_senador1Lista3.gridx = 5;
			gbc_senador1Lista3.gridy = 2;
			panel_1_2.add(senador1Lista3, gbc_senador1Lista3);

			cantidadDiputadosLista3 = new JLabel(infoDelDistrtito[7] + " ");
			GridBagConstraints gbc_cantidadDiputados_2 = new GridBagConstraints();
			gbc_cantidadDiputados_2.insets = new Insets(0, 0, 5, 5);
			gbc_cantidadDiputados_2.gridx = 7;
			gbc_cantidadDiputados_2.gridy = 2;
			panel_1_2.add(cantidadDiputadosLista3, gbc_cantidadDiputados_2);

			cantidadSenadoresLista3 = new JLabel(infoDelDistrtito[8] + " ");
			GridBagConstraints gbc_cantidadSenadores_2 = new GridBagConstraints();
			gbc_cantidadSenadores_2.insets = new Insets(0, 0, 5, 5);
			gbc_cantidadSenadores_2.gridx = 8;
			gbc_cantidadSenadores_2.gridy = 2;
			panel_1_2.add(cantidadSenadoresLista3, gbc_cantidadSenadores_2);

			JLabel diputado2Lista3 = new JLabel(distrito.getListasAVotar().get(2).getDiputado().get(1).getNombre());
			GridBagConstraints gbc_diputado2Lista3 = new GridBagConstraints();
			gbc_diputado2Lista3.insets = new Insets(0, 0, 5, 5);
			gbc_diputado2Lista3.gridx = 4;
			gbc_diputado2Lista3.gridy = 3;
			panel_1_2.add(diputado2Lista3, gbc_diputado2Lista3);

			JLabel senador2Lista3 = new JLabel(distrito.getListasAVotar().get(2).getSenador().get(1).getNombre());
			GridBagConstraints gbc_senador2Lista3 = new GridBagConstraints();
			gbc_senador2Lista3.insets = new Insets(0, 0, 5, 5);
			gbc_senador2Lista3.gridx = 5;
			gbc_senador2Lista3.gridy = 3;
			panel_1_2.add(senador2Lista3, gbc_senador2Lista3);

			JLabel diputado3Lista3 = new JLabel(distrito.getListasAVotar().get(2).getDiputado().get(2).getNombre());
			GridBagConstraints gbc_diputado3Lista3 = new GridBagConstraints();
			gbc_diputado3Lista3.insets = new Insets(0, 0, 5, 5);
			gbc_diputado3Lista3.gridx = 4;
			gbc_diputado3Lista3.gridy = 4;
			panel_1_2.add(diputado3Lista3, gbc_diputado3Lista3);

			JLabel senador3Lista3 = new JLabel(distrito.getListasAVotar().get(2).getSenador().get(2).getNombre());
			GridBagConstraints gbc_senador3Lista3 = new GridBagConstraints();
			gbc_senador3Lista3.insets = new Insets(0, 0, 5, 5);
			gbc_senador3Lista3.gridx = 5;
			gbc_senador3Lista3.gridy = 4;
			panel_1_2.add(senador3Lista3, gbc_senador3Lista3);

			JLabel diputado4Lista3 = new JLabel(distrito.getListasAVotar().get(2).getDiputado().get(3).getNombre());
			diputado4Lista3.setHorizontalAlignment(SwingConstants.CENTER);
			GridBagConstraints gbc_diputado4Lista3 = new GridBagConstraints();
			gbc_diputado4Lista3.fill = GridBagConstraints.BOTH;
			gbc_diputado4Lista3.insets = new Insets(0, 0, 5, 5);
			gbc_diputado4Lista3.gridx = 4;
			gbc_diputado4Lista3.gridy = 5;
			panel_1_2.add(diputado4Lista3, gbc_diputado4Lista3);

			JLabel diputado5Lista3 = new JLabel(distrito.getListasAVotar().get(2).getDiputado().get(4).getNombre());
			GridBagConstraints gbc_diputado5Lista3 = new GridBagConstraints();
			gbc_diputado5Lista3.insets = new Insets(0, 0, 0, 5);
			gbc_diputado5Lista3.gridx = 4;
			gbc_diputado5Lista3.gridy = 6;
			panel_1_2.add(diputado5Lista3, gbc_diputado5Lista3);

			JPanel panel_1_3 = new JPanel();
			panel_1_3.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(0, 0, 0), new Color(0, 0, 0)));
			contentPane.add(panel_1_3);
			GridBagLayout gbl_panel_1_3 = new GridBagLayout();
			gbl_panel_1_3.columnWidths = new int[] { 0, 0, 65, 0, 97, 100, 0, 110, 0, 0, 0, 0, 0 };
			gbl_panel_1_3.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0 };
			gbl_panel_1_3.columnWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0,
					Double.MIN_VALUE };
			gbl_panel_1_3.rowWeights = new double[] { 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE };
			panel_1_3.setLayout(gbl_panel_1_3);

			JSeparator separator_3 = new JSeparator();
			separator_3.setOrientation(SwingConstants.VERTICAL);
			separator_3.setForeground(Color.BLACK);
			separator_3.setBackground(Color.BLACK);
			GridBagConstraints gbc_separator_3 = new GridBagConstraints();
			gbc_separator_3.gridheight = 7;
			gbc_separator_3.insets = new Insets(0, 0, 0, 5);
			gbc_separator_3.gridx = 3;
			gbc_separator_3.gridy = 0;
			panel_1_3.add(separator_3, gbc_separator_3);

			JLabel lblNewLabel_2_3 = new JLabel("Nombre Lista");
			GridBagConstraints gbc_lblNewLabel_2_3 = new GridBagConstraints();
			gbc_lblNewLabel_2_3.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_2_3.gridx = 2;
			gbc_lblNewLabel_2_3.gridy = 1;
			panel_1_3.add(lblNewLabel_2_3, gbc_lblNewLabel_2_3);

			JLabel lblNewLabel_3_3 = new JLabel("Diputados");
			GridBagConstraints gbc_lblNewLabel_3_3 = new GridBagConstraints();
			gbc_lblNewLabel_3_3.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_3_3.gridx = 4;
			gbc_lblNewLabel_3_3.gridy = 1;
			panel_1_3.add(lblNewLabel_3_3, gbc_lblNewLabel_3_3);

			JLabel lblNewLabel_4_3 = new JLabel("    Senadores");
			GridBagConstraints gbc_lblNewLabel_4_3 = new GridBagConstraints();
			gbc_lblNewLabel_4_3.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_4_3.gridx = 5;
			gbc_lblNewLabel_4_3.gridy = 1;
			panel_1_3.add(lblNewLabel_4_3, gbc_lblNewLabel_4_3);

			JLabel lblNewLabel_7 = new JLabel("   Votos de diputados");
			GridBagConstraints gbc_lblNewLabel_7 = new GridBagConstraints();
			gbc_lblNewLabel_7.fill = GridBagConstraints.BOTH;
			gbc_lblNewLabel_7.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_7.gridx = 7;
			gbc_lblNewLabel_7.gridy = 1;
			panel_1_3.add(lblNewLabel_7, gbc_lblNewLabel_7);

			JLabel lblNewLabel_1_3 = new JLabel("Votos de Senadores");
			GridBagConstraints gbc_lblNewLabel_1_3 = new GridBagConstraints();
			gbc_lblNewLabel_1_3.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_1_3.gridx = 8;
			gbc_lblNewLabel_1_3.gridy = 1;
			panel_1_3.add(lblNewLabel_1_3, gbc_lblNewLabel_1_3);

			JLabel nombeLista_3 = new JLabel(distrito.getListasAVotar().get(3).getNombre());
			GridBagConstraints gbc_nombeLista_3 = new GridBagConstraints();
			gbc_nombeLista_3.insets = new Insets(0, 0, 5, 5);
			gbc_nombeLista_3.gridx = 2;
			gbc_nombeLista_3.gridy = 2;
			panel_1_3.add(nombeLista_3, gbc_nombeLista_3);

			JLabel diputado1Lista4 = new JLabel(distrito.getListasAVotar().get(3).getDiputado().get(0).getNombre());
			GridBagConstraints gbc_diputado1Lista4 = new GridBagConstraints();
			gbc_diputado1Lista4.insets = new Insets(0, 0, 5, 5);
			gbc_diputado1Lista4.gridx = 4;
			gbc_diputado1Lista4.gridy = 2;
			panel_1_3.add(diputado1Lista4, gbc_diputado1Lista4);

			JLabel senador1Lista4 = new JLabel(distrito.getListasAVotar().get(3).getSenador().get(0).getNombre());
			GridBagConstraints gbc_senador1Lista4 = new GridBagConstraints();
			gbc_senador1Lista4.insets = new Insets(0, 0, 5, 5);
			gbc_senador1Lista4.gridx = 5;
			gbc_senador1Lista4.gridy = 2;
			panel_1_3.add(senador1Lista4, gbc_senador1Lista4);

			cantidadDiputadosLista4 = new JLabel(infoDelDistrtito[9] + " ");
			GridBagConstraints gbc_cantidadDiputados_3 = new GridBagConstraints();
			gbc_cantidadDiputados_3.insets = new Insets(0, 0, 5, 5);
			gbc_cantidadDiputados_3.gridx = 7;
			gbc_cantidadDiputados_3.gridy = 2;
			panel_1_3.add(cantidadDiputadosLista4, gbc_cantidadDiputados_3);

			cantidadSenadoresLista4 = new JLabel(infoDelDistrtito[10] + " ");
			GridBagConstraints gbc_cantidadSenadores_3 = new GridBagConstraints();
			gbc_cantidadSenadores_3.insets = new Insets(0, 0, 5, 5);
			gbc_cantidadSenadores_3.gridx = 8;
			gbc_cantidadSenadores_3.gridy = 2;
			panel_1_3.add(cantidadSenadoresLista4, gbc_cantidadSenadores_3);

			JLabel diputado2Lista4 = new JLabel(distrito.getListasAVotar().get(3).getDiputado().get(1).getNombre());
			GridBagConstraints gbc_diputado2Lista4 = new GridBagConstraints();
			gbc_diputado2Lista4.insets = new Insets(0, 0, 5, 5);
			gbc_diputado2Lista4.gridx = 4;
			gbc_diputado2Lista4.gridy = 3;
			panel_1_3.add(diputado2Lista4, gbc_diputado2Lista4);

			JLabel senador2Lista4 = new JLabel(distrito.getListasAVotar().get(3).getSenador().get(1).getNombre());
			GridBagConstraints gbc_senador2Lista4 = new GridBagConstraints();
			gbc_senador2Lista4.insets = new Insets(0, 0, 5, 5);
			gbc_senador2Lista4.gridx = 5;
			gbc_senador2Lista4.gridy = 3;
			panel_1_3.add(senador2Lista4, gbc_senador2Lista4);

			JLabel diputado3Lista4 = new JLabel(distrito.getListasAVotar().get(3).getDiputado().get(2).getNombre());
			GridBagConstraints gbc_diputado3Lista4 = new GridBagConstraints();
			gbc_diputado3Lista4.insets = new Insets(0, 0, 5, 5);
			gbc_diputado3Lista4.gridx = 4;
			gbc_diputado3Lista4.gridy = 4;
			panel_1_3.add(diputado3Lista4, gbc_diputado3Lista4);

			JLabel senador3Lista4 = new JLabel(distrito.getListasAVotar().get(3).getSenador().get(2).getNombre());
			GridBagConstraints gbc_senador3Lista4 = new GridBagConstraints();
			gbc_senador3Lista4.insets = new Insets(0, 0, 5, 5);
			gbc_senador3Lista4.gridx = 5;
			gbc_senador3Lista4.gridy = 4;
			panel_1_3.add(senador3Lista4, gbc_senador3Lista4);

			JLabel diputado4Lista4 = new JLabel(distrito.getListasAVotar().get(3).getDiputado().get(3).getNombre());
			diputado4Lista4.setHorizontalAlignment(SwingConstants.CENTER);
			GridBagConstraints gbc_diputado4Lista4 = new GridBagConstraints();
			gbc_diputado4Lista4.fill = GridBagConstraints.BOTH;
			gbc_diputado4Lista4.insets = new Insets(0, 0, 5, 5);
			gbc_diputado4Lista4.gridx = 4;
			gbc_diputado4Lista4.gridy = 5;
			panel_1_3.add(diputado4Lista4, gbc_diputado4Lista4);

			JLabel diputado5Lista4 = new JLabel(distrito.getListasAVotar().get(3).getDiputado().get(4).getNombre());
			GridBagConstraints gbc_diputado5Lista4 = new GridBagConstraints();
			gbc_diputado5Lista4.insets = new Insets(0, 0, 0, 5);
			gbc_diputado5Lista4.gridx = 4;
			gbc_diputado5Lista4.gridy = 6;
			panel_1_3.add(diputado5Lista4, gbc_diputado5Lista4);
			setResizable(false);
			setLocationRelativeTo(null);
			setVisible(true);
		} else {
			setTitle(distrito.getNombre());

			setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			setBounds(100, 100, 650, 681);

			contentPane = new JPanel();
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(contentPane);
			contentPane.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

			JPanel panel = new JPanel();
			contentPane.add(panel);
			panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

			JPanel panel_1 = new JPanel();
			panel_1.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(0, 0, 0), new Color(0, 0, 0)));
			GridBagLayout gbl_panel_1 = new GridBagLayout();
			gbl_panel_1.columnWidths = new int[] { 0, 0, 65, 0, 111, 0, 110, 0, 0, 0, 0, 0 };
			gbl_panel_1.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0 };
			gbl_panel_1.columnWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0,
					Double.MIN_VALUE };
			gbl_panel_1.rowWeights = new double[] { 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE };
			panel_1.setLayout(gbl_panel_1);

			JLabel nombreLista1 = new JLabel("Nombre Lista");
			GridBagConstraints gbc_nombreLista1 = new GridBagConstraints();
			gbc_nombreLista1.insets = new Insets(0, 0, 5, 5);
			gbc_nombreLista1.gridx = 2;
			gbc_nombreLista1.gridy = 1;
			panel_1.add(nombreLista1, gbc_nombreLista1);

			JLabel lblNewLabel_3 = new JLabel("Diputados");
			GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
			gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_3.gridx = 4;
			gbc_lblNewLabel_3.gridy = 1;
			panel_1.add(lblNewLabel_3, gbc_lblNewLabel_3);

			JLabel lblNewLabel = new JLabel("   Votos de diputados");
			GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
			gbc_lblNewLabel.fill = GridBagConstraints.BOTH;
			gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel.gridx = 6;
			gbc_lblNewLabel.gridy = 1;
			panel_1.add(lblNewLabel, gbc_lblNewLabel);

			JLabel nombeLista = new JLabel("    " + distrito.getListasAVotar().get(0).getNombre());
			GridBagConstraints gbc_nombeLista = new GridBagConstraints();
			gbc_nombeLista.insets = new Insets(0, 0, 5, 5);
			gbc_nombeLista.gridx = 2;
			gbc_nombeLista.gridy = 2;
			panel_1.add(nombeLista, gbc_nombeLista);

			JLabel diputado1Lista1 = new JLabel(distrito.getListasAVotar().get(0).getDiputado().get(0).getNombre());
			GridBagConstraints gbc_diputado1Lista1 = new GridBagConstraints();
			gbc_diputado1Lista1.insets = new Insets(0, 0, 5, 5);
			gbc_diputado1Lista1.gridx = 4;
			gbc_diputado1Lista1.gridy = 2;
			panel_1.add(diputado1Lista1, gbc_diputado1Lista1);

			cantidadDiputadosLista1 = new JLabel(infoDelDistrtito[3] + " ");
			GridBagConstraints gbc_cantidadDiputados = new GridBagConstraints();
			gbc_cantidadDiputados.insets = new Insets(0, 0, 5, 5);
			gbc_cantidadDiputados.gridx = 6;
			gbc_cantidadDiputados.gridy = 2;
			panel_1.add(cantidadDiputadosLista1, gbc_cantidadDiputados);

			JLabel diputado2Lista1 = new JLabel(distrito.getListasAVotar().get(1).getDiputado().get(0).getNombre());
			GridBagConstraints gbc_diputado2Lista1 = new GridBagConstraints();
			gbc_diputado2Lista1.insets = new Insets(0, 0, 5, 5);
			gbc_diputado2Lista1.gridx = 4;
			gbc_diputado2Lista1.gridy = 3;
			panel_1.add(diputado2Lista1, gbc_diputado2Lista1);

			JLabel diputado3Lista1 = new JLabel(distrito.getListasAVotar().get(0).getDiputado().get(2).getNombre());
			GridBagConstraints gbc_diputado3Lista1 = new GridBagConstraints();
			gbc_diputado3Lista1.insets = new Insets(0, 0, 5, 5);
			gbc_diputado3Lista1.gridx = 4;
			gbc_diputado3Lista1.gridy = 4;
			panel_1.add(diputado3Lista1, gbc_diputado3Lista1);

			JLabel diputado4Lista1 = new JLabel(distrito.getListasAVotar().get(0).getDiputado().get(3).getNombre());
			diputado4Lista1.setHorizontalAlignment(SwingConstants.CENTER);
			GridBagConstraints gbc_diputado4Lista1 = new GridBagConstraints();
			gbc_diputado4Lista1.fill = GridBagConstraints.BOTH;
			gbc_diputado4Lista1.insets = new Insets(0, 0, 5, 5);
			gbc_diputado4Lista1.gridx = 4;
			gbc_diputado4Lista1.gridy = 5;
			panel_1.add(diputado4Lista1, gbc_diputado4Lista1);

			JLabel diputado5Lista1 = new JLabel(distrito.getListasAVotar().get(0).getDiputado().get(4).getNombre());
			GridBagConstraints gbc_diputado5Lista1 = new GridBagConstraints();
			gbc_diputado5Lista1.insets = new Insets(0, 0, 0, 5);
			gbc_diputado5Lista1.gridx = 4;
			gbc_diputado5Lista1.gridy = 6;
			panel_1.add(diputado5Lista1, gbc_diputado5Lista1);
			panel.add(panel_1);

			JPanel panel_1_1 = new JPanel();
			panel_1_1.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(0, 0, 0), new Color(0, 0, 0)));
			contentPane.add(panel_1_1);
			GridBagLayout gbl_panel_1_1 = new GridBagLayout();
			gbl_panel_1_1.columnWidths = new int[] { 0, 0, 65, 0, 104, 0, 110, 0, 0, 0, 0, 0 };
			gbl_panel_1_1.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0 };
			gbl_panel_1_1.columnWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0,
					Double.MIN_VALUE };
			gbl_panel_1_1.rowWeights = new double[] { 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE };
			panel_1_1.setLayout(gbl_panel_1_1);

			JLabel lblNewLabel_2_1 = new JLabel("Nombre Lista");
			GridBagConstraints gbc_lblNewLabel_2_1 = new GridBagConstraints();
			gbc_lblNewLabel_2_1.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_2_1.gridx = 2;
			gbc_lblNewLabel_2_1.gridy = 1;
			panel_1_1.add(lblNewLabel_2_1, gbc_lblNewLabel_2_1);

			JLabel lblNewLabel_3_1 = new JLabel("Diputados");
			GridBagConstraints gbc_lblNewLabel_3_1 = new GridBagConstraints();
			gbc_lblNewLabel_3_1.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_3_1.gridx = 4;
			gbc_lblNewLabel_3_1.gridy = 1;
			panel_1_1.add(lblNewLabel_3_1, gbc_lblNewLabel_3_1);

			JLabel lblNewLabel_5 = new JLabel("   Votos de diputados");
			GridBagConstraints gbc_lblNewLabel_5 = new GridBagConstraints();
			gbc_lblNewLabel_5.fill = GridBagConstraints.BOTH;
			gbc_lblNewLabel_5.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_5.gridx = 6;
			gbc_lblNewLabel_5.gridy = 1;
			panel_1_1.add(lblNewLabel_5, gbc_lblNewLabel_5);

			JLabel nombeLista_1 = new JLabel("    " + distrito.getListasAVotar().get(1).getNombre());
			GridBagConstraints gbc_nombeLista_1 = new GridBagConstraints();
			gbc_nombeLista_1.insets = new Insets(0, 0, 5, 5);
			gbc_nombeLista_1.gridx = 2;
			gbc_nombeLista_1.gridy = 2;
			panel_1_1.add(nombeLista_1, gbc_nombeLista_1);

			JLabel diputado1Lista2 = new JLabel(distrito.getListasAVotar().get(1).getDiputado().get(0).getNombre());
			GridBagConstraints gbc_diputado1Lista2 = new GridBagConstraints();
			gbc_diputado1Lista2.insets = new Insets(0, 0, 5, 5);
			gbc_diputado1Lista2.gridx = 4;
			gbc_diputado1Lista2.gridy = 2;
			panel_1_1.add(diputado1Lista2, gbc_diputado1Lista2);
//

			cantidadDiputadosLista2 = new JLabel(infoDelDistrtito[5] + " ");
			GridBagConstraints gbc_cantidadDiputados_1 = new GridBagConstraints();
			gbc_cantidadDiputados_1.insets = new Insets(0, 0, 5, 5);
			gbc_cantidadDiputados_1.gridx = 6;
			gbc_cantidadDiputados_1.gridy = 2;
			panel_1_1.add(cantidadDiputadosLista2, gbc_cantidadDiputados_1);

			JLabel diputado2Lista2 = new JLabel(distrito.getListasAVotar().get(1).getDiputado().get(1).getNombre());
			GridBagConstraints gbc_diputado2Lista2 = new GridBagConstraints();
			gbc_diputado2Lista2.insets = new Insets(0, 0, 5, 5);
			gbc_diputado2Lista2.gridx = 4;
			gbc_diputado2Lista2.gridy = 3;
			panel_1_1.add(diputado2Lista2, gbc_diputado2Lista2);

			JLabel diputado3Lista2 = new JLabel(distrito.getListasAVotar().get(1).getDiputado().get(2).getNombre());
			GridBagConstraints gbc_diputado3Lista2 = new GridBagConstraints();
			gbc_diputado3Lista2.insets = new Insets(0, 0, 5, 5);
			gbc_diputado3Lista2.gridx = 4;
			gbc_diputado3Lista2.gridy = 4;
			panel_1_1.add(diputado3Lista2, gbc_diputado3Lista2);

			JLabel diputado4Lista2 = new JLabel(distrito.getListasAVotar().get(1).getDiputado().get(3).getNombre());
			diputado4Lista2.setHorizontalAlignment(SwingConstants.CENTER);
			GridBagConstraints gbc_diputado4Lista2 = new GridBagConstraints();
			gbc_diputado4Lista2.fill = GridBagConstraints.BOTH;
			gbc_diputado4Lista2.insets = new Insets(0, 0, 5, 5);
			gbc_diputado4Lista2.gridx = 4;
			gbc_diputado4Lista2.gridy = 5;
			panel_1_1.add(diputado4Lista2, gbc_diputado4Lista2);

			JLabel diputado5Lista2 = new JLabel(distrito.getListasAVotar().get(1).getDiputado().get(4).getNombre());
			GridBagConstraints gbc_diputado5Lista2 = new GridBagConstraints();
			gbc_diputado5Lista2.insets = new Insets(0, 0, 0, 5);
			gbc_diputado5Lista2.gridx = 4;
			gbc_diputado5Lista2.gridy = 6;
			panel_1_1.add(diputado5Lista2, gbc_diputado5Lista2);

			JPanel panel_1_2 = new JPanel();
			panel_1_2.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(0, 0, 0), new Color(0, 0, 0)));
			contentPane.add(panel_1_2);
			GridBagLayout gbl_panel_1_2 = new GridBagLayout();
			gbl_panel_1_2.columnWidths = new int[] { 0, 0, 65, 0, 107, 0, 110, 0, 0, 0, 0, 0 };
			gbl_panel_1_2.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0 };
			gbl_panel_1_2.columnWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0,
					Double.MIN_VALUE };
			gbl_panel_1_2.rowWeights = new double[] { 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE };
			panel_1_2.setLayout(gbl_panel_1_2);

			JLabel lblNewLabel_2_2 = new JLabel("Nombre Lista");
			GridBagConstraints gbc_lblNewLabel_2_2 = new GridBagConstraints();
			gbc_lblNewLabel_2_2.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_2_2.gridx = 2;
			gbc_lblNewLabel_2_2.gridy = 1;
			panel_1_2.add(lblNewLabel_2_2, gbc_lblNewLabel_2_2);

			JLabel lblNewLabel_3_2 = new JLabel("Diputados");
			GridBagConstraints gbc_lblNewLabel_3_2 = new GridBagConstraints();
			gbc_lblNewLabel_3_2.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_3_2.gridx = 4;
			gbc_lblNewLabel_3_2.gridy = 1;
			panel_1_2.add(lblNewLabel_3_2, gbc_lblNewLabel_3_2);

			JLabel lblNewLabel_6 = new JLabel("   Votos de diputados");
			GridBagConstraints gbc_lblNewLabel_6 = new GridBagConstraints();
			gbc_lblNewLabel_6.fill = GridBagConstraints.BOTH;
			gbc_lblNewLabel_6.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_6.gridx = 6;
			gbc_lblNewLabel_6.gridy = 1;
			panel_1_2.add(lblNewLabel_6, gbc_lblNewLabel_6);

			JLabel nombeLista_2 = new JLabel("    " + distrito.getListasAVotar().get(2).getNombre());
			GridBagConstraints gbc_nombeLista_2 = new GridBagConstraints();
			gbc_nombeLista_2.insets = new Insets(0, 0, 5, 5);
			gbc_nombeLista_2.gridx = 2;
			gbc_nombeLista_2.gridy = 2;
			panel_1_2.add(nombeLista_2, gbc_nombeLista_2);

			JLabel diputado1Lista3 = new JLabel(distrito.getListasAVotar().get(2).getDiputado().get(0).getNombre());
			GridBagConstraints gbc_diputado1Lista3 = new GridBagConstraints();
			gbc_diputado1Lista3.insets = new Insets(0, 0, 5, 5);
			gbc_diputado1Lista3.gridx = 4;
			gbc_diputado1Lista3.gridy = 2;
			panel_1_2.add(diputado1Lista3, gbc_diputado1Lista3);

			cantidadDiputadosLista3 = new JLabel(infoDelDistrtito[7] + " ");
			GridBagConstraints gbc_cantidadDiputados_2 = new GridBagConstraints();
			gbc_cantidadDiputados_2.insets = new Insets(0, 0, 5, 5);
			gbc_cantidadDiputados_2.gridx = 6;
			gbc_cantidadDiputados_2.gridy = 2;
			panel_1_2.add(cantidadDiputadosLista3, gbc_cantidadDiputados_2);

			JLabel diputado2Lista3 = new JLabel(distrito.getListasAVotar().get(2).getDiputado().get(1).getNombre());
			GridBagConstraints gbc_diputado2Lista3 = new GridBagConstraints();
			gbc_diputado2Lista3.insets = new Insets(0, 0, 5, 5);
			gbc_diputado2Lista3.gridx = 4;
			gbc_diputado2Lista3.gridy = 3;
			panel_1_2.add(diputado2Lista3, gbc_diputado2Lista3);

			JLabel diputado3Lista3 = new JLabel(distrito.getListasAVotar().get(2).getDiputado().get(2).getNombre());
			GridBagConstraints gbc_diputado3Lista3 = new GridBagConstraints();
			gbc_diputado3Lista3.insets = new Insets(0, 0, 5, 5);
			gbc_diputado3Lista3.gridx = 4;
			gbc_diputado3Lista3.gridy = 4;
			panel_1_2.add(diputado3Lista3, gbc_diputado3Lista3);
//

			JLabel diputado4Lista3 = new JLabel(distrito.getListasAVotar().get(2).getDiputado().get(3).getNombre());
			diputado4Lista3.setHorizontalAlignment(SwingConstants.CENTER);
			GridBagConstraints gbc_diputado4Lista3 = new GridBagConstraints();
			gbc_diputado4Lista3.fill = GridBagConstraints.BOTH;
			gbc_diputado4Lista3.insets = new Insets(0, 0, 5, 5);
			gbc_diputado4Lista3.gridx = 4;
			gbc_diputado4Lista3.gridy = 5;
			panel_1_2.add(diputado4Lista3, gbc_diputado4Lista3);

			JLabel diputado5Lista3 = new JLabel(distrito.getListasAVotar().get(2).getDiputado().get(4).getNombre());
			GridBagConstraints gbc_diputado5Lista3 = new GridBagConstraints();
			gbc_diputado5Lista3.insets = new Insets(0, 0, 0, 5);
			gbc_diputado5Lista3.gridx = 4;
			gbc_diputado5Lista3.gridy = 6;
			panel_1_2.add(diputado5Lista3, gbc_diputado5Lista3);

			JPanel panel_1_3 = new JPanel();
			panel_1_3.setBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(0, 0, 0), new Color(0, 0, 0)));
			contentPane.add(panel_1_3);
			GridBagLayout gbl_panel_1_3 = new GridBagLayout();
			gbl_panel_1_3.columnWidths = new int[] { 0, 0, 65, 0, 97, 0, 110, 0, 0, 0, 0, 0 };
			gbl_panel_1_3.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0 };
			gbl_panel_1_3.columnWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0,
					Double.MIN_VALUE };
			gbl_panel_1_3.rowWeights = new double[] { 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE };

			panel_1_3.setLayout(gbl_panel_1_3);

			JLabel lblNewLabel_2_3 = new JLabel("Nombre Lista");
			GridBagConstraints gbc_lblNewLabel_2_3 = new GridBagConstraints();
			gbc_lblNewLabel_2_3.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_2_3.gridx = 2;
			gbc_lblNewLabel_2_3.gridy = 1;
			panel_1_3.add(lblNewLabel_2_3, gbc_lblNewLabel_2_3);

			JLabel lblNewLabel_3_3 = new JLabel("Diputados");
			GridBagConstraints gbc_lblNewLabel_3_3 = new GridBagConstraints();
			gbc_lblNewLabel_3_3.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_3_3.gridx = 4;
			gbc_lblNewLabel_3_3.gridy = 1;
			panel_1_3.add(lblNewLabel_3_3, gbc_lblNewLabel_3_3);

			JLabel lblNewLabel_7 = new JLabel("   Votos de diputados");
			GridBagConstraints gbc_lblNewLabel_7 = new GridBagConstraints();
			gbc_lblNewLabel_7.fill = GridBagConstraints.BOTH;
			gbc_lblNewLabel_7.insets = new Insets(0, 0, 5, 5);
			gbc_lblNewLabel_7.gridx = 6;
			gbc_lblNewLabel_7.gridy = 1;
			panel_1_3.add(lblNewLabel_7, gbc_lblNewLabel_7);

			JLabel nombeLista_3 = new JLabel("    " + distrito.getListasAVotar().get(3).getNombre());
			GridBagConstraints gbc_nombeLista_3 = new GridBagConstraints();
			gbc_nombeLista_3.insets = new Insets(0, 0, 5, 5);
			gbc_nombeLista_3.gridx = 2;
			gbc_nombeLista_3.gridy = 2;
			panel_1_3.add(nombeLista_3, gbc_nombeLista_3);

			JLabel diputado1Lista4 = new JLabel(distrito.getListasAVotar().get(3).getDiputado().get(0).getNombre());
			GridBagConstraints gbc_diputado1Lista4 = new GridBagConstraints();
			gbc_diputado1Lista4.insets = new Insets(0, 0, 5, 5);
			gbc_diputado1Lista4.gridx = 4;
			gbc_diputado1Lista4.gridy = 2;
			panel_1_3.add(diputado1Lista4, gbc_diputado1Lista4);

			cantidadDiputadosLista4 = new JLabel(infoDelDistrtito[9] + " ");
			GridBagConstraints gbc_cantidadDiputados_3 = new GridBagConstraints();
			gbc_cantidadDiputados_3.insets = new Insets(0, 0, 5, 5);
			gbc_cantidadDiputados_3.gridx = 6;
			gbc_cantidadDiputados_3.gridy = 2;
			panel_1_3.add(cantidadDiputadosLista4, gbc_cantidadDiputados_3);

			JLabel diputado2Lista4 = new JLabel(distrito.getListasAVotar().get(3).getDiputado().get(1).getNombre());
			GridBagConstraints gbc_diputado2Lista4 = new GridBagConstraints();
			gbc_diputado2Lista4.insets = new Insets(0, 0, 5, 5);
			gbc_diputado2Lista4.gridx = 4;
			gbc_diputado2Lista4.gridy = 3;
			panel_1_3.add(diputado2Lista4, gbc_diputado2Lista4);

			JLabel diputado3Lista4 = new JLabel(distrito.getListasAVotar().get(3).getDiputado().get(2).getNombre());
			GridBagConstraints gbc_diputado3Lista4 = new GridBagConstraints();
			gbc_diputado3Lista4.insets = new Insets(0, 0, 5, 5);
			gbc_diputado3Lista4.gridx = 4;
			gbc_diputado3Lista4.gridy = 4;
			panel_1_3.add(diputado3Lista4, gbc_diputado3Lista4);

			JLabel diputado4Lista4 = new JLabel(distrito.getListasAVotar().get(3).getDiputado().get(3).getNombre());
			diputado4Lista4.setHorizontalAlignment(SwingConstants.CENTER);
			GridBagConstraints gbc_diputado4Lista4 = new GridBagConstraints();
			gbc_diputado4Lista4.fill = GridBagConstraints.BOTH;
			gbc_diputado4Lista4.insets = new Insets(0, 0, 5, 5);
			gbc_diputado4Lista4.gridx = 4;
			gbc_diputado4Lista4.gridy = 5;
			panel_1_3.add(diputado4Lista4, gbc_diputado4Lista4);

			JLabel diputado5Lista4 = new JLabel(distrito.getListasAVotar().get(3).getDiputado().get(4).getNombre());
			GridBagConstraints gbc_diputado5Lista4 = new GridBagConstraints();
			gbc_diputado5Lista4.insets = new Insets(0, 0, 0, 5);
			gbc_diputado5Lista4.gridx = 4;
			gbc_diputado5Lista4.gridy = 6;
			panel_1_3.add(diputado5Lista4, gbc_diputado5Lista4);
			setResizable(false);
			setLocationRelativeTo(null);
			setVisible(true);
		}
	}

}
