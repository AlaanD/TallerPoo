package Servidor;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import Taller.CamaraElectoral;
import Taller.CaracteristicaVoto;
import Taller.Circuito;
import Taller.Distrito;
import Taller.Lista;
import Taller.MesaElectoral;
import Taller.Seccion;
import Taller.Voto;

import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *
 */
/** Clase servidor.
 * 
 * 
 * InformacionDistritos\n \n
 * 
 * Esta clase es la encargada de otorgar la información de la votación.\n
 * Acceso a la listas de votación  y a las graficas de cada distrtio.\n
 * *************************************************\n
 * *************************************************\n
 * Los arreglos de información se utilizan de la siguiente manera.\n
 * 	
 * 	 pocisiones; [0] [1] [2] [3] [4] [5]  [6] [7] [8] [9] [10] \n
 * 
 *  [0] total de votos que tiene el distrito \n
 *  [1]  votos en blanco \n
 *  [2]  votos validos \n
 *  [3]  votos de diputados lista 1\n 
 *  [4]  votos de senadores lista 1\n
 *  [5]  votos de diputados lista 2\n
 *  [6]  votos de senadores lista 2\n
 *  [7]  votos de diputados lista 3 \n
 *  [8]  votos de senadores lista 3\n
 *  [9]  votos de diputados lista 4\n
 *  [10] votos de senadores lista 4\n
 * 
 *  JButton btnActualizar \n
 * 	 Con este boton procedemos actualizar el frame.\n 
 **********************************************************\n
 **********************************************************\n
 * 	
 *  Sistema de filtrado\n
 *  tenemos un sistema de codificación de voto\n
 *  
 *  {1,5}numero de distrito\n       
 *  				 		
 *  {1-4} lista	0 voto nulo {0-4}, de diputado elegido \n
 *  {1-4} lista 0 voto nulo {0-4}, de senador elegido 'n
 *  					
 * 
 * ejemplos de codigo de votación: 114, 530\n
 * 
 **********************************************************\n
 **********************************************************\n
 * 
 * Las graficas se abren segun el distrito  {validos , blanco  } {votos totales, votos realizados}\n
 * en diferentes posiciones para que no se solapen.\n
 * 
 * **********************************************************\n
 * **********************************************************\n
 * Tambien desde esta ventana podemos llamar a la ventana de listas de distritos,\n
 * la cual nos brinda los diputados y  senadores si correponde.\n
 * 
 * Alli podemos observar los votos que tienen los diputados y senadores segun el distrito.\n 
 * Para ello debemos utilizar los botones Listas Corrienes, Listas Entre Rios etc.\n
 * 
 *  **********************************************************\n
 *  **********************************************************\n
 */
public class InformacionDistritos extends JFrame {

	/**
	 * lista codificada de voto 
	 */
	private List<String> ListaCodigoVoto = new ArrayList<>();
	/**
	 * elemento panel utilizado en el frame
	 */
	private JPanel contentPane;
	/**
	 * elemento boton utilizado en el frame
	 */
	private JButton btnActualizar;
	/**
	 * elemento booleano de control 
	 */
	private boolean control = false;
	/**
	 * vector para decoficidar el voto
	 */
	private int infoCorrientes[] = new int[11];
	/**
	 * vector para decoficidar el voto
	 */
	private int infoBuenosAires[] = new int[11];
	/**
	 * vector para decoficidar el voto
	 */
	private int infoCABA[] = new int[11];
	/**
	 * vector para decoficidar el voto
	 */
	private int infoMisiones[] = new int[11];
	/**
	 * vector para decoficidar el voto
	 */
	private int infoEntreRios[] = new int[11];
	/**
	 * elemento para conectar el servidor Pusher
	 */
	private PusherUtil pusher;
	/**
	 * lista tipo camara electoral
	 */
	private CamaraElectoral camara;

	
	/**
	 * @param args argumentos
	 */
	public static void main(String[] args) {
		CamaraElectoral c = new CamaraElectoral();
		InformacionDistritos frame = new InformacionDistritos(c);
		frame.setVisible(true);
	}

	
	/**
	 * @param camara lista de camaraelectoral
	 * recibe un objeto CamaraElectoral
	 */
	public InformacionDistritos(CamaraElectoral camara) {
		this.camara=camara;
		pusher = new PusherUtil();
	
		if (!control) {
			for (int i = 0; i < infoBuenosAires.length; i++) {
				infoBuenosAires[i] = 0;
				infoCABA[i] = 0;
				infoCorrientes[i] = 0;
				infoMisiones[i] = 0;
				infoEntreRios[i] = 0;
			}
			control = true;
		}

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1011, 482);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		JPanel panel = new JPanel();

		contentPane.add(panel, BorderLayout.NORTH);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_panel.rowHeights = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		gbl_panel.columnWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
				Double.MIN_VALUE };
		gbl_panel.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
				Double.MIN_VALUE };
		panel.setLayout(gbl_panel);

		JLabel lbl = new JLabel("Distritos");
		GridBagConstraints gbc_lbl = new GridBagConstraints();
		gbc_lbl.insets = new Insets(0, 0, 5, 5);
		gbc_lbl.gridx = 1;
		gbc_lbl.gridy = 1;
		panel.add(lbl, gbc_lbl);

		JLabel lblNewLabel_6 = new JLabel("Cantidad Votantes");
		GridBagConstraints gbc_lblNewLabel_6 = new GridBagConstraints();
		gbc_lblNewLabel_6.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_6.gridx = 2;
		gbc_lblNewLabel_6.gridy = 1;
		panel.add(lblNewLabel_6, gbc_lblNewLabel_6);

		JLabel lblNewLabel = new JLabel("Total de Votos");
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 4;
		gbc_lblNewLabel.gridy = 1;
		panel.add(lblNewLabel, gbc_lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Votos en blanco");
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 6;
		gbc_lblNewLabel_1.gridy = 1;
		panel.add(lblNewLabel_1, gbc_lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Votos Validos");
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 8;
		gbc_lblNewLabel_2.gridy = 1;
		panel.add(lblNewLabel_2, gbc_lblNewLabel_2);

		JLabel lblNewLabel_7 = new JLabel("Porcenaje voto Blanco");
		GridBagConstraints gbc_lblNewLabel_7 = new GridBagConstraints();
		gbc_lblNewLabel_7.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_7.gridx = 9;
		gbc_lblNewLabel_7.gridy = 1;
		panel.add(lblNewLabel_7, gbc_lblNewLabel_7);

		JLabel lblNewLabel_8 = new JLabel("Porcentaje voto valido");
		GridBagConstraints gbc_lblNewLabel_8 = new GridBagConstraints();
		gbc_lblNewLabel_8.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_8.gridx = 10;
		gbc_lblNewLabel_8.gridy = 1;
		panel.add(lblNewLabel_8, gbc_lblNewLabel_8);

		JLabel lblNewLabel_4 = new JLabel("Listas");
		GridBagConstraints gbc_lblNewLabel_4 = new GridBagConstraints();
		gbc_lblNewLabel_4.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_4.gridx = 11;
		gbc_lblNewLabel_4.gridy = 1;
		panel.add(lblNewLabel_4, gbc_lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("Graficas");
		GridBagConstraints gbc_lblNewLabel_5 = new GridBagConstraints();
		gbc_lblNewLabel_5.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_5.gridx = 12;
		gbc_lblNewLabel_5.gridy = 1;
		panel.add(lblNewLabel_5, gbc_lblNewLabel_5);

		JSeparator separator_6 = new JSeparator();
		GridBagConstraints gbc_separator_6 = new GridBagConstraints();
		gbc_separator_6.insets = new Insets(0, 0, 5, 5);
		gbc_separator_6.gridx = 7;
		gbc_separator_6.gridy = 2;
		panel.add(separator_6, gbc_separator_6);

		JSeparator separator_5 = new JSeparator();
		GridBagConstraints gbc_separator_5 = new GridBagConstraints();
		gbc_separator_5.insets = new Insets(0, 0, 5, 5);
		gbc_separator_5.gridx = 5;
		gbc_separator_5.gridy = 3;
		panel.add(separator_5, gbc_separator_5);

		JLabel lblCorrientes = new JLabel("Corrientes");
		GridBagConstraints gbc_lblCorrientes = new GridBagConstraints();
		gbc_lblCorrientes.insets = new Insets(0, 0, 5, 5);
		gbc_lblCorrientes.gridx = 1;
		gbc_lblCorrientes.gridy = 4;
		panel.add(lblCorrientes, gbc_lblCorrientes);

		JLabel cantidadVotantesCorrientes = new JLabel(
				camara.getControlaDistrito().get(0).getPadronDistrito().size() + "");
		GridBagConstraints gbc_cantidadVotantesCorrientes = new GridBagConstraints();
		gbc_cantidadVotantesCorrientes.insets = new Insets(0, 0, 5, 5);
		gbc_cantidadVotantesCorrientes.gridx = 2;
		gbc_cantidadVotantesCorrientes.gridy = 4;
		panel.add(cantidadVotantesCorrientes, gbc_cantidadVotantesCorrientes);

		JLabel votosTotalesCorrienes = new JLabel(infoCorrientes[0] + "");
		GridBagConstraints gbc_votosTotalesCorrienes = new GridBagConstraints();
		gbc_votosTotalesCorrienes.insets = new Insets(0, 0, 5, 5);
		gbc_votosTotalesCorrienes.gridx = 4;
		gbc_votosTotalesCorrienes.gridy = 4;
		panel.add(votosTotalesCorrienes, gbc_votosTotalesCorrienes);

		JLabel votoBlancoCorrientes = new JLabel(infoCorrientes[1] + "");
		GridBagConstraints gbc_votoBlancoCorrientes = new GridBagConstraints();
		gbc_votoBlancoCorrientes.insets = new Insets(0, 0, 5, 5);
		gbc_votoBlancoCorrientes.gridx = 6;
		gbc_votoBlancoCorrientes.gridy = 4;
		panel.add(votoBlancoCorrientes, gbc_votoBlancoCorrientes);

		JLabel votoValidosCorrientes = new JLabel(infoCorrientes[2] + "");
		GridBagConstraints gbc_votoValidosCorrientes = new GridBagConstraints();
		gbc_votoValidosCorrientes.insets = new Insets(0, 0, 5, 5);
		gbc_votoValidosCorrientes.gridx = 8;
		gbc_votoValidosCorrientes.gridy = 4;
		panel.add(votoValidosCorrientes, gbc_votoValidosCorrientes);

		JButton btnListasCorrientes = new JButton("Listas Corrientes");
		btnListasCorrientes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int infoDistrito[] = infoCorrientes;
				VentanaListasDistrito v = new VentanaListasDistrito(camara.getControlaDistrito().get(0),infoDistrito,true);

			}
		});

		JLabel porcentajeBlancoCorrientes = new JLabel("0");
		GridBagConstraints gbc_porcentajeBlancoCorrientes = new GridBagConstraints();
		gbc_porcentajeBlancoCorrientes.insets = new Insets(0, 0, 5, 5);
		gbc_porcentajeBlancoCorrientes.gridx = 9;
		gbc_porcentajeBlancoCorrientes.gridy = 4;
		panel.add(porcentajeBlancoCorrientes, gbc_porcentajeBlancoCorrientes);

		JLabel porcentajeValidoCorrientes = new JLabel("0");
		GridBagConstraints gbc_porcentajeValidoCorrientes = new GridBagConstraints();
		gbc_porcentajeValidoCorrientes.insets = new Insets(0, 0, 5, 5);
		gbc_porcentajeValidoCorrientes.gridx = 10;
		gbc_porcentajeValidoCorrientes.gridy = 4;
		panel.add(porcentajeValidoCorrientes, gbc_porcentajeValidoCorrientes);
		GridBagConstraints gbc_btnListasCorrientes = new GridBagConstraints();
		gbc_btnListasCorrientes.insets = new Insets(0, 0, 5, 5);
		gbc_btnListasCorrientes.gridx = 11;
		gbc_btnListasCorrientes.gridy = 4;
		panel.add(btnListasCorrientes, gbc_btnListasCorrientes);

		JButton btnGraficaCorrientes = new JButton("Grafica");
		btnGraficaCorrientes.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int validos = Integer.parseInt(votoValidosCorrientes.getText());
				int blancos = Integer.parseInt(votoBlancoCorrientes.getText());

				GraficaDistrito grafico = new GraficaDistrito("Corrientes", "Votos validos", "votos en blanco", validos,
						blancos, true);

				int cantidad = Integer.parseInt(cantidadVotantesCorrientes.getText());
				int totales = Integer.parseInt(votosTotalesCorrienes.getText());
				GraficaDistrito grafico2 = new GraficaDistrito("Corrientes", "Votos totales", "votos realizados",
						cantidad, totales, false);
			}
		});

		GridBagConstraints gbc_btnGraficaCorrientes = new GridBagConstraints();
		gbc_btnGraficaCorrientes.insets = new Insets(0, 0, 5, 5);
		gbc_btnGraficaCorrientes.gridx = 12;
		gbc_btnGraficaCorrientes.gridy = 4;
		panel.add(btnGraficaCorrientes, gbc_btnGraficaCorrientes);

		JLabel lblBuenosAires = new JLabel("Buenos Aires");
		GridBagConstraints gbc_lblBuenosAires = new GridBagConstraints();
		gbc_lblBuenosAires.insets = new Insets(0, 0, 5, 5);
		gbc_lblBuenosAires.gridx = 1;
		gbc_lblBuenosAires.gridy = 5;
		panel.add(lblBuenosAires, gbc_lblBuenosAires);

		JLabel cantidadVotantesBuenosAires = new JLabel(
				camara.getControlaDistrito().get(1).getPadronDistrito().size() + "");
		GridBagConstraints gbc_cantidadVotantesBuenosAires = new GridBagConstraints();
		gbc_cantidadVotantesBuenosAires.insets = new Insets(0, 0, 5, 5);
		gbc_cantidadVotantesBuenosAires.gridx = 2;
		gbc_cantidadVotantesBuenosAires.gridy = 5;
		panel.add(cantidadVotantesBuenosAires, gbc_cantidadVotantesBuenosAires);

		JLabel votosTotalesBuenosAires = new JLabel(infoBuenosAires[0] + "");
		GridBagConstraints gbc_votosTotalesBuenosAires = new GridBagConstraints();
		gbc_votosTotalesBuenosAires.insets = new Insets(0, 0, 5, 5);
		gbc_votosTotalesBuenosAires.gridx = 4;
		gbc_votosTotalesBuenosAires.gridy = 5;
		panel.add(votosTotalesBuenosAires, gbc_votosTotalesBuenosAires);

		JLabel votoBlancoBuenosAires = new JLabel(infoBuenosAires[1] + "");
		GridBagConstraints gbc_votoBlancoBuenosAires = new GridBagConstraints();
		gbc_votoBlancoBuenosAires.insets = new Insets(0, 0, 5, 5);
		gbc_votoBlancoBuenosAires.gridx = 6;
		gbc_votoBlancoBuenosAires.gridy = 5;
		panel.add(votoBlancoBuenosAires, gbc_votoBlancoBuenosAires);

		JLabel votoValidosBuenosAires = new JLabel(infoBuenosAires[2] + "");
		GridBagConstraints gbc_votoValidosBuenosAires = new GridBagConstraints();
		gbc_votoValidosBuenosAires.insets = new Insets(0, 0, 5, 5);
		gbc_votoValidosBuenosAires.gridx = 8;
		gbc_votoValidosBuenosAires.gridy = 5;
		panel.add(votoValidosBuenosAires, gbc_votoValidosBuenosAires);

		JButton btnListasBuenosAires = new JButton("Listas Buenos Aires");
		btnListasBuenosAires.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int infoDistrito[] = infoBuenosAires;
				VentanaListasDistrito v = new VentanaListasDistrito(camara.getControlaDistrito().get(1),infoDistrito,false);
			}
		});

		JLabel porcentajeBlancoBuenosAires = new JLabel("0");
		GridBagConstraints gbc_porcentajeBlancoBuenosAires = new GridBagConstraints();
		gbc_porcentajeBlancoBuenosAires.insets = new Insets(0, 0, 5, 5);
		gbc_porcentajeBlancoBuenosAires.gridx = 9;
		gbc_porcentajeBlancoBuenosAires.gridy = 5;
		panel.add(porcentajeBlancoBuenosAires, gbc_porcentajeBlancoBuenosAires);

		JLabel porcentajeValidoBuenosAires = new JLabel("0");
		GridBagConstraints gbc_porcentajeValidoBuenosAires = new GridBagConstraints();
		gbc_porcentajeValidoBuenosAires.insets = new Insets(0, 0, 5, 5);
		gbc_porcentajeValidoBuenosAires.gridx = 10;
		gbc_porcentajeValidoBuenosAires.gridy = 5;
		panel.add(porcentajeValidoBuenosAires, gbc_porcentajeValidoBuenosAires);
		GridBagConstraints gbc_btnListasBuenosAires = new GridBagConstraints();
		gbc_btnListasBuenosAires.insets = new Insets(0, 0, 5, 5);
		gbc_btnListasBuenosAires.gridx = 11;
		gbc_btnListasBuenosAires.gridy = 5;
		panel.add(btnListasBuenosAires, gbc_btnListasBuenosAires);

		JButton btnGraficaBuenosAires = new JButton("Grafica");
		GridBagConstraints gbc_btnGraficaBuenosAires = new GridBagConstraints();
		gbc_btnGraficaBuenosAires.insets = new Insets(0, 0, 5, 5);
		gbc_btnGraficaBuenosAires.gridx = 12;
		gbc_btnGraficaBuenosAires.gridy = 5;
		btnGraficaBuenosAires.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int validos = Integer.parseInt(votoValidosBuenosAires.getText());
				int blancos = Integer.parseInt(votoBlancoBuenosAires.getText());

				GraficaDistrito grafico = new GraficaDistrito("Buenos Aires", "Votos validos", "votos en blanco",
						validos, blancos, true);

				int cantidad = Integer.parseInt(cantidadVotantesBuenosAires.getText());
				int totales = Integer.parseInt(votosTotalesBuenosAires.getText());
				GraficaDistrito grafico2 = new GraficaDistrito("Buenos Aires", "Votos totales", "votos realizados",
						cantidad, totales, false);
				
			}
		});
		panel.add(btnGraficaBuenosAires, gbc_btnGraficaBuenosAires);

		JSeparator separator_4 = new JSeparator();
		GridBagConstraints gbc_separator_4 = new GridBagConstraints();
		gbc_separator_4.insets = new Insets(0, 0, 5, 5);
		gbc_separator_4.gridx = 1;
		gbc_separator_4.gridy = 6;
		panel.add(separator_4, gbc_separator_4);

		JLabel lblEntreRios = new JLabel("Entre Rios");
		GridBagConstraints gbc_lblEntreRios = new GridBagConstraints();
		gbc_lblEntreRios.insets = new Insets(0, 0, 5, 5);
		gbc_lblEntreRios.gridx = 1;
		gbc_lblEntreRios.gridy = 7;
		panel.add(lblEntreRios, gbc_lblEntreRios);

		JLabel cantidadVotantesEntreRios = new JLabel(
				camara.getControlaDistrito().get(4).getPadronDistrito().size() + "");
		GridBagConstraints gbc_cantidadVotantesEntreRios = new GridBagConstraints();
		gbc_cantidadVotantesEntreRios.insets = new Insets(0, 0, 5, 5);
		gbc_cantidadVotantesEntreRios.gridx = 2;
		gbc_cantidadVotantesEntreRios.gridy = 7;
		panel.add(cantidadVotantesEntreRios, gbc_cantidadVotantesEntreRios);

		JLabel votosTotalesEntreRios = new JLabel(infoEntreRios[0] + "");
		GridBagConstraints gbc_votosTotalesEntreRios = new GridBagConstraints();
		gbc_votosTotalesEntreRios.insets = new Insets(0, 0, 5, 5);
		gbc_votosTotalesEntreRios.gridx = 4;
		gbc_votosTotalesEntreRios.gridy = 7;
		panel.add(votosTotalesEntreRios, gbc_votosTotalesEntreRios);

		JLabel votoBlancoEntreRios = new JLabel(infoEntreRios[1] + "");
		GridBagConstraints gbc_votoBlancoEntreRios = new GridBagConstraints();
		gbc_votoBlancoEntreRios.insets = new Insets(0, 0, 5, 5);
		gbc_votoBlancoEntreRios.gridx = 6;
		gbc_votoBlancoEntreRios.gridy = 7;
		panel.add(votoBlancoEntreRios, gbc_votoBlancoEntreRios);

		JLabel votoValidosEntreRios = new JLabel(infoEntreRios[2] + "");
		GridBagConstraints gbc_votoValidosEntreRios = new GridBagConstraints();
		gbc_votoValidosEntreRios.insets = new Insets(0, 0, 5, 5);
		gbc_votoValidosEntreRios.gridx = 8;
		gbc_votoValidosEntreRios.gridy = 7;
		panel.add(votoValidosEntreRios, gbc_votoValidosEntreRios);

		JButton btnListasEntreRios = new JButton("Listas Entre Rios");
		btnListasEntreRios.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int infoDistrito[] = infoEntreRios;
				VentanaListasDistrito v = new VentanaListasDistrito(camara.getControlaDistrito().get(4),infoDistrito,false);
				
			}
		});

		JLabel porcentajeBlancoEntreRios = new JLabel("0");
		GridBagConstraints gbc_porcentajeBlancoEntreRios = new GridBagConstraints();
		gbc_porcentajeBlancoEntreRios.insets = new Insets(0, 0, 5, 5);
		gbc_porcentajeBlancoEntreRios.gridx = 9;
		gbc_porcentajeBlancoEntreRios.gridy = 7;
		panel.add(porcentajeBlancoEntreRios, gbc_porcentajeBlancoEntreRios);

		JLabel porcentajeValidoEntreRios = new JLabel("0");
		GridBagConstraints gbc_porcentajeValidoEntreRios = new GridBagConstraints();
		gbc_porcentajeValidoEntreRios.insets = new Insets(0, 0, 5, 5);
		gbc_porcentajeValidoEntreRios.gridx = 10;
		gbc_porcentajeValidoEntreRios.gridy = 7;
		panel.add(porcentajeValidoEntreRios, gbc_porcentajeValidoEntreRios);
		GridBagConstraints gbc_btnListasEntreRios = new GridBagConstraints();
		gbc_btnListasEntreRios.insets = new Insets(0, 0, 5, 5);
		gbc_btnListasEntreRios.gridx = 11;
		gbc_btnListasEntreRios.gridy = 7;
		panel.add(btnListasEntreRios, gbc_btnListasEntreRios);

		JButton btnGraficaEntreRios = new JButton("Grafica");
		GridBagConstraints gbc_btnGraficaEntreRios = new GridBagConstraints();
		gbc_btnGraficaEntreRios.insets = new Insets(0, 0, 5, 5);
		gbc_btnGraficaEntreRios.gridx = 12;
		gbc_btnGraficaEntreRios.gridy = 7;
		panel.add(btnGraficaEntreRios, gbc_btnGraficaEntreRios);

		btnGraficaEntreRios.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int validos = Integer.parseInt(votoValidosEntreRios.getText());
				int blancos = Integer.parseInt(votoBlancoEntreRios.getText());

				GraficaDistrito grafico = new GraficaDistrito("Entre Rios", "Votos validos", "votos en blanco", validos,
						blancos, true);

				int cantidad = Integer.parseInt(cantidadVotantesEntreRios.getText());
				int totales = Integer.parseInt(votosTotalesEntreRios.getText());
				GraficaDistrito grafico2 = new GraficaDistrito("Entre Rios", "Votos totales", "votos realizados",
						cantidad, totales, false);
			}
		});

		JSeparator separator_2 = new JSeparator();
		GridBagConstraints gbc_separator_2 = new GridBagConstraints();
		gbc_separator_2.insets = new Insets(0, 0, 5, 5);
		gbc_separator_2.gridx = 3;
		gbc_separator_2.gridy = 8;
		panel.add(separator_2, gbc_separator_2);

		JLabel lblMisiones = new JLabel("Misiones");
		GridBagConstraints gbc_lblMisiones = new GridBagConstraints();
		gbc_lblMisiones.insets = new Insets(0, 0, 5, 5);
		gbc_lblMisiones.gridx = 1;
		gbc_lblMisiones.gridy = 9;
		panel.add(lblMisiones, gbc_lblMisiones);

		JLabel cantidadVotantesMisiones = new JLabel(
				camara.getControlaDistrito().get(3).getPadronDistrito().size() + "");
		GridBagConstraints gbc_cantidadVotantesMisiones = new GridBagConstraints();
		gbc_cantidadVotantesMisiones.insets = new Insets(0, 0, 5, 5);
		gbc_cantidadVotantesMisiones.gridx = 2;
		gbc_cantidadVotantesMisiones.gridy = 9;
		panel.add(cantidadVotantesMisiones, gbc_cantidadVotantesMisiones);

		JLabel votosTotalesMisiones = new JLabel(infoMisiones[0] + "");
		GridBagConstraints gbc_votosTotalesMisiones = new GridBagConstraints();
		gbc_votosTotalesMisiones.insets = new Insets(0, 0, 5, 5);
		gbc_votosTotalesMisiones.gridx = 4;
		gbc_votosTotalesMisiones.gridy = 9;
		panel.add(votosTotalesMisiones, gbc_votosTotalesMisiones);

		JLabel votoBlancoMisiones = new JLabel(infoMisiones[1] + "");
		GridBagConstraints gbc_votoBlancoMisiones = new GridBagConstraints();
		gbc_votoBlancoMisiones.insets = new Insets(0, 0, 5, 5);
		gbc_votoBlancoMisiones.gridx = 6;
		gbc_votoBlancoMisiones.gridy = 9;
		panel.add(votoBlancoMisiones, gbc_votoBlancoMisiones);

		JLabel votoValidosMisiones = new JLabel(infoMisiones[2] + "");
		GridBagConstraints gbc_votoValidosMisiones = new GridBagConstraints();
		gbc_votoValidosMisiones.insets = new Insets(0, 0, 5, 5);
		gbc_votoValidosMisiones.gridx = 8;
		gbc_votoValidosMisiones.gridy = 9;
		panel.add(votoValidosMisiones, gbc_votoValidosMisiones);

		JButton btnListasMisiones = new JButton("Listas Misiones");
		btnListasMisiones.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int infoDistrito[] = infoMisiones;
				VentanaListasDistrito v = new VentanaListasDistrito(camara.getControlaDistrito().get(3),infoDistrito,false);
			}
		});

		JLabel porcentajeBlancoMisiones = new JLabel("0");
		GridBagConstraints gbc_porcentajeBlancoMisiones = new GridBagConstraints();
		gbc_porcentajeBlancoMisiones.insets = new Insets(0, 0, 5, 5);
		gbc_porcentajeBlancoMisiones.gridx = 9;
		gbc_porcentajeBlancoMisiones.gridy = 9;
		panel.add(porcentajeBlancoMisiones, gbc_porcentajeBlancoMisiones);

		JLabel porcentajeValidoMisiones = new JLabel("0");
		GridBagConstraints gbc_porcentajeValidoMisiones = new GridBagConstraints();
		gbc_porcentajeValidoMisiones.insets = new Insets(0, 0, 5, 5);
		gbc_porcentajeValidoMisiones.gridx = 10;
		gbc_porcentajeValidoMisiones.gridy = 9;
		panel.add(porcentajeValidoMisiones, gbc_porcentajeValidoMisiones);
		GridBagConstraints gbc_btnListasMisiones = new GridBagConstraints();
		gbc_btnListasMisiones.insets = new Insets(0, 0, 5, 5);
		gbc_btnListasMisiones.gridx = 11;
		gbc_btnListasMisiones.gridy = 9;
		panel.add(btnListasMisiones, gbc_btnListasMisiones);

		JButton btnGraficaMisiones = new JButton("Grafica");
		GridBagConstraints gbc_btnGraficaMisiones = new GridBagConstraints();
		gbc_btnGraficaMisiones.insets = new Insets(0, 0, 5, 5);
		gbc_btnGraficaMisiones.gridx = 12;
		gbc_btnGraficaMisiones.gridy = 9;
		panel.add(btnGraficaMisiones, gbc_btnGraficaMisiones);

		btnGraficaMisiones.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int validos = Integer.parseInt(votoValidosMisiones.getText());
				int blancos = Integer.parseInt(votoBlancoMisiones.getText());

				GraficaDistrito grafico = new GraficaDistrito("Misiones", "Votos validos", "votos en blanco", validos,
						blancos, true);

				int cantidad = Integer.parseInt(cantidadVotantesMisiones.getText());
				int totales = Integer.parseInt(votosTotalesMisiones.getText());
				GraficaDistrito grafico2 = new GraficaDistrito("Misiones", "Votos totales", "votos realizados",
						cantidad, totales, false);
			}
		});

		JSeparator separator_3 = new JSeparator();
		GridBagConstraints gbc_separator_3 = new GridBagConstraints();
		gbc_separator_3.insets = new Insets(0, 0, 5, 5);
		gbc_separator_3.gridx = 1;
		gbc_separator_3.gridy = 10;
		panel.add(separator_3, gbc_separator_3);

		JLabel lblNewLabel_3 = new JLabel("CABA");
		GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
		gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_3.gridx = 1;
		gbc_lblNewLabel_3.gridy = 11;
		panel.add(lblNewLabel_3, gbc_lblNewLabel_3);

		JLabel cantidadVotantesCABA = new JLabel(camara.getControlaDistrito().get(2).getPadronDistrito().size() + "");
		GridBagConstraints gbc_cantidadVotantesCABA = new GridBagConstraints();
		gbc_cantidadVotantesCABA.insets = new Insets(0, 0, 5, 5);
		gbc_cantidadVotantesCABA.gridx = 2;
		gbc_cantidadVotantesCABA.gridy = 11;
		panel.add(cantidadVotantesCABA, gbc_cantidadVotantesCABA);

		JLabel votosTotalesCABA = new JLabel(infoCABA[0] + "");
		GridBagConstraints gbc_votosTotalesCABA = new GridBagConstraints();
		gbc_votosTotalesCABA.insets = new Insets(0, 0, 5, 5);
		gbc_votosTotalesCABA.gridx = 4;
		gbc_votosTotalesCABA.gridy = 11;
		panel.add(votosTotalesCABA, gbc_votosTotalesCABA);

		JLabel votoBlancoCABA = new JLabel(infoCABA[1] + "");
		GridBagConstraints gbc_votoBlancoCABA = new GridBagConstraints();
		gbc_votoBlancoCABA.insets = new Insets(0, 0, 5, 5);
		gbc_votoBlancoCABA.gridx = 6;
		gbc_votoBlancoCABA.gridy = 11;
		panel.add(votoBlancoCABA, gbc_votoBlancoCABA);

		JLabel votoValidosCABA = new JLabel(infoCABA[2] + "");
		GridBagConstraints gbc_votoValidosCABA = new GridBagConstraints();
		gbc_votoValidosCABA.insets = new Insets(0, 0, 5, 5);
		gbc_votoValidosCABA.gridx = 8;
		gbc_votoValidosCABA.gridy = 11;
		panel.add(votoValidosCABA, gbc_votoValidosCABA);

		JButton btnListasCaba = new JButton("Listas CABA");
		btnListasCaba.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int infoDistrito[] = infoCABA;
				VentanaListasDistrito v = new VentanaListasDistrito(camara.getControlaDistrito().get(2),infoDistrito,false);				
				
			}
		});

		JLabel porcentajeBlancoCABA = new JLabel("0");
		GridBagConstraints gbc_porcentajeBlancoCABA = new GridBagConstraints();
		gbc_porcentajeBlancoCABA.insets = new Insets(0, 0, 5, 5);
		gbc_porcentajeBlancoCABA.gridx = 9;
		gbc_porcentajeBlancoCABA.gridy = 11;
		panel.add(porcentajeBlancoCABA, gbc_porcentajeBlancoCABA);

		JLabel porcentajeValidoCABA = new JLabel("0");
		GridBagConstraints gbc_porcentajeValidoCABA = new GridBagConstraints();
		gbc_porcentajeValidoCABA.insets = new Insets(0, 0, 5, 5);
		gbc_porcentajeValidoCABA.gridx = 10;
		gbc_porcentajeValidoCABA.gridy = 11;
		panel.add(porcentajeValidoCABA, gbc_porcentajeValidoCABA);
		btnListasCaba.setHorizontalAlignment(SwingConstants.RIGHT);
		GridBagConstraints gbc_btnListasCaba = new GridBagConstraints();
		gbc_btnListasCaba.insets = new Insets(0, 0, 5, 5);
		gbc_btnListasCaba.gridx = 11;
		gbc_btnListasCaba.gridy = 11;
		panel.add(btnListasCaba, gbc_btnListasCaba);

		JButton btnGraficaCABA = new JButton("Grafica");
		GridBagConstraints gbc_btnGraficaCABA = new GridBagConstraints();
		gbc_btnGraficaCABA.insets = new Insets(0, 0, 5, 5);
		gbc_btnGraficaCABA.gridx = 12;
		gbc_btnGraficaCABA.gridy = 11;
		panel.add(btnGraficaCABA, gbc_btnGraficaCABA);

		btnGraficaCABA.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int validos = Integer.parseInt(votoValidosCABA.getText());
				int blancos = Integer.parseInt(votoBlancoCABA.getText());

				GraficaDistrito grafico = new GraficaDistrito("CABA", "Votos validos", "votos en blanco", validos,
						blancos, true);

				int cantidad = Integer.parseInt(cantidadVotantesCABA.getText());
				int totales = Integer.parseInt(votosTotalesCABA.getText());
				GraficaDistrito grafico2 = new GraficaDistrito("CABA", "Votos totales", "votos realizados", cantidad,
						totales, false);
			}
		});

		btnActualizar = new JButton("Actualizar");
		btnActualizar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				if (!PusherUtil.getListaCodigoVoto().isEmpty()) {
					ListaCodigoVoto = PusherUtil.getListaCodigoVoto();
					PusherUtil.LimpiarVotosViejos();

					for (String codigo : ListaCodigoVoto) { // [DISTRITO],[DIPUTADO],[SENADOR]

						switch (codigo.charAt(0)) {// filtro distrito 1-5
						case '1': {

							switch (codigo.charAt(1)) {// Diputado

							case '0': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.BLANCO);
									infoCorrientes[0] += 1;// votorealizado totales
									infoCorrientes[1] += 1;// voto blanco
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[2] += 1;// voto valido
									infoCorrientes[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[2] += 1;// voto valido
									infoCorrientes[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[2] += 1;// voto valido
									infoCorrientes[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[2] += 1;// voto valido
									infoCorrientes[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores

								break;
							} // cierre switch diptado 0

							case '1': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;
									infoCorrientes[2] += 1;
									infoCorrientes[3] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[2] += 1;// valido
									infoCorrientes[3] += 1;// voto kista 1 disputado
									infoCorrientes[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[2] += 1;// valido
									infoCorrientes[3] += 1;
									infoCorrientes[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[2] += 1;// valido
									infoCorrientes[3] += 1;// voto valido
									infoCorrientes[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[2] += 1;// valido
									infoCorrientes[3] += 1;// voto valido
									infoCorrientes[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores
								break;
							} // cierre switch diptado 1
							case '2': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;
									infoCorrientes[2] += 1;// valido
									infoCorrientes[5] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[2] += 1;// valido
									infoCorrientes[5] += 1;// voto valido
									infoCorrientes[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[5] += 1;// voto valido
									infoCorrientes[2] += 1;// valido
									infoCorrientes[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[5] += 1;// voto valido
									infoCorrientes[2] += 1;// valido
									infoCorrientes[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[5] += 1;// voto valido
									infoCorrientes[2] += 1;// valido
									infoCorrientes[10] += 1;// voto lista senador 4
									break;
								}

								}// cierre senadores

								break;
							} // cierre switch diptado 2

							case '3': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;
									infoCorrientes[7] += 1;
									infoCorrientes[2] += 1;// valido
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[7] += 1;// voto valido
									infoCorrientes[4] += 1;// voto lista senador 1
									infoCorrientes[2] += 1;// valido
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[7] += 1;// voto valido
									infoCorrientes[6] += 1;// voto lista senador 2
									infoCorrientes[2] += 1;// valido
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[7] += 1;// voto valido
									infoCorrientes[8] += 1;// voto lista senador 3
									infoCorrientes[2] += 1;// valido
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[7] += 1;// voto valido
									infoCorrientes[10] += 1;// voto lista senador 4
									infoCorrientes[2] += 1;// valido
									break;
								}

								}// cieere senadores

								break;
							} // cierre switch diptado 3
							case '4': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;
									infoCorrientes[9] += 1;
									infoCorrientes[2] += 1;// valido
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[9] += 1;// voto valido
									infoCorrientes[4] += 1;// voto lista senador 1
									infoCorrientes[2] += 1;// valido
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[9] += 1;// voto valido
									infoCorrientes[6] += 1;// voto lista senador 2
									infoCorrientes[2] += 1;// valido
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[9] += 1;// voto valido
									infoCorrientes[8] += 1;// voto lista senador 3
									infoCorrientes[2] += 1;// valido
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCorrientes[0] += 1;// voto realizado
									infoCorrientes[9] += 1;// voto valido
									infoCorrientes[10] += 1;// voto lista senador 4
									infoCorrientes[2] += 1;// valido
									break;
								} // ------------------------------------------------------cerramos distrito

								}// cieere senadores

								break;
							} // cierre switch diptado 4

							}// cierre switc diputado

							break;
						} // cierre distrito 1

						case '2': {

							switch (codigo.charAt(1)) {// Diputado

							case '0': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.BLANCO);
									infoBuenosAires[0] += 1;
									infoBuenosAires[1] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;// voto valido
									infoBuenosAires[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;// voto valido
									infoBuenosAires[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;// voto valido
									infoBuenosAires[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;// voto valido
									infoBuenosAires[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores

								break;
							} // cierre switch diptado 0

							case '1': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;
									infoBuenosAires[2] += 1;
									infoBuenosAires[3] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;
									infoBuenosAires[3] += 1;// voto valido
									infoBuenosAires[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;
									infoBuenosAires[3] += 1;// voto valido
									infoBuenosAires[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;
									infoBuenosAires[3] += 1;// voto valido
									infoBuenosAires[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;
									infoBuenosAires[3] += 1;// voto valido
									infoBuenosAires[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores
								break;
							} // cierre switch diptado 1
							case '2': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;
									infoBuenosAires[2] += 1;
									infoBuenosAires[5] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;
									infoBuenosAires[5] += 1;// voto valido
									infoBuenosAires[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;
									infoBuenosAires[5] += 1;// voto valido
									infoBuenosAires[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;
									infoBuenosAires[5] += 1;// voto valido
									infoBuenosAires[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;
									infoBuenosAires[5] += 1;// voto valido
									infoBuenosAires[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores

								break;
							} // cierre switch diptado 2

							case '3': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;
									infoBuenosAires[2] += 1;
									infoBuenosAires[7] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;
									infoBuenosAires[7] += 1;// voto valido
									infoBuenosAires[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;
									infoBuenosAires[7] += 1;// voto valido
									infoBuenosAires[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;
									infoBuenosAires[7] += 1;// voto valido
									infoBuenosAires[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;
									infoBuenosAires[7] += 1;// voto valido
									infoBuenosAires[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores

								break;
							} // cierre switch diptado 3
							case '4': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;
									infoBuenosAires[2] += 1;
									infoBuenosAires[9] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;
									infoBuenosAires[4] += 1;// voto lista senador 1
									infoBuenosAires[9] += 1;// voto valido
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;
									infoBuenosAires[6] += 1;// voto lista senador 2
									infoBuenosAires[9] += 1;// voto valido
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;
									infoBuenosAires[8] += 1;// voto lista senador 3
									infoBuenosAires[9] += 1;// voto valido
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoBuenosAires[0] += 1;// voto realizado
									infoBuenosAires[2] += 1;
									infoBuenosAires[9] += 1;// voto valido
									infoBuenosAires[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores

								break;
							} // cierre switch diptado 4

							}// cierre switc diputado

							break;
						} // cierre distrito 2
						case '3': {

							switch (codigo.charAt(1)) {// Diputado

							case '0': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.BLANCO);
									infoCABA[0] += 1;
									infoCABA[1] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;// voto valido
									infoCABA[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;// voto valido
									infoCABA[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;// voto valido
									infoCABA[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;// voto valido
									infoCABA[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores

								break;
							} // cierre switch diptado 0

							case '1': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;
									infoCABA[2] += 1;
									infoCABA[3] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;
									infoCABA[3] += 1;// voto valido
									infoCABA[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;
									infoCABA[3] += 1;// voto valido
									infoCABA[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;
									infoCABA[3] += 1;// voto valido
									infoCABA[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;
									infoCABA[3] += 1;// voto valido
									infoCABA[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores
								break;
							} // cierre switch diptado 1
							case '2': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;
									infoCABA[2] += 1;
									infoCABA[5] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;
									infoCABA[5] += 1;// voto valido
									infoCABA[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;
									infoCABA[5] += 1;// voto valido
									infoCABA[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;
									infoCABA[5] += 1;// voto valido
									infoCABA[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;
									infoCABA[5] += 1;// voto valido
									infoCABA[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores

								break;
							} // cierre switch diptado 2

							case '3': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;
									infoCABA[2] += 1;
									infoCABA[7] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;
									infoCABA[7] += 1;// voto valido
									infoCABA[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;
									infoCABA[7] += 1;// voto valido
									infoCABA[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;
									infoCABA[7] += 1;// voto valido
									infoCABA[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;
									infoCABA[7] += 1;// voto valido
									infoCABA[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores

								break;
							} // cierre switch diptado 3
							case '4': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;
									infoCABA[2] += 1;
									infoCABA[9] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;
									infoCABA[4] += 1;// voto lista senador 1
									infoCABA[9] += 1;// voto valido
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;
									infoCABA[6] += 1;// voto lista senador 2
									infoCABA[9] += 1;// voto valido
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;
									infoCABA[8] += 1;// voto lista senador 3
									infoCABA[9] += 1;// voto valido
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoCABA[0] += 1;// voto realizado
									infoCABA[2] += 1;
									infoCABA[9] += 1;// voto valido
									infoCABA[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores

								break;
							} // cierre switch diptado 4

							}// cierre switc diputado

							break;
						} // cierre distrito 3
						case '4': {// ************************************************************************************************************
							switch (codigo.charAt(1)) {// Diputado

							case '0': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.BLANCO);
									infoMisiones[0] += 1;
									infoMisiones[1] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;// voto valido
									infoMisiones[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;// voto valido
									infoMisiones[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;// voto valido
									infoMisiones[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;// voto valido
									infoMisiones[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores

								break;
							} // cierre switch diptado 0

							case '1': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;
									infoMisiones[2] += 1;
									infoMisiones[3] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;
									infoMisiones[3] += 1;// voto valido
									infoMisiones[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;
									infoMisiones[3] += 1;// voto valido
									infoMisiones[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;
									infoMisiones[3] += 1;// voto valido
									infoMisiones[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;
									infoMisiones[3] += 1;// voto valido
									infoMisiones[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores
								break;
							} // cierre switch diptado 1
							case '2': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;
									infoMisiones[2] += 1;
									infoMisiones[5] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;
									infoMisiones[5] += 1;// voto valido
									infoMisiones[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;
									infoMisiones[5] += 1;// voto valido
									infoMisiones[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;
									infoMisiones[5] += 1;// voto valido
									infoMisiones[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;
									infoMisiones[5] += 1;// voto valido
									infoMisiones[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores

								break;
							} // cierre switch diptado 2

							case '3': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;
									infoMisiones[2] += 1;
									infoMisiones[7] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;
									infoMisiones[7] += 1;// voto valido
									infoMisiones[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;
									infoMisiones[7] += 1;// voto valido
									infoMisiones[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;
									infoMisiones[7] += 1;// voto valido
									infoMisiones[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;
									infoMisiones[7] += 1;// voto valido
									infoMisiones[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores

								break;
							} // cierre switch diptado 3
							case '4': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;
									infoMisiones[2] += 1;
									infoMisiones[9] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;
									infoMisiones[4] += 1;// voto lista senador 1
									infoMisiones[9] += 1;// voto valido
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;
									infoMisiones[6] += 1;// voto lista senador 2
									infoMisiones[9] += 1;// voto valido
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;
									infoMisiones[8] += 1;// voto lista senador 3
									infoMisiones[9] += 1;// voto valido
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoMisiones[0] += 1;// voto realizado
									infoMisiones[2] += 1;
									infoMisiones[9] += 1;// voto valido
									infoMisiones[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores

								break;
							} // cierre switch diptado 4

							}// cierre switc diputado

							break;
						} // cierre distrito 4
						case '5': {

							switch (codigo.charAt(1)) {// Diputado

							case '0': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.BLANCO);
									infoEntreRios[0] += 1;
									infoEntreRios[1] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;// voto valido
									infoEntreRios[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;// voto valido
									infoEntreRios[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;// voto valido
									infoEntreRios[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;// voto valido
									infoEntreRios[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores

								break;
							} // cierre switch diptado 0

							case '1': {
								setVoto(codigo,CaracteristicaVoto.VALIDO);
								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;
									infoEntreRios[2] += 1;
									infoEntreRios[3] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;
									infoEntreRios[3] += 1;// voto valido
									infoEntreRios[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;
									infoEntreRios[3] += 1;// voto valido
									infoEntreRios[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;
									infoEntreRios[3] += 1;// voto valido
									infoEntreRios[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;
									infoEntreRios[3] += 1;// voto valido
									infoEntreRios[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores
								break;
							} // cierre switch diptado 1
							case '2': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;
									infoEntreRios[2] += 1;
									infoEntreRios[5] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;
									infoEntreRios[5] += 1;// voto valido
									infoEntreRios[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;
									infoEntreRios[5] += 1;// voto valido
									infoEntreRios[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;
									infoEntreRios[5] += 1;// voto valido
									infoEntreRios[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;
									infoEntreRios[5] += 1;// voto valido
									infoEntreRios[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores

								break;
							} // cierre switch diptado 2

							case '3': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;
									infoEntreRios[2] += 1;
									infoEntreRios[7] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;
									infoEntreRios[7] += 1;// voto valido
									infoEntreRios[4] += 1;// voto lista senador 1
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;
									infoEntreRios[7] += 1;// voto valido
									infoEntreRios[6] += 1;// voto lista senador 2
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;
									infoEntreRios[7] += 1;// voto valido
									infoEntreRios[8] += 1;// voto lista senador 3
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;
									infoEntreRios[7] += 1;// voto valido
									infoEntreRios[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores

								break;
							} // cierre switch diptado 3
							case '4': {

								switch (codigo.charAt(2)) {// Senador
								case '0': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;
									infoEntreRios[2] += 1;
									infoEntreRios[9] += 1;
									break;
								}
								case '1': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;
									infoEntreRios[4] += 1;// voto lista senador 1
									infoEntreRios[9] += 1;// voto valido
									break;
								}
								case '2': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;
									infoEntreRios[6] += 1;// voto lista senador 2
									infoEntreRios[9] += 1;// voto valido
									break;
								}
								case '3': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;
									infoEntreRios[8] += 1;// voto lista senador 3
									infoEntreRios[9] += 1;// voto valido
									break;
								}
								case '4': {
									setVoto(codigo,CaracteristicaVoto.VALIDO);
									infoEntreRios[0] += 1;// voto realizado
									infoEntreRios[2] += 1;
									infoEntreRios[9] += 1;// voto valido
									infoEntreRios[10] += 1;// voto lista senador 4
									break;
								}

								}// cieere senadores

								break;
							} // cierre switch diptado 4

							}

							break;
						} // cierre distrito 5

						}// cierre sswitch Distrtito

					} // cierrer for

					votosTotalesCorrienes.setText(infoCorrientes[0] + "");
					votoBlancoCorrientes.setText(infoCorrientes[1] + "");
					votoValidosCorrientes.setText(infoCorrientes[2] + "");

					votosTotalesBuenosAires.setText(infoBuenosAires[0] + "");
					votoBlancoBuenosAires.setText(infoBuenosAires[1] + "");
					votoValidosBuenosAires.setText(infoBuenosAires[2] + "");

					votosTotalesEntreRios.setText(infoEntreRios[0] + "");
					votoBlancoEntreRios.setText(infoEntreRios[1] + "");
					votoValidosEntreRios.setText(infoEntreRios[2] + "");

					votosTotalesMisiones.setText(infoMisiones[0] + "");
					votoBlancoMisiones.setText(infoMisiones[1] + "");
					votoValidosMisiones.setText(infoMisiones[2] + "");

					votosTotalesCABA.setText(infoCABA[0] + "");
					votoBlancoCABA.setText(infoCABA[1] + "");
					votoValidosCABA.setText(infoCABA[2] + "");

					ListaCodigoVoto = new ArrayList<>();
				} else {
					JOptionPane.showMessageDialog(null, "No hay datos nuevos");
				}

				porcentajeBlancoCorrientes.setText(camara.getControlaDistrito().get(0).porcentajeVotosBlancos() + " %");
				porcentajeBlancoBuenosAires.setText(camara.getControlaDistrito().get(1).porcentajeVotosBlancos() + " %");
				porcentajeBlancoCABA.setText(camara.getControlaDistrito().get(2).porcentajeVotosBlancos() + " %");
				porcentajeBlancoMisiones.setText(camara.getControlaDistrito().get(3).porcentajeVotosBlancos() + " %");
				porcentajeBlancoEntreRios.setText(camara.getControlaDistrito().get(4).porcentajeVotosBlancos() + " %");

				porcentajeValidoCorrientes.setText(camara.getControlaDistrito().get(0).porcentajeVotosValidos() + " %");
				porcentajeValidoBuenosAires
						.setText(camara.getControlaDistrito().get(1).porcentajeVotosValidos() + " %");
				porcentajeValidoCABA.setText(camara.getControlaDistrito().get(2).porcentajeVotosValidos() + " %");
				porcentajeValidoMisiones.setText(camara.getControlaDistrito().get(3).porcentajeVotosValidos() + " %");
				porcentajeValidoEntreRios.setText(camara.getControlaDistrito().get(4).porcentajeVotosValidos() + " %");

				
				
			}// cierre action performed
		});// cierre action listener

		JPanel laminaBoton = new JPanel();
		laminaBoton.add(btnActualizar);
		porcentajeBlancoCorrientes.setText(0 + " %");
		porcentajeBlancoBuenosAires.setText(0 + " %");
		porcentajeBlancoCABA.setText(0 + " %");
		porcentajeBlancoMisiones.setText(0 + " %");
		porcentajeBlancoEntreRios.setText(0 + " %");  

		porcentajeValidoCorrientes.setText(0 + " %");
		porcentajeValidoBuenosAires.setText(0 + " %");
		porcentajeValidoCABA.setText(0 + " %");
		porcentajeValidoMisiones.setText(0 + " %");
		porcentajeValidoEntreRios.setText(0 + " %");
		
		contentPane.add(laminaBoton, BorderLayout.SOUTH);
		
		setResizable(false);
		setLocationRelativeTo(null);
		
		
	}
	
	/**
	 * @param codigovotacion codigo interno
	 * @param c tipo de voto, puede ser Blanco o Valido
	 */
	private void setVoto(String codigovotacion,CaracteristicaVoto c) {
		int codigo= Integer.parseInt(codigovotacion.substring(3));
		
		for (Distrito distrito : camara.getControlaDistrito()) {
			
			for (Seccion seccion : distrito.getSecciones()) {
				for (Circuito circuito : seccion.getCircuito()) {
					for (MesaElectoral mesa : circuito.getMesas()) {
						if(codigo==mesa.getId()) {
							mesa.addVoto(new Voto(c));
							return;
						}
					}
				}
			}
		}
//			
//		
	}
	
}