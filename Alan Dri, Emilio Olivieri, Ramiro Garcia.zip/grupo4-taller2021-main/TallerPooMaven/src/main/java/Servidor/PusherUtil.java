package Servidor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.pusher.client.Pusher;
import com.pusher.client.PusherOptions;
import com.pusher.client.channel.Channel;
import com.pusher.client.channel.PusherEvent;
import com.pusher.client.channel.SubscriptionEventListener;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *
 */

/**
 *Se conecta al servidor de Pusher para el envio de datos entre cliente servidor.
 */
public class PusherUtil {

	/**
	 * parametro para acceder al servidor de pusher
	 */
	private String app_id;
	/**
	 * parametro para acceder al servidor de pusher
	 */
	private String key;
	/**
	 * parametro para acceder al servidor de pusher
	 */
	private String secret;
	/**
	 * parametro para acceder al servidor de pusher
	 */
	private String cluster;

	private static List<String> ListaCodigoVoto = new ArrayList<>();
	private boolean recibido = false;
	
	/**
	 * metodo PusherUtil utilizado para acceder a la base de datos Pusher
	 */
	public PusherUtil() {

		app_id = "1287468";
		key = "3e83a94bdd287eadbca3";
		secret = "aeb09d4cd63283936a29";
		cluster = "us2";
		escucharMensajes();
	}

	/**
	 * Metodo que esta a la escucha del mensaje que envia el cliente
	 */
	public void escucharMensajes() {
		
		PusherOptions options = new PusherOptions();
		options.setCluster(cluster);
		Pusher pusher = new Pusher(key, options);

		Channel channel = pusher.subscribe("my-channel");
		channel.bind("my-event", new SubscriptionEventListener() {

			@Override
			public void onEvent(PusherEvent pe) {
				recibido=true;
				ListaCodigoVoto.add(pe.getData().substring(0, pe.getData().length() - 1).replace("{\"message\":", "").replace("\"",""));
			}

		});

		pusher.connect();
	}

	
	/**
	 * @return Devuelve una List de tipo String que almacena los votos codificados
	 */
	public static List<String> getListaCodigoVoto() {
		return ListaCodigoVoto;
	}
	
	/**
	 * Resetea la ListaCodigoVoto una vez utilizada
	 */
	public static void LimpiarVotosViejos() {
		if(!ListaCodigoVoto.isEmpty())
				ListaCodigoVoto = new ArrayList<>();
		
		if(ListaCodigoVoto.isEmpty()) {
			JOptionPane.showMessageDialog(null, "Se borraron los votos viejos");
		}else {
			JOptionPane.showMessageDialog(null, "No se borraron los votos viejos");
		}
	}
}