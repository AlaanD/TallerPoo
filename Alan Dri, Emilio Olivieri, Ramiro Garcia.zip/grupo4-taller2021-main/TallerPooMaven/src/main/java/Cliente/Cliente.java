package Cliente;

import com.pusher.client.Pusher;
import com.pusher.client.PusherOptions;
import com.pusher.client.channel.Channel;
import com.pusher.client.channel.PusherEvent;
import com.pusher.client.channel.SubscriptionEventListener;

import Taller.CamaraElectoral;
import VentanaModelo.VentanaMenu;

import java.util.Collections;
import java.util.Iterator;

import javax.swing.JOptionPane;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *
 */

/**
 * Clase main cliente, de esta misma se inica el programa.
 */
public class Cliente {

	/**
	 * parametro para acceder al servidor de pusher
	 */
	private String app_id;
	/**
	 * parametro para acceder al servidor de pusher
	 */
	private String key;
	/**
	 * parametro para acceder al servidor de pusher
	 */
	private String secret;
	/**
	 * parametro para acceder al servidor de pusher
	 */
	private String cluster;
	
	/**
	 * @param args argumentos
	 * Clase Cliente Main
	 */
	public static void main(String[] args) {
		CamaraElectoral camara = new CamaraElectoral();
		VentanaMenu ventanaMenu = new VentanaMenu(camara);
	}

	/**
	 * @param codigoString Codigo interno utilizado para saber a que lista voto el
	 * elector y en que distrito realizo el voto. Tambien de que
	 * tipo es el voto(Blanco o Valido), manteniendo el
	 * anonimato del elector
	 */
	public Cliente(String codigoString) {

		app_id = "1287468";
		key = "3e83a94bdd287eadbca3";
		secret = "aeb09d4cd63283936a29";
		cluster = "us2";
		enviarMensaje(codigoString);
		System.out.println(codigoString);
	}

	/**
	 * @param mensaje Metodo que envia un mensaje al servidor
	 */
	public void enviarMensaje(String mensaje) {

		com.pusher.rest.Pusher pusher = new com.pusher.rest.Pusher(app_id, key, secret);
		pusher.setCluster(cluster);
		pusher.setEncrypted(true);
		pusher.trigger("my-channel", "my-event", Collections.singletonMap("message", mensaje));
		System.out.println("Codigo enviado");
	}
}