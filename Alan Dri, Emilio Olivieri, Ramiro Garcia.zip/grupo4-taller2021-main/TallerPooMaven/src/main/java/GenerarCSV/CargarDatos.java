package GenerarCSV;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import Taller.Candidato;
import Taller.Domicilio;
import Taller.Elector;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 */

/**
 *Se encarga de crear los archivos electores y candidatos.csv.
 */
public class CargarDatos {

	/**
	 * elemento tipo lista Elector
	 */
	private List<Elector> padronGeneral;
	/**
	 * elemento tipo lista candidato
	 */
	private List<Candidato> candidatos;
	/**
	 * elemento tipo Datos
	 */
	private Datos datos;

	/**
	 * @throws IOException lanza una excepcion si el archivo no se encuentra
	 */
	public CargarDatos() throws IOException {
		this.padronGeneral = new ArrayList<>();
		this.candidatos = new ArrayList<>();
		datos = new Datos();
		generarElectores();
		generarCandidatos();
		crearArchivosCSV();
	}

	/**
	 * Se crea un archivo csv para almacenar los electores y los candidatos
	 */
	/**
	 * @throws IOException excepcion al crear el archivo CSV
	 */
	public void crearArchivosCSV() throws IOException {
		FileWriter csvWriter;
		FileWriter csvWriter2;

		csvWriter = new FileWriter("src\\candidatos.csv");
		
		for (Candidato c : candidatos) {
			csvWriter.append(String.join(",", c + ",\n"));
		}

		csvWriter.flush();
		csvWriter.close();
		csvWriter2 = new FileWriter("src\\electores.csv");
		for (Elector e : padronGeneral) {
			csvWriter2.append(String.join(",", e + ",\n"));
		}
		csvWriter2.flush();
		csvWriter2.close();
	}

	/**
	 * Se generan los candidatos segun los distritos
	 */
	private void generarCandidatos() {

		Iterator<Elector> it = padronGeneral.iterator();
		int diputadosBsAs = 0;
		int diputadosCorrientes = 0;
		int senadoresCorrientes = 0;
		int diputadosEntreRios = 0;
		int diputadosMisiones = 0;
		int diputadosCABA = 0;

		Elector e;
		while (it.hasNext()) {

			e = it.next();
			switch (e.getDomicilio().getProvincia()) {
				case "Buenos Aires":
					if (diputadosBsAs < 20) {
						diputadosBsAs++;
						candidatos.add(new Candidato(e, "Diputado"));
					}
				break;
				
				case "Corrientes":
					if (diputadosCorrientes < 20) {
						diputadosCorrientes++;
						candidatos.add(new Candidato(e, "Diputado"));
					} else {
						if(senadoresCorrientes < 12) {
							senadoresCorrientes++;
							candidatos.add(new Candidato(e, "Senador"));
						}
					}
				break;
				
				case "Entre Rios":
					if (diputadosEntreRios < 20) {
						diputadosEntreRios++;
						candidatos.add(new Candidato(e, "Diputado"));
					}
				break;
				
				case "Misiones":
					if (diputadosMisiones < 20) {
						diputadosMisiones++;
						candidatos.add(new Candidato(e, "Diputado"));
					}
				break;
				
				case "CABA":
					if (diputadosCABA < 20) {
						diputadosCABA++;
						candidatos.add(new Candidato(e, "Diputado"));
					}
				break;

				default:
					break;
			}
		}

	}

	/**
	 * @param Seccion lista para obtener la localidad
	 * @return Devuelve la localidad segun la seccion recibida por parametro
	 */
	private String dameLocalidad(String Seccion) {

		switch (Seccion) {
		case "Caballito": {
			if (Math.random() > 0.5) {
				return "Caballito Norte";
			} else {
				return "Caballito Sur";
			}
		}
		case "Palermo": {
			if (Math.random() > 0.5) {
				return "Palermo Norte";
			} else {
				return "Palermo Sur";
			}
		}
		case "Recoleta": {
			if (Math.random() > 0.5) {
				return "Recoleta Norte";
			} else {
				return "Recoleta Sur";
			}
		}
		case "Concordia": {
			if (Math.random() > 0.5) {
				return "Concordia Norte";
			} else {
				return "Concordia Sur";
			}
		}
		case "Parana": {
			if (Math.random() > 0.5) {
				return "Parana Norte";
			} else {
				return "Parana Sur";
			}
		}
		case "Gualeguaychu": {
			if (Math.random() > 0.5) {
				return "Gualeguaychu Norte";
			} else {
				return "Gualeguaychu Sur";
			}
		}
		case "Ituzaingo": {
			if (Math.random() > 0.5) {
				return "Ituzaingo Norte";
			} else {
				return "Ituzaingo Sur";
			}
		}
		case "Goya": {
			if (Math.random() > 0.5) {
				return "Goya Norte";
			} else {
				return "Goya Sur";
			}
		}
		case "Esquina": {
			if (Math.random() > 0.5) {
				return "Esquina Norte";
			} else {
				return "Esquina Sur";
			}
		}
		case "Tandil": {
			if (Math.random() > 0.5) {
				return "Tandil Norte";
			} else {
				return "Tandil Sur";
			}
		}
		case "La Plata": {
			if (Math.random() > 0.5) {
				return "La Plata Norte";
			} else {
				return "La Plata Sur";
			}
		}
		case "Olavarria": {
			if (Math.random() > 0.5) {
				return "Olavarria Norte";
			} else {
				return "Olavarria Sur";
			}
		}
		case "Iguazu": {
			if (Math.random() > 0.5) {
				return "Iguazu Norte";
			} else {
				return "Iguazu Sur";
			}
		}
		case "Obera": {
			if (Math.random() > 0.5) {
				return "Obera Norte";
			} else {
				return "Obera Sur";
			}
		}
		case "Apostoles": {
			if (Math.random() > 0.5) {
				return "Apostoles Norte";
			} else {
				return "Apostoles Sur";
			}
		}
		default:
			break;
		}
		return null;
	}

	/**
	 * Se generan los electores aleatoriamente cargando sus datos obtenidos desde los csv
	 * nombresHombres, nombresMujeres, domicilio y apellido que cargamos en la clase Datos
	 */
	private void generarElectores() {
		String domicilio = "";
		padronGeneral.add(new Elector("Alan", "Dri", 4, 8, 1995, 38260500,
				new Domicilio("Hermanas Bentancourt", "Concordia Norte", "Concordia", "Entre Rios")));
		padronGeneral.add(new Elector("Ramiro", "Garcia", 17, 6, 1993, 36546998,
				new Domicilio("Buenos Aires", "Concordia Norte", "Concordia", "Entre Rios")));
		padronGeneral.add(new Elector("Emilio", "Olivieri", 10, 5, 1994, 37888190,
				new Domicilio("Pueyrredon", "Goya Norte", "Goya", "Corrientes")));
		for (int i = 20000000; i < 20020000; i++) {
			double x = Math.random();
			int randomNombre, randomApellido, dia, mes;
			randomNombre = (int) (Math.random() * 1000);
			dia = randomNombre % 32;// para que no supere los 32 dias
			mes = randomNombre % 13;// para que no sea mes 13
			randomApellido = (int) (Math.random() * 1000);

			if (dia == 0)
				dia = 1;

			if (mes == 0)
				mes = 1;

			LocalDate mi_anio = LocalDate.now();
			int anio = (int) (Math.random() * 100);
			anio = mi_anio.getYear() - anio;

			while ((2021 - anio) < 15) {
				anio = (int) (Math.random() * 100);
				anio = mi_anio.getYear() - anio;
			}

			if (x > 0.50) {
				x = Math.random();
				if (x < 0.20) {
					randomNombre = randomNombre % datos.getNombres().size();
					randomApellido = randomApellido % datos.getApellidos().size();
					domicilio = datos.getDomicilios().get(randomNombre % datos.getDomicilios().size());

					x = Math.random();
					if (x < 0.33) {
						padronGeneral.add(new Elector(datos.getNombres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Ituzaingo"), "Ituzaingo", "Corrientes")));
						continue;
					}
					if (x < 0.66) {
						padronGeneral.add(new Elector(datos.getNombres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Esquina"), "Esquina", "Corrientes")));
						continue;
					}
					if (x < 1.00) {
						padronGeneral.add(new Elector(datos.getNombres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Goya"), "Goya", "Corrientes")));
						continue;
					}
				}
				if (x < 0.40) {
					randomNombre = randomNombre % datos.getNombres().size();
					randomApellido = randomApellido % datos.getApellidos().size();

					x = Math.random();
					if (x < 0.33) {
						padronGeneral.add(new Elector(datos.getNombres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Caballito"), "Caballito", "CABA")));
						continue;
					}
					if (x < 0.66) {
						padronGeneral.add(new Elector(datos.getNombres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Palermo"), "Palermo", "CABA")));
						continue;
					}
					if (x < 1.00) {
						padronGeneral.add(new Elector(datos.getNombres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Recoleta"), "Recoleta", "CABA")));
						continue;
					}
				}
				if (x < 0.60) {
					randomNombre = randomNombre % datos.getNombres().size();
					randomApellido = randomApellido % datos.getApellidos().size();

					x = Math.random();
					if (x < 0.33) {
						padronGeneral.add(new Elector(datos.getNombres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Tandil"), "Tandil", "Buenos Aires")));
						continue;
					}
					if (x < 0.66) {
						padronGeneral.add(new Elector(datos.getNombres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Olavarria"), "Olavarria", "Buenos Aires")));
						continue;
					}
					if (x < 1.00) {
						padronGeneral.add(new Elector(datos.getNombres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("La Plata"), "La Plata", "Buenos Aires")));
						continue;
					}
				}
				if (x < 0.70) {
					randomNombre = randomNombre % datos.getNombres().size();
					randomApellido = randomApellido % datos.getApellidos().size();

					x = Math.random();
					if (x < 0.33) {
						padronGeneral.add(new Elector(datos.getNombres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Concordia"), "Concordia", "Entre Rios")));
						continue;
					}
					if (x < 0.66) {

						padronGeneral.add(new Elector(datos.getNombres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Parana"), "Parana", "Entre Rios")));
						continue;
					}
					if (x < 1.00) {
						padronGeneral.add(new Elector(datos.getNombres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Gualeguaychu"), "Gualeguaychu", "Entre Rios")));
						continue;
					}
				}
				if (x < 1.0) {
					randomNombre = randomNombre % datos.getNombres().size();
					randomApellido = randomApellido % datos.getApellidos().size();
					x = Math.random();
					if (x < 0.33) {
						padronGeneral.add(new Elector(datos.getNombres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Iguazu"), "Iguazu", "Misiones")));
						continue;
					}
					if (x < 0.66) {
						padronGeneral.add(new Elector(datos.getNombres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Obera"), "Obera", "Misiones")));
						continue;
					}
					if (x < 1.00) {
						padronGeneral.add(new Elector(datos.getNombres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Apostoles"), "Apostoles", "Misiones")));
						continue;
					}
				}
			} else {
				x = Math.random();

				if (x < 0.20) {
					x = Math.random();
					randomNombre = randomNombre % datos.getNombresmujeres().size();
					randomApellido = randomApellido % datos.getApellidos().size();
					domicilio = datos.getDomicilios().get(randomNombre % datos.getDomicilios().size());

					if (x < 0.33) {
						padronGeneral.add(new Elector(datos.getNombresmujeres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Ituzaingo"), "Ituzaingo", "Corrientes")));
						continue;
					}
					if (x < 0.66) {
						padronGeneral.add(new Elector(datos.getNombresmujeres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Esquina"), "Esquina", "Corrientes")));
						continue;
					}
					if (x < 1.00) {
						padronGeneral.add(new Elector(datos.getNombresmujeres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Goya"), "Goya", "Corrientes")));
						continue;
					}
				}
				if (x < 0.40) {
					randomNombre = randomNombre % datos.getNombresmujeres().size();
					randomApellido = randomApellido % datos.getApellidos().size();

					x = Math.random();
					if (x < 0.33) {
						padronGeneral.add(new Elector(datos.getNombresmujeres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Caballito"), "Caballito", "CABA")));
						continue;
					}
					if (x < 0.66) {
						padronGeneral.add(new Elector(datos.getNombresmujeres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Palermo"), "Palermo", "CABA")));
						continue;
					}
					if (x < 1.00) {
						padronGeneral.add(new Elector(datos.getNombresmujeres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Recoleta"), "Recoleta", "CABA")));
						continue;
					}
				}
				if (x < 0.60) {
					randomNombre = randomNombre % datos.getNombresmujeres().size();
					randomApellido = randomApellido % datos.getApellidos().size();

					x = Math.random();
					if (x < 0.33) {
						padronGeneral.add(new Elector(datos.getNombresmujeres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Tandil"), "Tandil", "Buenos Aires")));
						continue;
					}
					if (x < 0.66) {

						padronGeneral.add(new Elector(datos.getNombresmujeres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Olavarria"), "Olavarria", "Buenos Aires")));
						continue;
					}
					if (x < 1.00) {
						padronGeneral.add(new Elector(datos.getNombresmujeres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("La Plata"), "La Plata", "Buenos Aires")));
						continue;
					}
				}
				if (x < 0.70) {
					randomNombre = randomNombre % datos.getNombresmujeres().size();
					randomApellido = randomApellido % datos.getApellidos().size();
					x = Math.random();
					if (x < 0.33) {
						padronGeneral.add(new Elector(datos.getNombresmujeres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Iguazu"), "Iguazu", "Misiones")));
						continue;
					}
					if (x < 0.66) {

						padronGeneral.add(new Elector(datos.getNombresmujeres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Obera"), "Obera", "Misiones")));
						continue;
					}
					if (x < 1.00) {
						padronGeneral.add(new Elector(datos.getNombresmujeres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Apostoles"), "Apostoles", "Misiones")));
						continue;
					}
				}
				if (x < 1.0) {
					randomNombre = randomNombre % datos.getNombresmujeres().size();
					randomApellido = randomApellido % datos.getApellidos().size();

					x = Math.random();
					if (x < 0.33) {
						padronGeneral.add(new Elector(datos.getNombresmujeres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Concordia"), "Concordia", "Entre Rios")));
						continue;
					}
					if (x < 0.66) {
						padronGeneral.add(new Elector(datos.getNombresmujeres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Parana"), "Parana", "Entre Rios")));
						continue;
					}
					if (x < 1.00) {
						padronGeneral.add(new Elector(datos.getNombresmujeres().get(randomNombre),
								datos.getApellidos().get(randomApellido), dia, mes, anio, i,
								new Domicilio(domicilio, dameLocalidad("Gualeguaychu"), "Gualeguaychu", "Entre Rios")));
						continue;
					}
				}
			}
		}
	}
}