package GenerarCSV;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 */
/**
 * Carga los datos de los archivos, nombre de hombre, nombre de mujeres, apellidos y domicilios.
 *
 */
public class Datos {

	private List<String> nombres;
	private List<String> apellidos;
	private List<String> nombresmujeres;
	private List<String> domicilios;
	
	/**
	 * lista de atributos de una persona
	 */
	public Datos() {
		nombres = new ArrayList<>();
		apellidos = new ArrayList<>();
		nombresmujeres = new ArrayList<>();
		domicilios = new ArrayList<>();
		cargarNombresHombres();
		cargarNombresMujeres();
		cargarApellidos();
		cargarDomicilios();
	}
	
	/**
	 * Se almacenan los domicilios en una List de tipo String para luego cargar los electores/candidatos
	 */
	private void cargarDomicilios() {
		FileReader fr;
		try {
			fr = new FileReader(new File("src/main/java/domicilios.csv"));
			BufferedReader data = new BufferedReader(fr);
			String linea = "";
			linea = data.readLine();
			while (linea != null) {

				domicilios.add(linea);
				linea = data.readLine();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	/**
	 * @return Devuelve el domicilio
	 */
	public List<String> getDomicilios() {
		return domicilios;
	}

	/**
	 * @return Devuelve el nombre
	 */
	public List<String> getNombres() {
		return nombres;
	}

	/**
	 * @return Devuelve el apellido
	 */
	public List<String> getApellidos() {
		return apellidos;
	}

	/**
	 * @return Devuelve el nombre de las mujeres
	 */
	public List<String> getNombresmujeres() {
		return nombresmujeres;
	}

	/**
	 * Se almacenan los apellidos en una List de tipo String para luego cargar los electores/candidatos
	 */
	private void cargarApellidos() {
		FileReader fr;
		try {
			fr = new FileReader(new File("src/main/java/apellidos.csv"));
			BufferedReader data = new BufferedReader(fr);
			String linea = "";
			linea = data.readLine();
			while (linea != null) {

				apellidos.add(linea);
				linea = data.readLine();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Se almacenan los nombres de la mujeres en una List de tipo String para luego cargar los electores/candidatos
	 */
	private void cargarNombresMujeres() {
		FileReader fr;
		try {
			fr = new FileReader(new File("src/main/java/nombresMujeres.csv"));
			BufferedReader data = new BufferedReader(fr);
			String linea = "";
			linea = data.readLine();
			while (linea != null) {

				nombresmujeres.add(linea);
				linea = data.readLine();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Se almacenan los nombres de los hombres en una List de tipo String para luego cargar los electores/candidatos
	 */
	private void cargarNombresHombres() {

		FileReader fr;
		try {
			
			fr = new FileReader(new File("src/main/java/nombresHombres.csv"));
			BufferedReader data = new BufferedReader(fr);
			String linea = "";
			linea = data.readLine();
			
			while (linea != null) {
				nombres.add(linea);
				linea = data.readLine();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}