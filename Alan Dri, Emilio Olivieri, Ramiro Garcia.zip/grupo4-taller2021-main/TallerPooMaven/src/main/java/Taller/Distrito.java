package Taller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *
 */

/**
 *	Crea un objeto de tipo distrito, a su vez se encarga de crear las secciones.
 *	Crea las listas, alianzas y separa los candidatos por distrito.
 */
public class Distrito implements EstadisticaEleccion {

	/**
	 * string con nombre del distrito
	 */
	private String nombreDistrito;
	/**
	 * cantidad de senadores del distrito
	 */
	private int cantSenadores;
	/**
	 * cantidad de diputados del distrito
	 */
	private int cantDiputados;
	/**
	 * lista padron con los electores del distrito
	 */
	private List<Elector> padronDistrito;
	/**
	 * listas a votar presentadas en el distrito
	 */
	private List<Lista> listasAVotar;
	/**
	 * listas de las secciones de cada distrito
	 */
	private List<Seccion> secciones;
	/**
	 * listas de las alianzas de cada distrito
	 */
	private List<Alianza> alianzas;

	/**
	 * lista de candidatos a senadores de buenos aires
	 */
	private List<Candidato> senadorBsAs = new ArrayList<>();
	/**
	 * lista de candidatos a diputados de buenos aires
	 */
	private List<Candidato> diputadoBsAs = new ArrayList<>();
	/**
	 * lista de candidatos a senadores de CABA
	 */
	private List<Candidato> senadorCABA = new ArrayList<>();
	/**
	 * lista de candidatos a diputados de CABA
	 */
	private List<Candidato> diputadoCABA = new ArrayList<>();
	/**
	 * lista de candidatos a senadores de Misiones
	 */
	private List<Candidato> senadorMisiones = new ArrayList<>();
	/**
	 * lista de candidatos a diputados de Misiones
	 */
	private List<Candidato> diputadoMisiones = new ArrayList<>();
	/**
	 * lista de candidatos a senadores de Entre Rios
	 */
	private List<Candidato> senadorEntreRios = new ArrayList<>();
	/**
	 * lista de candidatos a diputados de Entre Rios
	 */
	private List<Candidato> diputadoEntreRios = new ArrayList<>();
	/**
	 * lista de candidatos a senadores de Corrientes
	 */
	private List<Candidato> senadorCorrientes = new ArrayList<>();
	/**
	 * lista de candidatos a diputados de Corrientes
	 */
	private List<Candidato> diputadoCorrientes = new ArrayList<>();

	/**
	 * @param nombreDistrito nombre del distrito
	 * @param cantDiputados cantidad de diputados del distrito
	 * @param padronDistrito padron electoral del distrito
	 * @param registroCandidatos registro de candidatos
	 * 
	 * crea un objeto de tipo distrito
	 * 
	 */
	public Distrito(String nombreDistrito, int cantDiputados, List<Elector> padronDistrito,	List<Candidato> registroCandidatos) {
		this.nombreDistrito = nombreDistrito;
		this.cantSenadores = 3;
		this.cantDiputados = cantDiputados;
		this.padronDistrito = padronDistrito;
		this.secciones = new ArrayList<>();
		this.alianzas = new ArrayList<>();
		this.listasAVotar = new ArrayList<>();
		
		separarCandidatos(registroCandidatos);
		crearAlianzas();
		crearListas();
		cargarSecciones(padronDistrito, listasAVotar);
	}

	/**
	 * @param candidatos recibe la totalidad de candidatos, separa, diputados, senadores por distrito 
	 */
	private void separarCandidatos(List<Candidato> candidatos) {

		int i = 0;
		Iterator<Candidato> it = candidatos.iterator();
		while (it.hasNext()) {
			Candidato candidato = it.next();

			if (candidato.getCargo().equalsIgnoreCase("Senador")) {
				switch (candidato.getDomicilio().getProvincia()) {
				case "Buenos Aires": {
					senadorBsAs.add(candidato);
					break;
				}
				case "Entre Rios": {
					senadorEntreRios.add(candidato);
					break;
				}
				case "Misiones": {
					senadorMisiones.add(candidato);
					break;
				}
				case "Corrientes": {
					senadorCorrientes.add(candidato);
					break;
				}
				case "CABA": {
					senadorCABA.add(candidato);
					break;
				}
				default:
					break;
				}
			} else {
				switch (candidato.getDomicilio().getProvincia()) {
				case "Buenos Aires": {
					diputadoBsAs.add(candidato);
					break;
				}
				case "Entre Rios": {
					diputadoEntreRios.add(candidato);
					break;
				}
				case "Misiones": {
					diputadoMisiones.add(candidato);
					break;
				}
				case "Corrientes": {
					diputadoCorrientes.add(candidato);
					break;
				}
				case "CABA": {
					diputadoCABA.add(candidato);
					break;
				}
				default:
					break;
				}
			}
		}
	}

	/**
	 * crea alianzas discriminado por distrito
	 */
	private void crearAlianzas() {

		switch (this.nombreDistrito) {
			case "Buenos Aires": {
				alianzas.add(new Alianza("JUNTOS POR EL CAMBIO", damePartidosPoliticos("JUNTOS POR EL CAMBIO")));
				alianzas.add(new Alianza("FRENTE DE TODOS", damePartidosPoliticos("FRENTE DE TODOS")));
				alianzas.add(new Alianza("CONSENSO FEDERAL", damePartidosPoliticos("CONSENSO FEDERAL")));
				alianzas.add(new Alianza("COMPROMISO FEDERAL", damePartidosPoliticos("COMPROMISO FEDERAL")));
				break;
			}
			case "CABA": {
				alianzas.add(new Alianza("TRABAJADORES - UNIDAD", damePartidosPoliticos("TRABAJADORES - UNIDAD")));
				alianzas.add(new Alianza("FRENTE DE TODOS", damePartidosPoliticos("FRENTE DE TODOS")));
				alianzas.add(new Alianza("JUNTOS POR EL CAMBIO", damePartidosPoliticos("JUNTOS POR EL CAMBIO")));
				alianzas.add(new Alianza("CONSESO FEDERAL", damePartidosPoliticos("CONSESO FEDERAL")));
				break;
			}
			case "Corrientes": {
				alianzas.add(new Alianza("CONSESO FEDERAL", damePartidosPoliticos("CONSESO FEDERAL")));
				alianzas.add(new Alianza("FRENTE DE TODOS", damePartidosPoliticos("FRENTE DE TODOS")));
				alianzas.add(new Alianza("ECO", damePartidosPoliticos("ECO")));
				alianzas.add(new Alianza("JUNTOS POR EL CAMBIO", damePartidosPoliticos("JUNTOS POR EL CAMBIO")));
				break;
			}
			case "Entre Rios": {
				alianzas.add(new Alianza("JUNTOS POR EL CAMBIO", damePartidosPoliticos("JUNTOS POR EL CAMBIO")));
				alianzas.add(new Alianza("FRENTE DE TODOS", damePartidosPoliticos("FRENTE DE TODOS")));
				alianzas.add(new Alianza("ECO", damePartidosPoliticos("ECO")));
				alianzas.add(new Alianza("CIUDADANOS A GOBERNAR", damePartidosPoliticos("SOCIALISTA")));
				break;
			}
			case "Misiones": {
				alianzas.add(new Alianza("JUNTOS POR EL CAMBIO", damePartidosPoliticos("JUNTOS POR EL CAMBIO")));
				alianzas.add(new Alianza("FRENTE DE TODOS", damePartidosPoliticos("FRENTE DE TODOS")));
				alianzas.add(new Alianza("ECO", damePartidosPoliticos("ECO")));
				alianzas.add(new Alianza("CIUDADANOS A GOBERNAR", damePartidosPoliticos("CIUDADANOS A GOBERNAR")));
				break;
			}
			default:
				break;
		}
	}

	/**
	 * @param cargo que ocuparia el candidato
	 * @param candidatosDistrito lista de candidatos de cada distrito
	 * @return devuelve una lista de candidatos, 
	 * teniendo en cuenta el cargo pasado por parametro
	 */
	private List<Candidato> dameCandidatos(String cargo, List<Candidato> candidatosDistrito) {
		int x = 0;
		List<Candidato> candidatosLista = new ArrayList<>();

		if (cargo.equalsIgnoreCase("senador")) {
			x = 3;
		} else {
			x = 5;
		}
		int longitud = candidatosDistrito.size();
		
		for (int i = 0; i < longitud; i++) {

			if (x > 0) {
				candidatosLista.add(candidatosDistrito.get(0));
				candidatosDistrito.remove(0);
				x--;
			}else {
				break;
			}
		}
		return candidatosLista;
	}

	/**
	 * crea las listas por distrito 
	 */
	private void crearListas() {

		switch (this.nombreDistrito) {
			case "Buenos Aires": {
				listasAVotar.add(new Lista("Frente de Todos", new AgrupacionPolitica(alianzas.get(0)),
						dameCandidatos("Senador", senadorBsAs), dameCandidatos("Diputado", diputadoBsAs),this));
				listasAVotar.add(new Lista("Juntos", new AgrupacionPolitica(alianzas.get(1)),
						dameCandidatos("Senador", senadorBsAs), dameCandidatos("Diputado", diputadoBsAs),this));
				listasAVotar.add(new Lista("Vamos por vos", new AgrupacionPolitica(alianzas.get(2)),
						dameCandidatos("Senador", senadorBsAs), dameCandidatos("Diputado", diputadoBsAs),this));
				listasAVotar.add(new Lista("Avanza Libertad", new AgrupacionPolitica(alianzas.get(3)),
						dameCandidatos("Senador", senadorBsAs), dameCandidatos("Diputado", diputadoBsAs),this));
				
				break;
			}
			case "Entre Rios": {
				listasAVotar.add(new Lista("Frente de Todos", new AgrupacionPolitica(alianzas.get(0)),
						dameCandidatos("Senador", senadorEntreRios), dameCandidatos("Diputado", diputadoEntreRios),this));
				listasAVotar.add(new Lista("Juntos por Entre Rios", new AgrupacionPolitica(alianzas.get(1)),
						dameCandidatos("Senador", senadorEntreRios), dameCandidatos("Diputado", diputadoEntreRios),this));
				listasAVotar.add(new Lista("Nueva Izquierda", new AgrupacionPolitica(alianzas.get(2)),
						dameCandidatos("Senador", senadorEntreRios), dameCandidatos("Diputado", diputadoEntreRios),this));
				listasAVotar.add(new Lista("Adelante Entre Rios", new AgrupacionPolitica(alianzas.get(3)),
						dameCandidatos("Senador", senadorEntreRios), dameCandidatos("Diputado", diputadoEntreRios),this));
				break;
			}
			case "Misiones": {
				listasAVotar.add(new Lista("Juntos por el Cambio", new AgrupacionPolitica(alianzas.get(0)),
						dameCandidatos("Senador", senadorMisiones), dameCandidatos("Diputado", diputadoMisiones),this));
				listasAVotar.add(new Lista("Frente de Todos", new AgrupacionPolitica(alianzas.get(1)),
						dameCandidatos("Senador", senadorMisiones), dameCandidatos("Diputado", diputadoMisiones),this));
				listasAVotar.add(new Lista("Libertad, Valores y Cambio", new AgrupacionPolitica(alianzas.get(2)),
						dameCandidatos("Senador", senadorMisiones), dameCandidatos("Diputado", diputadoMisiones),this));
				listasAVotar.add(new Lista("Frente Renovador de la Concordia", new AgrupacionPolitica(alianzas.get(3)),
						dameCandidatos("Senador", senadorMisiones), dameCandidatos("Diputado", diputadoMisiones),this));
				break;
			}
			case "CABA": {
				listasAVotar.add(new Lista("Juntos por el Cambio", new AgrupacionPolitica(alianzas.get(0)),
						dameCandidatos("Senador", senadorCABA), dameCandidatos("Diputado", diputadoCABA),this));
				listasAVotar.add(new Lista("Frente de Izquierda", new AgrupacionPolitica(alianzas.get(1)),
						dameCandidatos("Senador", senadorCABA), dameCandidatos("Diputado", diputadoCABA),this));
				listasAVotar.add(new Lista("Frente de Todos", new AgrupacionPolitica(alianzas.get(2)),
						dameCandidatos("Senador", senadorCABA), dameCandidatos("Diputado", diputadoCABA),this));
				listasAVotar.add(new Lista("La Libertad Avanza", new AgrupacionPolitica(alianzas.get(3)),
						dameCandidatos("Senador", senadorCABA), dameCandidatos("Diputado", diputadoCABA),this));
				break;
			}
			case "Corrientes": {
				listasAVotar.add(new Lista("Eco+ Vamos Corrientes", new AgrupacionPolitica(alianzas.get(0)),
						dameCandidatos("Senador", senadorCorrientes), dameCandidatos("Diputado", diputadoCorrientes),this));
				listasAVotar.add(new Lista("Frente de Todos", new AgrupacionPolitica(alianzas.get(1)),
						dameCandidatos("Senador", senadorCorrientes), dameCandidatos("Diputado", diputadoCorrientes),this));
				listasAVotar.add(new Lista("Vamos con Vos", new AgrupacionPolitica(alianzas.get(2)),
						dameCandidatos("Senador", senadorCorrientes), dameCandidatos("Diputado", diputadoCorrientes),this));
				listasAVotar.add(new Lista("Compromiso Federal", new AgrupacionPolitica(alianzas.get(3)),
						dameCandidatos("Senador", senadorCorrientes), dameCandidatos("Diputado", diputadoCorrientes),this));
				break;
			}
			default:
				break;
		}
	}

	/**
	 * @param nombre del distrito
	 * @return devuelve una List<PartidoPolitico>, 
	 * dependiendo del nombre pasado por parametro
	 */
	private List<PartidoPolitico> damePartidosPoliticos(String nombre) {
		switch (this.nombreDistrito) {
			case "Buenos Aires": {
				List<PartidoPolitico> partidoPolitico = new ArrayList<>();
				switch (nombre) {
					case "JUNTOS POR EL CAMBIO": {
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Democrata Progresista"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Comunista"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Movimiento al Socialismo"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Conservador Popular"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Union Popular"));
						break;
					}
					case "FRENTE DE TODOS": {
						partidoPolitico.add(PartidoPolitico.getPartidos("Movimiento de Integracion y Desarrollo"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Justicialista"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Union Civica Radical"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Intransigente"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Federal"));
						break;
					}
					case "CONSENSO FEDERAL": {
						partidoPolitico.add(PartidoPolitico.getPartidos("Movimiento de Integracion y Desarrollo"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Justicialista"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Union Civica Radical"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Intransigente"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Federal"));
						break;
					}
					case "COMPROMISO FEDERAL": {
						partidoPolitico.add(PartidoPolitico.getPartidos("Movimiento de Integracion y Desarrollo"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Justicialista"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Union Civica Radical"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Intransigente"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Federal"));
						break;
					}
				}
				return partidoPolitico;
			}
			case "CABA": {
				List<PartidoPolitico> partidoPolitico = new ArrayList<>();
				switch (nombre) {
					case "TRABAJADORES - UNIDAD": {
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Democrata"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Nueva Dirigencia"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Union por la Libertad"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Movimiento Socialista de los Trabajadores"));
						break;
					}
					case "FRENTE DE TODOS": {
						partidoPolitico.add(PartidoPolitico.getPartidos("Accion Ciudadana"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Socialista Autentico"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Autodeterminacion y Libertad"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Red por Buenos Aires"));
						partidoPolitico.add(PartidoPolitico.getPartidos("El Movimiento"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Patria Grande"));
						break;
					}
					case "JUNTOS POR EL CAMBIO": {
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Socialista Autentico"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Autodeterminacion y Libertad"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Red por Buenos Aires"));
						partidoPolitico.add(PartidoPolitico.getPartidos("ELI - Encuentro en Libertad"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Encuentro Libertario"));
						break;
					}
					case "CONSESO FEDERAL": {
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Democrata"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Nueva Dirigencia"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Union por la Libertad"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Movimiento Socialista de los Trabajadores"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Accion Ciudadana"));
						break;
					}
				}
				return partidoPolitico;
			}
			case "Corrientes": {
				List<PartidoPolitico> partidoPolitico = new ArrayList<>();
				switch (nombre) {
					case "CONSESO FEDERAL": {
						partidoPolitico.add(PartidoPolitico.getPartidos("Renacer Polotico y Social"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Dignidad Popular"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Unite por la Libertad y la Dignidad"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Corriente Martin Fierro"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Nuevo Espacio de Opinion"));
						break;
					}
					case "FRENTE DE TODOS": {
						partidoPolitico.add(PartidoPolitico.getPartidos("Republicanos Unidos"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Izquierda Popular"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Fuerza Organizada Renovadora Democratica"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Union del Centro Democratico"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Movimiento Autentico Popular"));
						break;
					}
					case "ECO": {
						partidoPolitico.add(PartidoPolitico.getPartidos("Cambio Austeridad y Progreso"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Union para el Desarrollo"));
						partidoPolitico.add(PartidoPolitico.getPartidos("ELI - Encuentro en Libertad"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Encuentro Correligionario"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Accion por Corrientes"));
						break;
					}
					case "JUNTOS POR EL CAMBIO": {
						partidoPolitico.add(PartidoPolitico.getPartidos("Cambio Austeridad y Progreso"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Union para el Desarrollo"));
						partidoPolitico.add(PartidoPolitico.getPartidos("ELI - Encuentro en Libertad"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Encuentro Libertario"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Accion por Corrientes"));
						break;
					}
				}
				return partidoPolitico;
			}
			case "Entre Rios": {
				List<PartidoPolitico> partidoPolitico = new ArrayList<>();
				switch (nombre) {
					case "JUNTOS POR EL CAMBIO": {
						partidoPolitico.add(PartidoPolitico.getPartidos("Accion por la Republica"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Autonomista"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Proyecto Popular"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Conservador Popular"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Union Popular Entre Rios"));
						break;
					}
					case "SOCIALISTA": {
						partidoPolitico.add(PartidoPolitico.getPartidos("Cambio Austeridad y Progreso"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Union para el Desarrollo"));
						partidoPolitico.add(PartidoPolitico.getPartidos("ELI - Encuentro en Libertad"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Encuentro Correligionario"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Accion por Corrientes"));
						break;
					}
					case "FRENTE DE TODOS": {
						partidoPolitico.add(PartidoPolitico.getPartidos("ACCION POR ENTRE RIOS"));
						partidoPolitico.add(PartidoPolitico.getPartidos("ENCUENTRO ENTRERRIANO"));
						partidoPolitico.add(PartidoPolitico.getPartidos("ENCUENTRO EN LIBERTAD POR ENTRE RIOS"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Nuevo Pais"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Federal"));
						break;
					}
					case "ECO": {
						partidoPolitico.add(PartidoPolitico.getPartidos("COALICION CIVICA - ARI"));
						partidoPolitico.add(PartidoPolitico.getPartidos("DEMOCRATA PROGRESISTA"));
						partidoPolitico.add(PartidoPolitico.getPartidos("UNION CIVICA RADICAL"));
						partidoPolitico.add(PartidoPolitico.getPartidos("TERCERA POSICION P3P"));
						partidoPolitico.add(PartidoPolitico.getPartidos("JUSTICIALISTA"));
						break;
					}
				}
				return partidoPolitico;
			}
			case "Misiones": {
				List<PartidoPolitico> partidoPolitico = new ArrayList<>();
				switch (nombre) {
					case "JUNTOS POR EL CAMBIO": {
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Democrata Progresista"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Comunista"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Movimiento al Socialismo"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Conservador Popular"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Union Popular Misiones"));
						break;
					}
					case "FRENTE DE TODOS": {
						partidoPolitico.add(PartidoPolitico.getPartidos("Integracion y Desarrollo"));
						partidoPolitico.add(PartidoPolitico.getPartidos("DEL FRENTE "));
						partidoPolitico.add(PartidoPolitico.getPartidos("HUMANISTA"));
						partidoPolitico.add(PartidoPolitico.getPartidos("GEN"));
						partidoPolitico.add(PartidoPolitico.getPartidos("AZUL"));
						break;
					}
					case "ECO": {
						partidoPolitico.add(PartidoPolitico.getPartidos("Movimiento de Integracion por Misiones"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Justicialista por Misiones unida"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Union Civica Radical MISIONES"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido economico MISIONES"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Federal ECO MISIONES"));
						break;
					}
					case "CIUDADANOS A GOBERNAR": {
						partidoPolitico.add(PartidoPolitico.getPartidos("DEL OBRERO"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Justicialista"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Radical"));
						partidoPolitico.add(PartidoPolitico.getPartidos("Partido Intransigente"));
						partidoPolitico.add(PartidoPolitico.getPartidos("IZQUIERDA POR UNA OPCION SOCIALISTA"));
						break;
					}
				}
				return partidoPolitico;
			}
			default:
				break;
		}
		return null;
	}

	/**
	 * @param padronDistrito padron electoral del distrito
	 * @param listaAvotar listas que se van a votar
	 * carga los secciones de un distrito
	 * 
	 */
	private void cargarSecciones(List<Elector> padronDistrito, List<Lista> listaAvotar) {


		String corrientes[] = { "Goya", "Ituzaingo", "Esquina" };
		String caba[] = { "Caballito", "Palermo", "Recoleta" };
		String entreRios[] = { "Concordia", "Parana", "Gualeguaychu" };
		String misiones[] = { "Iguazu", "Obera", "Apostoles" };
		String buenosAires[] = { "Tandil", "Olavarria", "La Plata" };

		List<Elector> padronSecciones;

		switch (this.nombreDistrito) {
			case "Buenos Aires": {
				for (String e : buenosAires) {
					padronSecciones = padronDistrito.stream().filter(n -> n.getDomicilio().getDepartamento().equals(e))
							.collect(Collectors.toList());
					secciones.add(new Seccion(e, padronSecciones, listaAvotar));
				}
				break;
			}
			case "CABA": {
				for (String e : caba) {
					padronSecciones = padronDistrito.stream().filter(n -> n.getDomicilio().getDepartamento().equals(e))
							.collect(Collectors.toList());
					secciones.add(new Seccion(e, padronSecciones, listaAvotar));
				}
				break;
			}
			case "Corrientes": {
				for (String e : corrientes) {
					padronSecciones = padronDistrito.stream().filter(n -> n.getDomicilio().getDepartamento().equals(e))
							.collect(Collectors.toList());
					secciones.add(new Seccion(e, padronSecciones, listaAvotar));
				}
				break;
			}
			case "Entre Rios": {
				for (String e : entreRios) {
					padronSecciones = padronDistrito.stream().filter(n -> n.getDomicilio().getDepartamento().equals(e))
							.collect(Collectors.toList());
					secciones.add(new Seccion(e, padronSecciones, listaAvotar));
				}
				break;
			}
			case "Misiones": {
				for (String e : misiones) {
					padronSecciones = padronDistrito.stream().filter(n -> n.getDomicilio().getDepartamento().equals(e))
							.collect(Collectors.toList());
					secciones.add(new Seccion(e, padronSecciones, listaAvotar));
				}
				break;
			}
			default:
				break;
		}
	}

	/**
	 * @return devuelve una List de tipo Seccion
	 */
	public List<Seccion> getConformaSecciones() {
		return secciones;
	}

	/**
	 * @return devuelve una List de tipo Lista
	 */
	public List<Lista> getPresenta() {
		return listasAVotar;
	}

	/**
	 * @return devuelve una List de tipo Alianza
	 */
	public List<Alianza> getAlianzas() {
		return alianzas;
	}

	/**
	 * @return devuelve nombre del distrito 
	 */
	public String getNombre() {
		return nombreDistrito;
	}

	/**
	 * @return devuelve cantidad de senadores
	 */
	public int getCantSenadores() {
		return cantSenadores;
	}


	/**
	 * @return devuelve cantidad de diputdos
	 */
	public int getCantDiputados() {
		return cantDiputados;
	}


	/**
	 * @return devuelve una List de tipo Elector 
	 */
	public List<Elector> getPadronDistrito() {
		return padronDistrito;
	}
	
	//----------------------------------------------------------------------------------

	
	/**
	 * @return devuelve List de tipo Lista 
	 */
	public List<Lista> getListasAVotar() {
		return listasAVotar;
	}

	/**
	 * @return devuelve una List de tipo Seccion
	 */
	public List<Seccion> getSecciones() {
		return secciones;
	}


	
	//-------------------------------------------------------------------------------------------------------------
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nombreDistrito == null) ? 0 : nombreDistrito.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Distrito other = (Distrito) obj;
		if (nombreDistrito == null) {
			if (other.nombreDistrito != null) {
				return false;
			}
		} else if (!nombreDistrito.equals(other.nombreDistrito)) {
			return false;
		}
		return true;
	}

	/**
	 *@return devuelve la cantidad de votos blancos del distrito
	 */
	@Override
	public int cantidadVotosBlancos() {
		AtomicInteger votos = new AtomicInteger();
		secciones.stream().forEach((p) -> {
			p.getCircuito().forEach((c) -> {
				c.getMesas().stream().forEach((m) -> {
					votos.set((int) (votos.get()
							+ m.getUrna().stream().filter(i -> i.getEl_voto() == CaracteristicaVoto.BLANCO).count()));
				});
			});
		});
		return votos.get();
	}

	/**
	 *@return devuelve la cantidad de votos validos del distrito
	 */
	@Override
	public int cantidadVotosValidos() {
		AtomicInteger votos = new AtomicInteger();
		secciones.stream().forEach((p) -> {
			p.getCircuito().forEach((c) -> {
				c.getMesas().stream().forEach((m) -> {
					votos.set((int) (votos.get()
							+ m.getUrna().stream().filter(i -> i.getEl_voto() == CaracteristicaVoto.VALIDO).count()));
				});
			});
		});
		return votos.get();
	}
	 
	/**
	 *@return devuelve la cantidad de votos totales del distrito
	 */
	@Override
	public int cantidadVotosTotales() {
		return this.cantidadVotosBlancos()+this.cantidadVotosValidos();
	}

	/**
	 *@return devuelve porcentaje votos validos por distrito
	 */
	@Override
	public double porcentajeVotosValidos() {
		// TODO Auto-generated method stub
		double x = (double) this.cantidadVotosValidos();
		if (cantidadVotosTotales() > 0) {
			return (x / cantidadVotosTotales())*100;
		} else {
			return 0;
		}
	}
	
	/**
	 * @return devuelve porcentaje votos en blanco por distrito
	 */
	@Override
	public double porcentajeVotosBlancos() {
		double x = (double) this.cantidadVotosBlancos();
		if (cantidadVotosTotales() > 0) {
			return (x / cantidadVotosTotales())*100;
		} else {
			return 0;
		}
	}
	
	/**
	 * Devuelve un unico String
	 */
	@Override
	public String toString() {
		return "Distrito [nombre: " + nombreDistrito + ", cantSenadores: " + cantSenadores + ", cantDiputados: "
				+ cantDiputados + ", padronDistrito: " + padronDistrito + "\n, listaAVotar: \n" + listasAVotar
				+ ", Secciones: " + secciones + "]\n";
	}
}