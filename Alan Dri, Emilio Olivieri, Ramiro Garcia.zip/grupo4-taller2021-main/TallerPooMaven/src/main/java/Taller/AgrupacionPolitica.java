package Taller;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *
 */

/**
 *Crea una alianza o partido politico segun corresponda.
 */
public class AgrupacionPolitica {
	
	/**
	 * elemento tipo alianza que contiene el nombre de esta y los partidos que la componen
	 */
	private Alianza alianza;
	/**
	 * elemento tipo partido politico
	 */
	private PartidoPolitico partido;
	
	/**
	 * @param partido crea un partido politico
	 */
	public AgrupacionPolitica(PartidoPolitico partido) {
		alianza = null;
		this.partido = partido;
	}

	/**
	 * @param alianza crea una alianza
	 */
	public AgrupacionPolitica(Alianza alianza) {
		this.alianza = alianza;
		this.partido = null;
	}
	
	/**
	 * @return retorna alianza si existe, sino retorna null
	 */
	public Alianza getAlianza() {
		if(alianza!=null)
			return alianza;
		return null;
	}
	
	
	
	/**
	 * @return devuelve partidopolitico, sino retorna null
	 */
	public PartidoPolitico getPartido() {
		if(partido!=null)
			return partido;
		return null;
	}
	
	 
	/**
	 * Devuelve un unico String
	 */
	@Override
	public String toString() {
		if(alianza != null) {
			return "AgrupacionPolitica [alianza: " + alianza + "]";
		}else 
			if(partido != null) {
				return "AgrupacionPolitica [partido: " + partido + "]";
		}
		return "No existe";
	}
}