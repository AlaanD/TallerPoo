package Taller;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 * 
 */

/**
 * Crea un objeto de PartidoPolitico
 *
 */
public class PartidoPolitico {

	/**
	 * nombre del partido politico 
	 */
	private String nombre ;
	/**
	 * generador de enteros
	 */
	private static int generador = 1;
	/**
	 * elemento de identificacion
	 */
	private int id;
	/**
	 * mapa de partidos politicos
	 */
	private static Map<String,Integer>partidos;
	/**
	 * elemento de control
	 */
	private static boolean control = false;
	
	
	/**
	 * @param nombre del partido politico
	 */
	public PartidoPolitico(String nombre  ) {
		this.nombre = nombre;
		id=generador++;
	}

	/**
	 * @param nombre del partido politico
	 * @return Devuelve un objeto de tipo PartidoPolitico
	 */
	public static PartidoPolitico getPartidos(String nombre) {
		
		PartidoPolitico partidoPolitico;
		if(!control) {
			partidos= new HashMap<>();
			partidos.put(nombre,generador);
			control=true;
			return new PartidoPolitico(nombre);
		}else {
		
			if(!controlpartidos(nombre)) {
				
				partidos.put(nombre,generador);
				return new PartidoPolitico(nombre);
			}else {
				
				for (Map.Entry<String, Integer> e : partidos.entrySet()) {
					if (e.getKey().equals(nombre)) {
						partidoPolitico= new PartidoPolitico(nombre);
						partidoPolitico.setid(e.getValue());
						return partidoPolitico;
					}
				}
			}
		}
		return null;
	}

	/**
	 * @param key clave id
	 * Se establece el id del partido
	 */
	private void setid(int key) {
		id = key;
	}

	/**
	 * @param nombre de partido
	 * @return Utiliza una coleccion de tipo map
	 * para verificar que no hallan nombre de partidos iguales
	 */
	private static boolean controlpartidos(String nombre) {
		return partidos.containsKey(nombre);
	}
	
	/**
	 * @return Devuelve el nombre de Partido politico
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @return Devuelve el id del Partido Politico
	 */
	public int getId() {
		return id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		PartidoPolitico other = (PartidoPolitico) obj;
		if (nombre == null) {
			if (other.nombre != null) {
				return false;
			}
		} else if (!nombre.equals(other.nombre)) {
			return false;
		}
		return true;
	}

	/**
	 * Devuelve un unico String
	 */
	@Override
	public String toString() {
		return "PartidoPolitico [nombre: " + nombre + ", id: " + id + "]\n";
	}
}