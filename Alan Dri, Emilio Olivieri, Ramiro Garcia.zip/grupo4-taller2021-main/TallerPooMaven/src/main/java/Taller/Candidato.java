package Taller;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *	
 */
/**
 * Crea un objeto de tipo candidato.
 */
public class Candidato extends Persona {

	/**
	 * cargo del candidato {Diputado, Senador}
	 */
	private String cargo;
	/**
	 * Domicilio del candidato
	 */
	private Domicilio domicilio;


	/**
	 * @param nombre nombre del candidato
	 * @param apellido apellido del candidato
	 * @param dia de nacimiento del candidato
	 * @param mes de nacimiento del candidato
	 * @param anio de nacimiento del candidato
	 * @param dni del candidato
	 * @param cargo {diputado, senador} que va a ocupar el candidato
	 * @param domicilio del candidato
	 * construte un objeto candidato
	 * 
	 */
	public Candidato(String nombre, String apellido, int dia, int mes, int anio, int dni, String cargo,	Domicilio domicilio) {
		super(nombre, apellido, dia, mes, anio, dni);
		this.cargo = cargo;
		this.domicilio = domicilio;
	}

	/**
	 * @param elector {diputado, senador} elemento tipo elector
	 * @param cargo que ocupa el candidato
	 * construte un objeto candidato
	 * 
	 * Solo es utiliza para la creación del archivo candidatos.csv
	 */
	public Candidato(Elector elector, String cargo) {
		super(elector.getNombre(), elector.getApellido(), elector.getDia(), elector.getMes(), elector.getAnio(), elector.getDni());
		this.cargo = cargo;
		this.domicilio = elector.getDomicilio();
	}
	
	/**
	 * @return devuelve un domicilio
	 */
	public Domicilio getDomicilio() {
		return domicilio;
	}

	/**
	 * @return devuelve el cargo del elector
	 */
	public String getCargo() {
		return cargo;
	}

	/**
	 * Devuelve un unico String
	 */
	@Override
	public String toString() {
		return super.toString()+" Candidato [cargo=" + cargo + ", domicilio=" + domicilio + "]";
	}
	
//	@Override
//	public String toString() {
//		return super.toString() + "," + cargo + "," + domicilio;
//	}
}