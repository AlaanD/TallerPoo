package Taller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *
 */

/**
 * 	Crea un objeto Seccion y tambien los circuitos correspondientes.
 *
 */
public class Seccion {
	/**
	 * lista de circuitos de una seccion
	 */
	private List<Circuito> circuitos;
	/**
	 * numero de la seccion
	 */
	private int numero;
	/**
	 * generador de enteros
	 */
	private static int generador = 1;
	/**
	 * nombre de la seccion
	 */
	private String nombreSeccion;
	
	/**
	 * @param nombreSeccion de la seccion
	 * @param padronSecciones de la seccion
	 * @param listasAVotar de la seccion
	 */
	public Seccion(String nombreSeccion,List<Elector> padronSecciones, List<Lista> listasAVotar) {
		this.numero = generador++;
		this.nombreSeccion = nombreSeccion;
		this.circuitos = new ArrayList<>();
		cargarCircuitos(padronSecciones, listasAVotar);
	}

	/**
	 * @param padronSecciones
	 * @param listasAVotar
	 * Se Establece los circuitos discriminando por seccion
	 */
	private void cargarCircuitos(List<Elector> padronSecciones, List<Lista> listasAVotar) {

		List<Elector> padronCircuitos;
		switch (this.nombreSeccion) {
		
			case "Goya": {
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Goya Norte"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Goya Norte", padronCircuitos, listasAVotar));
				
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Goya Sur"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Goya Sur", padronCircuitos, listasAVotar));
				break;
			}
			case "Ituzaingo": {
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Ituzaingo Norte"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Ituzaingo Norte", padronCircuitos, listasAVotar));
				
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Ituzaingo Sur"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Ituzaingo Sur", padronCircuitos, listasAVotar));
				break;
			}
			case "Esquina": {
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Esquina Norte"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Esquina Norte", padronCircuitos, listasAVotar));
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Esquina Sur"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Esquina Sur", padronCircuitos, listasAVotar));
				break;
			}
			case "Caballito": {
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Caballito Norte"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Caballito Norte", padronCircuitos, listasAVotar));
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Caballito Sur"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Caballito Sur", padronCircuitos, listasAVotar));
				break;
			}
			case "Palermo": {
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Palermo Norte"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Palermo Norte", padronCircuitos, listasAVotar));
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Palermo Sur"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Palermo Sur", padronCircuitos, listasAVotar));
				break;
			}
			case "Recoleta": {
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Recoleta Norte"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Recoleta Norte", padronCircuitos, listasAVotar));
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Recoleta Sur"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Recoleta Sur", padronCircuitos, listasAVotar));
				break;
			}
			case "Parana": {
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Parana Norte"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Parana Norte", padronCircuitos, listasAVotar));
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Parana Sur"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Parana Sur", padronCircuitos, listasAVotar));
				break;
			}
			case "Concordia": {
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Concordia Norte"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Concordia Norte", padronCircuitos, listasAVotar));
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Concordia Sur"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Concordia Sur", padronCircuitos, listasAVotar));
				break;
			}
			case "Gualeguaychu": {
				padronCircuitos = padronSecciones.stream()
						.filter(n -> n.getDomicilio().getLocalidad().equals("Gualeguaychu Norte"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Gualeguaychu Norte", padronCircuitos, listasAVotar));
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Gualeguaychu Sur"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Gualeguaychu Sur", padronCircuitos, listasAVotar));
				break;
			}
			case "Iguazu": {
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Iguazu Norte"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Iguazu Norte", padronCircuitos, listasAVotar));
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Iguazu Sur"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Iguazu Sur", padronCircuitos, listasAVotar));
				break;
			}
			case "Obera": {
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Obera Norte"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Obera Norte", padronCircuitos, listasAVotar));
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Obera Sur"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Obera Sur", padronCircuitos, listasAVotar));
				break;
			}
			case "Apostoles": {
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Apostoles Norte"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Apostoles Norte", padronCircuitos, listasAVotar));
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Apostoles Sur"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Apostoles Sur", padronCircuitos, listasAVotar));
				break;
			}
			case "Tandil": {
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Tandil Norte"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Tandil Norte", padronCircuitos, listasAVotar));
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Tandil Sur"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Tandil Sur", padronCircuitos, listasAVotar));
				break;
			}
			case "Olavarria": {
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Olavarria Norte"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Olavarria Norte",padronCircuitos, listasAVotar));
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("Olavarria Sur"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("Olavarria Sur",padronCircuitos, listasAVotar));
				break;
			}
			case "La Plata": {
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("La Plata Norte"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("La Plata Norte",padronCircuitos, listasAVotar));
				padronCircuitos = padronSecciones.stream().filter(n -> n.getDomicilio().getLocalidad().equals("La Plata Sur"))
						.collect(Collectors.toList());
				this.circuitos.add(new Circuito("La Plata Sur",padronCircuitos, listasAVotar));
				break;
			}
			default:
				break;
			}
	}

	/**
	 * @return Devuelve el circuito
	 */
	public List<Circuito> getCircuito() {
		return circuitos;
	}

	/**
	 * @return Devuelve el numero de la seccion
	 */
	public int getNumero() {
		return numero;
	}
	
	/**
	 * @return Devuelve el nombre de la seccion
	 */
	public String getNombreSeccion() {
		return nombreSeccion;
	}

	/**
	 * Devuelve un unico String
	 */
	@Override
	public String toString() {
		return "Nombre de sección: " + nombreSeccion + " [ " + circuitos +" ]\n" ;
	}
}