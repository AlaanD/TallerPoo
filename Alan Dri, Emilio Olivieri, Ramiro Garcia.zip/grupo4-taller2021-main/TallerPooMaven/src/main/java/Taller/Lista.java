package Taller;

import java.util.List;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *
 */

/**
 *	Crea un objeto de tipo Lista.
 */
public class Lista {
	/**
	 * nombre de la lista 
	 */
	private String nombre;
	/**
	 * numero de la lista
	 */
	private int numero;
	/**
	 * agrupacion politica a la que pertenece la lista
	 */
	private AgrupacionPolitica agrupacion;
	/**
	 * lista de listas a votar en el distrito
	 */
	private Distrito listaAVotar;
	/**
	 * lista de candidatos a senador
	 */
	private List<Candidato> senador;
	/**
	 * lista de candidatos a diputado
	 */
	private List<Candidato> diputado;
	/**
	 * generador tipo entero
	 */
	private static int generador = 1;
	/**
	 * contador de votos a diputados de la lista
	 */
	private int votosDiputados;
	/**
	 * contador de votos a senadores de la lista
	 */
	private int votosSenadores;

	/**
	 * @param nombre de la lista
	 * @param agrupacion de la lista
	 * @param senador de la lista
	 * @param diputado de la lista
	 * @param distrito de la lista
	 */
	public Lista(String nombre, AgrupacionPolitica agrupacion, List<Candidato> senador, List<Candidato> diputado,Distrito distrito) {
		this.nombre = nombre;
		this.agrupacion = agrupacion;
		this.numero = generador++;
		this.senador = senador;
		this.diputado = diputado;
		this.votosDiputados = 0;
		this.votosSenadores = 0;
		this.listaAVotar=distrito;
		
	}
	
//	private void sumarvotoSDiputados() {
//		this.votosDiputados++;
//	}
//	
//	private void sumarvotoSSenadores() {
//		this.votosSenadores++;
//	}
	
	/**
	 * @return devuelve un objeto de tipo Distrito
	 */
	public Distrito getPresenta() {
		return listaAVotar;
	}

	/**
	 * @return Devuelve una List de tipo Candidato con los senadores
	 * de la lista
	 */
	public List<Candidato> getSenador() {
		return senador;
	}

	/**
	 * @return Devuelve una List de tipo Candidato con los diputados
	 * de la lista
	 */
	public List<Candidato> getDiputado() {
		return diputado;
	}

	/**
	 * @return Devuelve un objeto de tipo AgupacionPolitica
	 */
	public AgrupacionPolitica getAgrupacion() {
		return agrupacion;
	}

	/**
	 * @return Devuelve el nombre de la lista
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @return devuelve el numero de la lista
	 */
	public int getNumero() {
		return numero;
	}

	/**
	 * @return Devuelve los votos de los diputados
	 */
	public int getVotosDiputados() {
		return votosDiputados;
	}

	/**
	 * @return Devuelve los votos de los senadores
	 */
	public int getVotosSenadores() {
		return votosSenadores;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + numero;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Lista other = (Lista) obj;
		if (numero != other.numero) {
			return false;
		}
		return true;
	}

	/**
	 * Devuelve un unico String
	 */
	@Override
	public String toString() {
		return nombre + "," + numero + "," + agrupacion.getAlianza().getNombre() + ","+ listaAVotar.getNombre() + "," + senador + ",\n diputados= \n" + diputado + "]\n";
	}
}