package Taller;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 * 
 */

/**
 * Crea un objeto de tipo Elector.
 *
 */
public class Elector extends Persona {

	/**
	 * lista domicilios de los electores
	 */
	private Domicilio domicilio;
	/**
	 * lista de mesas 
	 */
	private MesaElectoral mesa;
	/**
	 * control de realizacion de voto
	 */
	private boolean realizoVotacion;

	/**
	 * @param nombre del elector
	 * @param apellido del elector
	 * @param dia de nacimiento del elector
	 * @param mes de nacimiento del elector
	 * @param anio de nacimiento del elector
	 * @param dni de nacimiento del elector
	 * @param direccion del elector
	 */
	public Elector(String nombre, String apellido, int dia, int mes, int anio, 
			int dni, Domicilio direccion) {
		super(nombre, apellido, dia, mes, anio, dni);
		this.domicilio = direccion;
		realizoVotacion=false;
	}
	
	/**
	 * @return devuelve true si el elector ya realizo la votacion
	 */
	public boolean getRealizoVotacion() {
		return realizoVotacion;
	}

	/**
	 * Setea en true el atributo realizoVotacion
	 */
	public void setRealizado() {
		this.realizoVotacion = true;
	}
	
	/**
	 * @return Devuelve un objeto de tipo Domicilio
	 */
	public Domicilio getDomicilio() {
		return this.domicilio;
	}

	/**
	 * @return Devuelve un objeto de tipo MesaElectoral
	 */
	public MesaElectoral getMesa() {
		return this.mesa;
	}

	/**
	 * @param mesa Establece el atributo mesa
	 */
	public void setMesa(MesaElectoral mesa) {
		this.mesa = mesa;
	}

	/**
	 * Devuelve un unico String
	 */
	@Override
	public String toString() {
		return super.toString()+" Elector [direccion: " + domicilio + "]\n";
	}
//	public String toString() {
//		return super.toString() + "," + domicilio;
//	}
}