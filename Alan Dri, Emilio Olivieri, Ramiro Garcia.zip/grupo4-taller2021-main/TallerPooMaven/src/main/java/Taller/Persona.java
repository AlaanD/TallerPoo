package Taller;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *	
 */

/**
 *	Crea un objeto de tipo Persona. La misma es heredad por Elector y Candidato.
 *
 */
public class Persona {

	/**
	 * nombre de la persona
	 */
	protected String nombre;
	/**
	 * apellido de la persona
	 */
	protected String apellido;
	/**
	 * fecha de nacimiento de la persona
	 */
	protected String fechaNacimiento;
	/**
	 * dia de nacimiento de la persona
	 */
	private int dia;
	/**
	 * mes de nacimiento de la persona
	 */
	private int mes;
	/**
	 * anio de nacimiento de la persona
	 */
	private int anio;
	/**
	 * documento de identidad de la persona
	 */
	protected int dni;

	/**
	 * @param nombre de la Persona
	 * @param apellido de la Persona
	 * @param dia de la Persona
	 * @param mes de la Persona
	 * @param anio de la Persona
	 * @param dni de la Persona
	 */
	public Persona(String nombre, String apellido, int dia, int mes, int anio, int dni) {
		this.nombre = nombre;
		this.apellido = apellido;
		setMes(mes);
		setDia(dia);
		this.anio = anio;
		this.setFechaNacimiento(dia, mes, anio);
		this.dni = dni;
	}
	
	/**
	 * @return Devuelve el dia de nacimiento de la persona
	 */
	public int getDia() {
		return dia;
	}
	
	/**
	 * @param dias 
	 * Establece el dia de nacimiento de la persona
	 */
	private void setDia(int dias) {
		int[] meses = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
		if (esBisiesto()) {
			meses[1] = 29;
		}
		if (dias >= 1 && dias <= meses[this.mes - 1]) {
			this.dia = dias;
		} else {
			this.dia = 1;
		}
	}

	/**
	 * @return Devuelve el mes de nacimiento de la persona
	 */
	public int getMes() {
		return mes;
	}
	
	/**
	 * @param mes
	 * Establece el mes de nacimiento de la persona
	 */
	private void setMes(int mes) {
		if (mes <= 12 && mes >= 1) {
			this.mes = mes;
		} else {
			this.mes = 1;
		}
	}

	/**
	 * @return Devuelve el anio de nacimiento de la persona
	 */
	public int getAnio() {
		return anio;
	}
	
	/**
	 * @return Devuelve si el anio es bisiesto
	 */
	private boolean esBisiesto() {
		return (this.anio % 4 == 0 && (this.anio % 100 != 0 || this.anio % 400 == 0));
	}

	/**
	 * @return Devuelve la edad de la persona
	 */
	public int edad() {
		DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate fechaNac = LocalDate.parse(fechaNacimiento, fmt);
		LocalDate ahora = LocalDate.now();

		Period periodo = Period.between(fechaNac, ahora);

		return periodo.getYears();
	}

	/**
	 * @return Devuelve el nombre de la persona
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @return Devuelve el Apellido de la persona
	 */
	public String getApellido() {
		return apellido;
	}

	/**
	 * @return Devuelve la fecha de nacimineto de la persona
	 */
	public String getFechaNacimiento() {
		return fechaNacimiento;
	}

	/**
	 * @param dia
	 * @param mes
	 * @param anio
	 * 
	 * Se establece la fecha de nacimiento de la persona
	 */
	private void setFechaNacimiento( int dia, int mes, int anio) {

		if (dia < 10) {
			this.fechaNacimiento = "0" + dia;
		} else {
			this.fechaNacimiento = "" + dia;
		}

		if (mes < 10) {
			this.fechaNacimiento += "/" + "0" + mes;
		} else {
			this.fechaNacimiento += "/" + mes;
		}
		this.fechaNacimiento += "/" + anio;
	}

	/**
	 * @return Devuelve el dni de la persona
	 */
	public int getDni() {
		return dni;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + dni;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Persona other = (Persona) obj;
		if (dni != other.dni) {
			return false;
		}
		return true;
	}

	
	/**
	 * Devuelve un unico String
	 */
	@Override
	public String toString() {
		return "\nPersona [nombre: " + nombre + ", apellido: " + apellido + ", fechaNacimiento: " + fechaNacimiento
				+ ", dni: " + dni + "]\n";
	}
//	@Override
//	public String toString() {
//		return nombre + "," + apellido + "," + fechaNacimiento+ "," + dni ;
//	}
}