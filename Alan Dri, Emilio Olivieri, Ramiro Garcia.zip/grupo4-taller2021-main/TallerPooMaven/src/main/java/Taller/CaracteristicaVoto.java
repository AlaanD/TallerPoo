package Taller;


/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *
 */

/**
 Los votos se clasifican en
 * BLANCO("EN BLANCO"),
 * VALIDO("VALIDO");
 */
public enum CaracteristicaVoto {
	/**
	 * enumeracion para voto blanco
	 */
	BLANCO("EN BLANCO"),
	/**
	 * enumeracion para votos validos (no blancos)
	 */
	VALIDO("VALIDO");
	
	private final String s;

	private CaracteristicaVoto(String s) {
		this.s = s;
	}

	String getS() {
		return s;
	}
	

}
