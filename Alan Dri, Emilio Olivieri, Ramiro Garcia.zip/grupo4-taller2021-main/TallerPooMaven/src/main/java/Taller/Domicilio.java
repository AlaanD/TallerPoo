package Taller;

import java.util.Objects;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *
 */

/**
 *	Crea un Objeto de tipo domicilio.
 */
public class Domicilio {
	/**
	 * string con la direccion de la persona
	 */
	private String direccion;
	/**
	 * string con la localidad
	 */
	private String localidad;
	/**
	 * string del departamento
	 */
	private String departamento;
	/**
	 * string de la provincia
	 */
	private String provincia;
	
	/**
	 * @param direccion de la persona
	 * @param localidad de la persona
	 * @param departamento donde reside la persona
	 * @param provincia donde reside la persona
	 */
	public Domicilio(String direccion, String localidad, String departamento, String provincia) {
		this.direccion = direccion;
		this.localidad = localidad;
		this.departamento = departamento;
		this.provincia = provincia;
	}
	
	/**
	 * @return devuelve una direccion
	 */
	public String getDireccion() {
		return direccion;
	}
	
	/**
	 * @return Devuelve una localidad
	 */
	public String getLocalidad() {
		return localidad;
	}
	
	/**
	 * @return devuelve un departamento
	 */
	public String getDepartamento() {
		return departamento;
	}
	
	/**
	 * @return Devuelve una provincia
	 */
	public String getProvincia() {
		return provincia;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(departamento, direccion, localidad, provincia);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Domicilio other = (Domicilio) obj;
		return Objects.equals(departamento, other.departamento) && Objects.equals(direccion, other.direccion)
				&& Objects.equals(localidad, other.localidad) && Objects.equals(provincia, other.provincia);
	}
	
	/**
	 * Devuelve un unico String
	 */
	@Override
	public String toString() {
		return "Domicilio [direccion: " + direccion + ", localidad: " + localidad + ", departamento: " + departamento
				+ ", provincia: " + provincia + "]";
	}
//	@Override
//	public String toString() {
//		return direccion + "," + localidad + "," + departamento+ "," + provincia ;
//	}
}