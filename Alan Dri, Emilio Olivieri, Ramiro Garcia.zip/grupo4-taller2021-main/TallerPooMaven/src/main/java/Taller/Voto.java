package Taller;

import java.util.List;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *
 */

/**
 * 	Crea un obejto Voto. puede ser {VALIDO, BLANCO}.
 *
 */
public class Voto {
	
	/**
	 * elemento lista de una lista de listas 
	 */
	private List<Lista> lista;
	/**
	 * elemento de enumeracion
	 */
	private CaracteristicaVoto el_voto;
	
	/**
	 * @param el_voto
	 * CaracteristicaVoto.BLANCO("EN BLANCO"),
     * CaracteristicaVoto.VALIDO("VALIDO");
	 */
	public Voto(CaracteristicaVoto el_voto) {
		this.el_voto = el_voto;
	}

	/**
	 * @return Devuelve el valor del voto, puede ser Valido o Blanco
	 */
	public CaracteristicaVoto getEl_voto() {
		return el_voto;
	}

	/**
	 * Devuelve un unico String
	 */
	@Override
	public String toString() {
		return "Voto [el_voto: " + el_voto + "]";
	}
}
