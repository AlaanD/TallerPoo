package Taller;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *
 *	
 */

/**
 * Crea un objeto de tipo Circuito.
 *	Tambien se encarga de crear las mesas electorales.
 */
public class Circuito {
	private List<MesaElectoral> mesas;
	private int numero;
	private static int generador = 1;
	private String nombreCircuito;
	
	/**
	 * @param nombreCircuito nombre del circuito
	 * @param padronCircuito padron del circuito
	 * @param listasAVotar Listas del circuito
	 */
	public Circuito(String nombreCircuito, List<Elector> padronCircuito, List<Lista> listasAVotar) {
		this.numero = generador++;
		this.nombreCircuito = nombreCircuito;
		this.mesas = new ArrayList<>();
		cargarMesas(padronCircuito, listasAVotar);
	}
	
	/**
	 * c
	 * carga las mesas 
	 */
	private void cargarMesas(List<Elector> padronCircuito, List<Lista> listasAVotar) {
		
		switch (this.nombreCircuito) {
			case "Goya Norte": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Ituzaingo Norte": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Esquina Norte": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Caballito Norte": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Palermo Norte": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Recoleta Norte": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Parana Norte": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Concordia Norte": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Gualeguaychu Norte": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Iguazu Norte": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Obera Norte": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Apostoles Norte": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Tandil Norte": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Olavarria Norte": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "La Plata Norte": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Goya Sur": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Ituzaingo Sur": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Esquina Sur": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Caballito Sur": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Palermo Sur": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Recoleta Sur": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Parana Sur": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Concordia Sur": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Gualeguaychu Sur": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Iguazu Sur": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Obera Sur": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Apostoles Sur": {
				ListaMesa(padronCircuito, listasAVotar);;
				break;
			}
			case "Tandil Sur": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "Olavarria Sur": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			case "La Plata Sur": {
				ListaMesa(padronCircuito, listasAVotar);
				break;
			}
			default:
				break;
			}
	}
		
	/**
	 * @param padronCircuito padron correspondiente a cada circuito
	 * @param listasAVotar listas que se presentan en el circuito
	 * genera las mesas desde los electores que recibe, y las listas del distrito 
	 */
	private void ListaMesa(List<Elector> padronCircuito, List<Lista> listasAvotar) {
//		total += padronCircuito.size();
		Elector[] electores = new Elector[350];
	
		if (padronCircuito.size() < 350 && !padronCircuito.isEmpty()) {
			for (int i = 0; i < padronCircuito.size(); i++) {
				electores[i] = padronCircuito.get(i);
			}
			try {
				mesas.add(new MesaElectoral(electores[0], electores[1], electores, listasAvotar));
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			List<Elector> padronMesa = padronCircuito;
			while (padronMesa.size() > 350) {
				electores = new Elector[350];
				//cargar electores al array
				for (int i = 0; i < 350; i++) {
					electores[i] = padronMesa.get(i);
				}
				//elimino lo cargado
				for (int i = 0; i < 350; i++) {
					if(padronMesa.get(0)!=null)
						padronMesa.remove(0);
				}
				try {
				
					mesas.add(new MesaElectoral(electores[0], electores[1], electores, listasAvotar));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (!padronMesa.isEmpty()) {
				electores = new Elector[350];
				//cargar electores al array
				for (int i = 0; i < padronMesa.size(); i++) {
					electores[i] = padronMesa.get(i);
				}
				try {
					mesas.add(new MesaElectoral(electores[0], electores[1], electores, listasAvotar));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * @return devuelve una List de tipo MesaElectoral
	 */
	public List<MesaElectoral> getMesas() {
		return this.mesas;
	}

	/**
	 * @return devuelve el numero de la mesa
	 */
	public int getNumero() {
		return this.numero;
	}
	
	/**
	 * @return devuelve el nombre del circuito
	 */
	public String getNombreCircuito() {
		return nombreCircuito;
	}


	/**
	 * Devuelve un unico String
	 */
	@Override
	public String toString() {
		return "Nombre Circuito: " + nombreCircuito  +", nro circuito: "+ this.numero  + ", mesas= " + mesas+"]\n";
	}
}