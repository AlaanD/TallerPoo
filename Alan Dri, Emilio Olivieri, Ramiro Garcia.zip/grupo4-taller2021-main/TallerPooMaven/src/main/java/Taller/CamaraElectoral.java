package Taller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.swing.JOptionPane;

import GenerarCSV.Datos;

import java.util.Iterator;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *
 */

/**
 * Crea un objeto de CamaraElectoral. Esta se encarga de crear los distritos,
 * cargar los padrones, y las listas de los mismo.
 */
public class CamaraElectoral implements EstadisticaEleccion {

	/**
	 * elemento tipo lista elector
	 */
	private List<Elector> padronGeneral;
	/**
	 * elemento tipo lista elector
	 */
	private List<Elector> padronCABA = new ArrayList<>();
	/**
	 * elemento tipo lista elector
	 */
	private List<Elector> padronBsAs = new ArrayList<>();
	/**
	 * elemento tipo lista elector
	 */
	private List<Elector> padronCorrientes = new ArrayList<>();
	/**
	 * elemento tipo lista elector
	 */
	private List<Elector> padronEntreRios = new ArrayList<>();
	/**
	 * elemento tipo lista elector
	 */
	private List<Elector> padronMisiones = new ArrayList<>();
	/**
	 * elemento tipo lista candidato
	 */
	private List<Candidato> registroCandidatos;
	/**
	 * elemento tipo lista candidato
	 */
	private List<Candidato> candidatosCABA;
	/**
	 * elemento tipo lista candidato
	 */
	private List<Candidato> candidatosBsAs;
	/**
	 * elemento tipo lista candidato
	 */
	private List<Candidato> candidatosCorrientes;
	/**
	 * elemento tipo lista candidato
	 */
	private List<Candidato> candidatosEntreRios;
	/**
	 * elemento tipo lista candidato
	 */
	private List<Candidato> candidatosMisiones;
	/**
	 * elemento tipo lista distrito
	 */
	private List<Distrito> distritos;
	/**
	 * elemento tipo lista lista
	 */
	private List<Lista> verificaLista;
	
	/**
	 * crea un objeto camara electoral
	 */
	public CamaraElectoral() {
		this.padronGeneral = new ArrayList<>();
		this.distritos = new ArrayList<>();
		this.verificaLista = new ArrayList<>();
		this.candidatosCABA = new ArrayList<>();
		this.candidatosBsAs = new ArrayList<>();
		this.candidatosCorrientes = new ArrayList<>();
		this.candidatosMisiones = new ArrayList<>();
		this.candidatosEntreRios = new ArrayList<>();
		this.registroCandidatos = new ArrayList<>();
		cargarElectores();
		cargarCandidatos();
		padronDistritos();
		filtrarCandidatos();
		establecerDistritos();
	}

	/**
	 * crea los distritos
	 */
	private void establecerDistritos() {
		distritos.add(new Distrito("Corrientes", 5, padronCorrientes, candidatosCorrientes));
		distritos.add(new Distrito("Buenos Aires", 5, padronBsAs, candidatosBsAs));
		distritos.add(new Distrito("CABA", 5, padronCABA, candidatosCABA));
		distritos.add(new Distrito("Misiones", 5, padronMisiones, candidatosMisiones));
		distritos.add(new Distrito("Entre Rios", 5, padronEntreRios, candidatosEntreRios));
	}

	/**
	 * 
	 * @param cargamos los candidatos de un archivo .csv
	 * usando expresiones regulares. Y luego
	 * se agrega a la lista de registroCandidatos
	 * 
	 */
	private void cargarCandidatos() {
		List<String> canditatos = new ArrayList<String>();

		try {
			FileReader datos = new FileReader(new File(	"src\\main\\java\\candidatos.csv"));

			BufferedReader bf = new BufferedReader(datos);
			String linea = "";
			while (linea != null) {
				linea = bf.readLine();
				if (linea != null) {
					canditatos.add(linea);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		for (String e : canditatos) {

			
			Pattern p;
			Matcher m;
			p = Pattern.compile("(.+),(.+),(.*),(\\d+),(.+),(.+),(.+),(.*),(.*),(\\w*)");
			m = p.matcher(e);

			if (m.find()) {
				String nombre = m.group(1);
				String apellido = m.group(2);
				String nacimiento = m.group(3);
				String fecha[] = nacimiento.split("/");

				int dia = Integer.parseInt(fecha[0]);
				int mes = Integer.parseInt(fecha[1]);
				int anio = Integer.parseInt(fecha[2]);
				int documento = Integer.parseInt(m.group(4));
				String cargo = m.group(5);
				String direccion = m.group(6);
				String localidad = m.group(7);
				String departamento = m.group(8);
				String provincia = m.group(9);

				this.registroCandidatos.add(new Candidato(nombre.trim(), apellido.trim(), dia, mes, anio, documento,
						cargo.trim(),
						new Domicilio(direccion.trim(), localidad.trim(), departamento.trim(), provincia.trim())));
			}
		}
	}

	/**
	 * carga electores de un archivo csv 
	 * usando expresiones regulares 
	 * 
	 * */
	private void cargarElectores() {
		List<String> electores = new ArrayList<String>();
		List<Integer> DNIElectores= new ArrayList<Integer>();
		try {
			FileReader datos = new FileReader(new File(	"src\\main\\java\\electores.csv"));

			BufferedReader bf = new BufferedReader(datos);
			String linea = "";
			while (linea != null) {
				linea = bf.readLine();
				if (linea != null) {
					
					electores.add(linea);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (String e : electores) {

			Pattern p;
			Matcher m;
			p = Pattern.compile("(.+),(.+),(.*),(\\d+),(.+),(.+),(.*),(.*),(\\w*)");
			m = p.matcher(e);

			if (m.find()) {
				String nombre = m.group(1);
				String apellido = m.group(2);
				String nacimiento = m.group(3);
				String fecha[] = nacimiento.split("/");

				int dia = Integer.parseInt(fecha[0]);
				int mes = Integer.parseInt(fecha[1]);
				int anio = Integer.parseInt(fecha[2]);
				int documento = Integer.parseInt(m.group(4));
				
				
				String direccion = m.group(5);
				String localidad = m.group(6);
				String departamento = m.group(7);
				String provincia = m.group(8);

				
				switch (departamento) {
				case "Goya": {
					provincia = "Corrientes";
					break;
				}
				case "Ituzaingo": {
					provincia = "Corrientes";
					break;
				}
				case "Esquina": {
					provincia = "Corrientes";
					break;
				}
				case "Caballito": {
					provincia = "Buenos Aires";
					break;
				}
				case "Palermo": {
					provincia = "Buenos Aires";
					break;
				}
				case "Recoleta": {
					provincia = "Buenos Aires";
					break;
				}
				case "Parana": {
					provincia = "Entre Rios";
					break;
				}
				case "Concordia": {
					provincia = "Entre Rios";
					break;
				}
				case "Gualeguaychu": {
					provincia = "Entre Rios";
					break;
				}
				case "Iguazu": {
					provincia = "Misiones";
					break;
				}
				case "Obera": {
					provincia = "Misiones";
					break;
				}
				case "Apostoles": {
					provincia = "Misiones";
					break;
				}
				case "Tandil": {
					provincia = "CABA";
					break;
				}
				case "Olavarria": {
					provincia = "CABA";
					break;
				}
				case "La Plata": {
					provincia = "CABA";
					break;
				}
				default:
					break;

				}

				if(DNIElectores.contains(documento)) {
					JOptionPane.showMessageDialog(null, "El DNI: "+documento+ ", ya se encuentra en el padron. ");
				}else {
					DNIElectores.add(documento);
					padronGeneral.add(new Elector(nombre, apellido, dia, mes, anio, documento,
							new Domicilio(direccion, localidad, departamento, provincia.trim())));
				}
			}
		}
	}

	/**
	 * filtramos los candidatos por distrito
	 */
	private void filtrarCandidatos() {

		Iterator<Candidato> it = registroCandidatos.iterator();
		Candidato e;
		while (it.hasNext()) {
			e = it.next();
			switch (e.getDomicilio().getProvincia()) {
			case "Buenos Aires": {
				candidatosBsAs.add(e);
				break;
			}
			case "CABA": {
				candidatosCABA.add(e);
				break;
			}
			case "Corrientes": {
				candidatosCorrientes.add(e);
				break;
			}
			case "Entre Rios": {
				candidatosEntreRios.add(e);
				break;
			}
			case "Misiones": {
				candidatosMisiones.add(e);
				break;
			}
			default:
				break;
			}
		}
	}

	/**
	 * filtramos electores por distrito
	 */
	private void padronDistritos() {
		Iterator<Elector> it = padronGeneral.iterator();

		while (it.hasNext()) {
			Elector e = it.next();
			switch (e.getDomicilio().getProvincia()) {
			case "Buenos Aires": {
				padronBsAs.add(e);
				break;
			}
			case "CABA": {
				padronCABA.add(e);
				break;
			}
			case "Corrientes": {
				padronCorrientes.add(e);
				break;
			}
			case "Entre Rios": {
				padronEntreRios.add(e);
				break;
			}
			case "Misiones": {
				padronMisiones.add(e);
				break;
			}
			default:
				break;
			}
		}
	}

	/**
	 * @return 
	*	devuelve una List de tipo elector
	 */
	public List<Elector> getPadronGeneral() {
		return padronGeneral;
	}

	/**
	 * @return
	 * devuelve una List de tipo Distrito
	 */
	public List<Distrito> getControlaDistrito() {
		return distritos;
	}

	/**
	 * @return
	 * devuelve List de tipo Lista
	 */
	public List<Lista> getVerificaLista() {
		return verificaLista;
	}

	

	/**
	 *@return int cantidad de votos en blanco de todos los distritos
	 *
	 */
	@Override
	public int cantidadVotosBlancos() {
		
		AtomicInteger votos = new AtomicInteger();
		this.distritos.stream().forEach((d) -> {
			d.getConformaSecciones().stream().forEach((p) -> {
				p.getCircuito().forEach((c) -> {
					c.getMesas().stream().forEach((m) -> {
						votos.set((int) (votos.get() + m.getUrna().stream()
								.filter(i -> i.getEl_voto() == CaracteristicaVoto.BLANCO).count()));
					});
				});
			});
		});
		return votos.get();
	}

	
	/**
	 *@return cantidad de votos en validos de todos los distritos
	 */
	@Override
	public int cantidadVotosValidos() {
		AtomicInteger votos = new AtomicInteger();
		this.distritos.stream().forEach((d) -> {
			d.getConformaSecciones().stream().forEach((p) -> {
				p.getCircuito().forEach((c) -> {
					c.getMesas().stream().forEach((m) -> {
						votos.set((int) (votos.get() + m.getUrna().stream()
								.filter(i -> i.getEl_voto() == CaracteristicaVoto.VALIDO).count()));
					});
				});
			});
		});
		return votos.get();
	}

	/**
	 *@return cantidad de votos porcentaje blanco de todos los distritos
	 **	devuelve 0, si la cantidad de votos totales es 0
	 */
	@Override
	public double porcentajeVotosBlancos() {
		double x = (double) this.cantidadVotosBlancos();
		if (cantidadVotosTotales() > 0) {
			return (x / cantidadVotosTotales()) * 100;
		} else {
			return 0;
		}
	}

	/**
	 *@return cantidad de votos totales
	 */
	@Override
	public int cantidadVotosTotales() {
		return this.cantidadVotosBlancos() + this.cantidadVotosValidos();
	}

	/**
	 *	 *@return porcentaje Votos Validos
	 *	devuelve 0, si la cantidad de votos totales es 0
	 */
	@Override
	public double porcentajeVotosValidos() {
		// TODO Auto-generated method stub
		double x = (double) this.cantidadVotosValidos();
		if (cantidadVotosTotales() > 0) {
			return (x / cantidadVotosTotales()) * 100;
		} else {
			return 0;
		}
	}
}