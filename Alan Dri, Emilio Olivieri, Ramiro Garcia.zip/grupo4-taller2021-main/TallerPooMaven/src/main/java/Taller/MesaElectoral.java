package Taller;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *
 */

/**
 * 	Crea un objeto de MesaElectoral.
 * 
 */
public class MesaElectoral {
	/**
	 * elemento presidente de la lista elector
	 */
	private Elector presidente;
	/**
	 * elemento del auxiliar de la lista elector
	 */
	private Elector auxiliar;
	/**
	 * urna de la lista de votos
	 */
	private List<Voto> urna;
	/**
	 * padron particular de electores
	 */
	private Elector[] padronParticular;
	/**
	 * generador de datos tipo entero
	 */
	private static int generador = 1;
	/**
	 * codigo de identificacion
	 */
	private int id;
	/**
	 * lista a votar de la lista de listas
	 */
	private List<Lista> listaAVotar;

	/**
	 * @param presidente de la mesa
	 * @param auxiliar de la mesa
	 * @param padron de la mesa
	 * @param listaAVotar de la mesa
	 * @throws Exception de la mesa
	 */
	public MesaElectoral(Elector presidente, Elector auxiliar, Elector[] padron, List<Lista> listaAVotar) throws Exception {
		this.presidente = presidente;
		this.auxiliar = auxiliar;
		this.listaAVotar = listaAVotar;
		this.setPadron(padron);
		this.urna = new ArrayList();
		//hago que los numeros de mesa se generen solos y no se repitan
		this.id=generador++;
		
		if(auxiliar!=null) {
			this.auxiliar.setMesa(this);
			
			if(presidente!=null) {
				this.presidente.setMesa(this);
			}
			for (int i = 0; i < padron.length; i++) { 
				if(padron[i]!=null)
					padron[i].setMesa(this);
			}
		}
	}
	
	/**
	 * @return Devuelve un id unico de la mesa
	 */
	public int getId() {
		return id;
	}
	
	/**
	 * @return Devuelve el padron de electores de la mesa
	 */
	public Elector[] getPadron() {
		return padronParticular;
	}
	
	/**
	 * @param padron electoral 
	 * @throws Exception excepcion cuando el padron excede el maximo de electores
	 * Se establece el padron de la mesa
	 *
	 */
	private void setPadron(Elector[] padron) throws Exception {
		if (padron.length <= 350) {
			padronParticular = padron;
		} else {
			throw new Exception("el padron contiene mas de 350 electores");
		}
	}

	/**
	 * @param voto  elemento tipo voto
	 * Se agrega un voto
	 */
	public void addVoto(Voto voto) {
		this.urna.add(voto);
	}

	/**
	 * @return Devuelve el presidente de la mesa
	 */
	public Elector getPresidente() {
		return presidente;
	}
	
	/**
	 * @return Devuelve el auxiliar de la mesa
	 */
	public Elector getAuxiliar() {
		return auxiliar;
	}

	/**
	 * @return Devuelve una List de tipo Voto
	 */
	public List<Voto> getUrna() {
		return urna;
	}
	
	/**
	 * Devuelve un unico String
	 */
	@Override
	public String toString() {
		return "MesaElectoral numero: "+ this.id + ", \npresidente: " + presidente + ",\n auxiliar: " + auxiliar + " ]\n";
	}
}