package Taller;

import java.util.List;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *	
 */

/**
 * Crea un objeto de tipo Alianza.
 */
public class Alianza {
	private String nombre ;
	private List<PartidoPolitico> partidos;
	
	/**
	 * @param nombre nombre de la alianza
	 * @param partidos conjunto de partidos politicos por la alianza
	 */
	public Alianza(String nombre, List<PartidoPolitico> partidos) {
		this.nombre = nombre;
		this.partidos = partidos;
	}
	
	/**
	 * @return retorna nombre de la alianza
	 */
	public String getNombre() {
		return nombre;
	}
	
//	public void setNombre(String nombre) {
//		this.nombre = nombre;
//	}
	
	/**
	 * @return retorna una List de tipo PartidoPolitico 
	 */
	public List<PartidoPolitico> getPartidos() {
		return partidos;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		result = prime * result + ((partidos == null) ? 0 : partidos.hashCode());
		return result;
	}

	/**
	 * equals por nombre de alianza
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Alianza other = (Alianza) obj;
		if (nombre == null) {
			if (other.nombre != null) {
				return false;
			}
		} else if (!nombre.equals(other.nombre)) {
			return false;
		}
		if (partidos == null) {
			if (other.partidos != null) {
				return false;
			}
		} else if (!partidos.equals(other.partidos)) {
			return false;
		}
		return true;
	}

	/**
	 * Devuelve un unico String
	 */
	@Override
	public String toString() {
		return "Alianza [nombre: "+nombre +  "\n, partidos: \n" + partidos + "]\n";
	}
}