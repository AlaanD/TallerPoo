package Taller;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *	
 */
/**
 *	Realiza el calculo estadistico. Es implementa en CamaraElectoral y Distrito.
 */
public interface EstadisticaEleccion {
	
	/**
	 * @return Devuelve cantidad de votos blancos
	 */
	public int cantidadVotosBlancos();
	
	/**
	 * @return Devuelve cantidad de votos validos
	 */
	public int cantidadVotosValidos();
	
	/**
	 * @return Devuelve porcentajes de votos blancos
	 */
	public double porcentajeVotosBlancos();
	
	/**
	 * @return Devuelve porcentajes de votos validos
	 */
	public double porcentajeVotosValidos();
	
	/**
	 * @return Devuelve cantidad de votos totales
	 */
	public int cantidadVotosTotales();
}
