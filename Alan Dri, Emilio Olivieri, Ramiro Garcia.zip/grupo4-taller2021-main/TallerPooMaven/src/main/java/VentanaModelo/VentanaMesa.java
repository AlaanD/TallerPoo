package VentanaModelo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Optional;

import javax.swing.*;

import Taller.CamaraElectoral;
import Taller.Elector;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *
 */

/**
 * 	Crea la interfaz grafica donde el elector consulta su mesa.
 *
 */
public class VentanaMesa extends JFrame {

	/**
	 * panel panelMesa
	 */
	private JPanel panelMesa;
	/**
	 * etiqueta etiquetaDocumento
	 */
	private JLabel etiquetaDocumento;
	/**
	 * campo de texto casillero
	 */
	private JTextField casillero;
	/**
	 * boton botonContinuar
	 */
	private JButton botonContinuar;

	/**
	 * @param padron
	 * Se crea la ventana mesa donde el usuario ingresa su dni y el sistema le devuelve
	 * si esta en el padron electoral y el numero de mesa que le corresponde
	 */
	public VentanaMesa(CamaraElectoral padron) {

		super("Elecciones Primarias 2021");

		Toolkit kitMesa = Toolkit.getDefaultToolkit();

		Dimension pantallaMesa = kitMesa.getScreenSize();

		int altoPantallaMesa = pantallaMesa.height;
		int anchoPantallaMesa = pantallaMesa.width;

		iniciarComponentes(padron);
		setExtendedState(MAXIMIZED_BOTH);

		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);

	}

	private void iniciarComponentes(CamaraElectoral padron) {

		// creo panel

		panelMesa = new JPanel();
		panelMesa.setLayout(null);

		this.getContentPane().add(panelMesa);

		// creo etiqueta

		etiquetaDocumento = new JLabel("Ingrese su numero de documento");

		Font fuenteEtiqueta = new Font("Arial", Font.BOLD, 20);

		etiquetaDocumento.setHorizontalAlignment(SwingConstants.CENTER);
		etiquetaDocumento.setFont(fuenteEtiqueta);
		etiquetaDocumento.setBounds(60, 60, 400, 40);
		etiquetaDocumento.setOpaque(true);
		etiquetaDocumento.setBackground(Color.BLACK);
		etiquetaDocumento.setForeground(Color.WHITE);
		panelMesa.add(etiquetaDocumento);

		casillero = new JTextField();

		Font fuenteCampo = new Font("Arial", Font.ITALIC, 16);

		casillero.setBounds(60, 110, 400, 40);
		casillero.setFont(fuenteCampo);
		panelMesa.add(casillero);

		botonContinuar = new JButton();

		Font fuenteBoton = new Font("Arial", Font.BOLD, 18);

		botonContinuar.setText("Continuar");
		botonContinuar.setFont(fuenteBoton);
		botonContinuar.setBounds(250, 170, 200, 40);

		ActionListener eventoMesa = new ActionListener() {
			int dniIngresado;

			@Override
			public void actionPerformed(ActionEvent e) {

				int respuesta = -1;
				// controlamos que el casillero no este vacio, luego que solo sean numeros, y que la longitud no supere el maximo del tipo de dato int
				if (!casillero.getText().isEmpty() && casillero.getText().matches("[0-9]*") 
						&& casillero.getText().length()<10) {
					
					dniIngresado = Integer.parseInt(casillero.getText());
					Optional<Elector> elector = padron.getPadronGeneral().stream()
							.filter(i -> i.getDni() == dniIngresado).findFirst();
					if (!elector.isEmpty()) {

						if (respuesta < 0) {

							respuesta = JOptionPane.showConfirmDialog(null, "Su DNI es: " + elector.get().getDni());
							if (respuesta == 0) {
								JOptionPane.showMessageDialog(null, elector.get().getMesa());
								dispose();
								VentanaMenu menu = new VentanaMenu(padron);
							} else
								casillero.setText("");
						
						} 
						
					} else {
						JOptionPane.showMessageDialog(null, "DNI no encontrado");
						casillero.setText("");
					}
				} else {// en caso de no ingresar nada
					JOptionPane.showMessageDialog(null, "Ingresar DNI por favor");
					casillero.setText("");
				}
			}
		};
		panelMesa.add(botonContinuar);
		botonContinuar.addActionListener(eventoMesa);
	}
}