package VentanaModelo;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;


import Cliente.Cliente;
import Taller.CamaraElectoral;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *	
 */

/**
 * Crea la interfaz grafica donde el Elector consulta su mesa donde realizara el voto,
 * o bien acceder a la ventana votacion.
 */
public class VentanaMenu extends JFrame {
	
	/**
	 * boton abreMesa
	 */
	private JButton abreMesa;
	/**
	 * boton abreVoto
	 */
	private JButton abreVoto;
	/**
	 * lista electores
	 */
	private CamaraElectoral electores;

	/**
	 * @param electores recibe un objeto de tipo CamaraElectoral
	 * Ventama principal del frame, nos da la opcion de elegir ir a votacion o consultar la mesa 
	 * en la cual votar
	 */
	public VentanaMenu(CamaraElectoral electores) {
		this.electores = electores;
		setTitle("Menu Elecciones Primarias 2021");
		setSize(1000, 600);
		setLocationRelativeTo(null);
		
		

		setDefaultCloseOperation(EXIT_ON_CLOSE);

		JPanel panel = new JPanel();

		JLabel etiquetaMenu = new JLabel("Elecciones Primarias 2021");
		
		etiquetaMenu.setSize(800, 40);
		Font fuente = new Font("Courier",Font.BOLD,20);
		etiquetaMenu.setHorizontalAlignment(SwingConstants.CENTER);
		etiquetaMenu.setVerticalAlignment(SwingConstants.CENTER);
		etiquetaMenu.setFont(fuente);
		JLabel etiquetaMenu2 = new JLabel("Elija una opcion");

		etiquetaMenu2.setSize(800, 40);
		etiquetaMenu2.setHorizontalAlignment(SwingConstants.CENTER);
		etiquetaMenu2.setVerticalAlignment(SwingConstants.CENTER);

		abreMesa = new JButton("Obtener Mesa");
		abreMesa.setSize(400, 40);

		abreVoto = new JButton("Realizar Voto");
		abreMesa.setSize(400, 40);

		ActionListener botonMenu = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				if (e.getSource() == abreMesa) {
					dispose();
					VentanaMesa ventanaM = new VentanaMesa(electores);
				}
				if (e.getSource() == abreVoto) {
					dispose();
					VentanaVotoCamaraV2 ventanaV = new VentanaVotoCamaraV2(electores);
					Thread hilo = new Thread(ventanaV);
					hilo.start();
				}
			}
		};
		abreMesa.addActionListener(botonMenu);
		abreVoto.addActionListener(botonMenu);

		// adiciono elementos al JPanel

		panel.add(etiquetaMenu);
		panel.add(etiquetaMenu2);
		panel.add(abreMesa);
		panel.add(abreVoto);
		add(panel);
		setVisible(true);
	}
}