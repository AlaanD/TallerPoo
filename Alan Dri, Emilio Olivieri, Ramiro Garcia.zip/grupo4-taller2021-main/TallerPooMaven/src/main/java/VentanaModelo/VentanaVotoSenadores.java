package VentanaModelo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;

import Cliente.Cliente;
import Cliente.Cliente;
import Taller.CamaraElectoral;
import Taller.CaracteristicaVoto;
import Taller.Distrito;
import Taller.Elector;
import Taller.Voto;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *
 */

/**
 * Crea una interfaz grafica donde el elector vota a los senadores de su distrito.
 */
public class VentanaVotoSenadores extends JFrame {

	/**
	 * panel utilizado en el frame
	 */
	private JPanel contentPane;
	/**
	 * elemento entero con el codigo interno de voto
	 */
	private int codigovotacion;
	/**
	 * lista tipo camara electoral
	 */
	private CamaraElectoral camara;

	/**
	 * @param elector lista con atributos de la persona elector
	 * @param camara lista tipo camara electoral
	 * @param distrito lista tipo distrito
	 * @param codigovotacion elemento tipo entero creado segun codigo interno
	 * 
	 * Se crea la ventana de votacion de los senadores
	 */
	public VentanaVotoSenadores(Elector elector, CamaraElectoral camara, Distrito distrito, int codigovotacion) {
		this.camara = camara;
		this.codigovotacion = codigovotacion;
		setTitle("Senadores " + distrito.getNombre());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 490);
		setResizable(false);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		JPanel panel_4 = new JPanel();
		panel_4.setPreferredSize(new Dimension(0, 350));
		contentPane.add(panel_4, BorderLayout.NORTH);

		JPanel panel = new JPanel();
		panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, Color.BLACK, null));
		panel_4.add(panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[] { 0, 36, 0, 0, 0, 0, 0 };
		gbl_panel.rowHeights = new int[] { 0, 0, 0, 0 };
		gbl_panel.columnWeights = new double[] { 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE };
		gbl_panel.rowWeights = new double[] { 0.0, 1.0, 0.0, Double.MIN_VALUE };
		panel.setLayout(gbl_panel);

		JLabel nombreLista = new JLabel(distrito.getListasAVotar().get(0).getNombre());
		GridBagConstraints gbc_nombreLista = new GridBagConstraints();
		gbc_nombreLista.insets = new Insets(0, 0, 5, 5);
		gbc_nombreLista.gridx = 0;
		gbc_nombreLista.gridy = 0;
		panel.add(nombreLista, gbc_nombreLista);

		JLabel senadorL1 = new JLabel("Senadores");
		GridBagConstraints gbc_diputadosL1 = new GridBagConstraints();
		gbc_diputadosL1.insets = new Insets(0, 0, 5, 5);
		gbc_diputadosL1.gridx = 2;
		gbc_diputadosL1.gridy = 0;
		panel.add(senadorL1, gbc_diputadosL1);

		JCheckBox votoListaCompleta1 = new JCheckBox("Votar Lista Completa");
		GridBagConstraints gbc_votoListaCompleta1 = new GridBagConstraints();
		gbc_votoListaCompleta1.insets = new Insets(0, 0, 5, 5);
		gbc_votoListaCompleta1.gridx = 0;
		gbc_votoListaCompleta1.gridy = 1;
		panel.add(votoListaCompleta1, gbc_votoListaCompleta1);

		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new EtchedBorder(EtchedBorder.LOWERED, Color.BLACK, null));
		panel_4.add(panel_1);
		GridBagLayout gbl_panel_1 = new GridBagLayout();
		gbl_panel_1.columnWidths = new int[] { 0, 36, 0, 0, 0, 0 };
		gbl_panel_1.rowHeights = new int[] { 0, 0, 0, 0 };
		gbl_panel_1.columnWeights = new double[] { 0.0, 1.0, 0.0, 0.0, 0.0, Double.MIN_VALUE };
		gbl_panel_1.rowWeights = new double[] { 0.0, 1.0, 0.0, Double.MIN_VALUE };
		panel_1.setLayout(gbl_panel_1);

		JLabel nombreLista2 = new JLabel(distrito.getListasAVotar().get(1).getNombre());
		GridBagConstraints gbc_nombreLista2 = new GridBagConstraints();
		gbc_nombreLista2.insets = new Insets(0, 0, 5, 5);
		gbc_nombreLista2.gridx = 0;
		gbc_nombreLista2.gridy = 0;
		panel_1.add(nombreLista2, gbc_nombreLista2);

		JLabel senadorL2 = new JLabel("Senadores");
		GridBagConstraints gbc_diputadosL2 = new GridBagConstraints();
		gbc_diputadosL2.insets = new Insets(0, 0, 5, 5);
		gbc_diputadosL2.gridx = 2;
		gbc_diputadosL2.gridy = 0;
		panel_1.add(senadorL2, gbc_diputadosL2);

		JCheckBox votoListaCompleta2 = new JCheckBox("Votar Lista Completa");
		GridBagConstraints gbc_votoListaCompleta2 = new GridBagConstraints();
		gbc_votoListaCompleta2.insets = new Insets(0, 0, 5, 5);
		gbc_votoListaCompleta2.gridx = 0;
		gbc_votoListaCompleta2.gridy = 1;
		panel_1.add(votoListaCompleta2, gbc_votoListaCompleta2);

		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new EtchedBorder(EtchedBorder.LOWERED, Color.BLACK, null));
		panel_4.add(panel_2);
		GridBagLayout gbl_panel_2 = new GridBagLayout();
		gbl_panel_2.columnWidths = new int[] { 0, 36, 0, 0, 0, 0 };
		gbl_panel_2.rowHeights = new int[] { 0, 0, 0, 0 };
		gbl_panel_2.columnWeights = new double[] { 0.0, 1.0, 0.0, 0.0, 0.0, Double.MIN_VALUE };
		gbl_panel_2.rowWeights = new double[] { 0.0, 1.0, 0.0, Double.MIN_VALUE };
		panel_2.setLayout(gbl_panel_2);

		JLabel nombreLista3 = new JLabel(distrito.getListasAVotar().get(2).getNombre());
		GridBagConstraints gbc_nombreLista3 = new GridBagConstraints();
		gbc_nombreLista3.insets = new Insets(0, 0, 5, 5);
		gbc_nombreLista3.gridx = 0;
		gbc_nombreLista3.gridy = 0;
		panel_2.add(nombreLista3, gbc_nombreLista3);

		JLabel senadorL3 = new JLabel("Senadores");
		GridBagConstraints gbc_diputadosl3 = new GridBagConstraints();
		gbc_diputadosl3.insets = new Insets(0, 0, 5, 5);
		gbc_diputadosl3.gridx = 2;
		gbc_diputadosl3.gridy = 0;
		panel_2.add(senadorL3, gbc_diputadosl3);

		JCheckBox votoListaCompleta3 = new JCheckBox("Votar Lista Completa");
		GridBagConstraints gbc_votoListaCompleta3 = new GridBagConstraints();
		gbc_votoListaCompleta3.insets = new Insets(0, 0, 5, 5);
		gbc_votoListaCompleta3.gridx = 0;
		gbc_votoListaCompleta3.gridy = 1;
		panel_2.add(votoListaCompleta3, gbc_votoListaCompleta3);

		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new EtchedBorder(EtchedBorder.LOWERED, Color.BLACK, null));
		panel_4.add(panel_3);
		GridBagLayout gbl_panel_3 = new GridBagLayout();
		gbl_panel_3.columnWidths = new int[] { 0, 36, 0, 0, 0, 0 };
		gbl_panel_3.rowHeights = new int[] { 0, 0, 0, 0 };
		gbl_panel_3.columnWeights = new double[] { 0.0, 1.0, 0.0, 0.0, 0.0, Double.MIN_VALUE };
		gbl_panel_3.rowWeights = new double[] { 0.0, 1.0, 0.0, Double.MIN_VALUE };
		panel_3.setLayout(gbl_panel_3);

		JLabel nombreLista4 = new JLabel(distrito.getListasAVotar().get(3).getNombre());
		GridBagConstraints gbc_nombreLista4 = new GridBagConstraints();
		gbc_nombreLista4.insets = new Insets(0, 0, 5, 5);
		gbc_nombreLista4.gridx = 0;
		gbc_nombreLista4.gridy = 0;
		panel_3.add(nombreLista4, gbc_nombreLista4);

		JLabel senadorL4 = new JLabel("Senadores");
		GridBagConstraints gbc_diputadosL4 = new GridBagConstraints();
		gbc_diputadosL4.insets = new Insets(0, 0, 5, 5);
		gbc_diputadosL4.gridx = 2;
		gbc_diputadosL4.gridy = 0;
		panel_3.add(senadorL4, gbc_diputadosL4);

		JCheckBox votoListaCompleta4 = new JCheckBox("Votar Lista Completa");
		GridBagConstraints gbc_votoListaCompleta4 = new GridBagConstraints();
		gbc_votoListaCompleta4.insets = new Insets(0, 0, 5, 5);
		gbc_votoListaCompleta4.gridx = 0;
		gbc_votoListaCompleta4.gridy = 1;
		panel_3.add(votoListaCompleta4, gbc_votoListaCompleta4);

		JPanel panel_5 = new JPanel();
		contentPane.add(panel_5, BorderLayout.SOUTH);
		GridBagLayout gbl_panel_5 = new GridBagLayout();
		gbl_panel_5.columnWidths = new int[] { 77, 97, 150, 71, 105, 0, 0, 0, 0 };
		gbl_panel_5.rowHeights = new int[] { 23, 0 };
		gbl_panel_5.columnWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE };
		gbl_panel_5.rowWeights = new double[] { 0.0, Double.MIN_VALUE };
		panel_5.setLayout(gbl_panel_5);

		JCheckBox checkBlanco = new JCheckBox("Voto en blanco");
		checkBlanco.setHorizontalAlignment(SwingConstants.LEFT);
		GridBagConstraints gbc_checkBlanco = new GridBagConstraints();
		gbc_checkBlanco.anchor = GridBagConstraints.NORTHWEST;
		gbc_checkBlanco.insets = new Insets(0, 0, 0, 5);
		gbc_checkBlanco.gridx = 1;
		gbc_checkBlanco.gridy = 0;
		panel_5.add(checkBlanco, gbc_checkBlanco);

		JSeparator separator = new JSeparator();
		separator.setPreferredSize(new Dimension(150, 0));
		GridBagConstraints gbc_separator = new GridBagConstraints();
		gbc_separator.anchor = GridBagConstraints.WEST;
		gbc_separator.insets = new Insets(0, 0, 0, 5);
		gbc_separator.gridx = 2;
		gbc_separator.gridy = 0;
		panel_5.add(separator, gbc_separator);

		JButton btnFinalizar = new JButton("Finalizar");
		btnFinalizar.setVerticalAlignment(SwingConstants.BOTTOM);
		GridBagConstraints gbc_btnFinalizar = new GridBagConstraints();
		gbc_btnFinalizar.anchor = GridBagConstraints.NORTHWEST;
		gbc_btnFinalizar.insets = new Insets(0, 0, 0, 5);
		gbc_btnFinalizar.gridx = 3;
		gbc_btnFinalizar.gridy = 0;
		panel_5.add(btnFinalizar, gbc_btnFinalizar);

		JTextPane nombreSenadorL1 = new JTextPane();
		nombreSenadorL1.setText((distrito.getListasAVotar().get(0).getSenador().get(0).getNombre() + "  "
				+ distrito.getListasAVotar().get(0).getSenador().get(0).getApellido() + "\n"
				+ distrito.getListasAVotar().get(0).getSenador().get(1).getNombre() + "  "
				+ distrito.getListasAVotar().get(0).getSenador().get(1).getApellido() + "\n"
				+ distrito.getListasAVotar().get(0).getSenador().get(2).getNombre() + "  "
				+ distrito.getListasAVotar().get(0).getSenador().get(2).getApellido()

		));
		GridBagConstraints gbc_nombreDiputadosL1 = new GridBagConstraints();
		gbc_nombreDiputadosL1.fill = GridBagConstraints.BOTH;
		gbc_nombreDiputadosL1.insets = new Insets(0, 0, 5, 5);
		gbc_nombreDiputadosL1.gridx = 2;
		gbc_nombreDiputadosL1.gridy = 1;
		panel.add(nombreSenadorL1, gbc_nombreDiputadosL1);
		nombreSenadorL1.setEditable(false);

		nombreSenadorL1.setBackground(getBackground());

		JTextPane nombreSenadorL2 = new JTextPane();
		nombreSenadorL2.setText((distrito.getListasAVotar().get(1).getSenador().get(0).getNombre() + "  "
				+ distrito.getListasAVotar().get(1).getSenador().get(0).getApellido() + "\n"
				+ distrito.getListasAVotar().get(1).getSenador().get(1).getNombre() + "  "
				+ distrito.getListasAVotar().get(1).getSenador().get(1).getApellido() + "\n"
				+ distrito.getListasAVotar().get(1).getSenador().get(2).getNombre() + "  "
				+ distrito.getListasAVotar().get(1).getSenador().get(2).getApellido()));

		GridBagConstraints gbc_nombreDiputadosL2 = new GridBagConstraints();
		gbc_nombreDiputadosL2.fill = GridBagConstraints.BOTH;
		gbc_nombreDiputadosL2.insets = new Insets(0, 0, 5, 5);
		gbc_nombreDiputadosL2.gridx = 2;
		gbc_nombreDiputadosL2.gridy = 1;
		panel_1.add(nombreSenadorL2, gbc_nombreDiputadosL2);
		nombreSenadorL2.setEditable(false);
		nombreSenadorL2.setBackground(getBackground());

		JTextPane nombreSenadorL3 = new JTextPane();
		nombreSenadorL3.setText(distrito.getListasAVotar().get(2).getSenador().get(0).getNombre() + "  "
				+ distrito.getListasAVotar().get(2).getSenador().get(0).getApellido() + "\n"
				+ distrito.getListasAVotar().get(2).getSenador().get(1).getNombre() + "  "
				+ distrito.getListasAVotar().get(2).getSenador().get(1).getApellido() + "\n"
				+ distrito.getListasAVotar().get(2).getSenador().get(2).getNombre() + "  "
				+ distrito.getListasAVotar().get(2).getSenador().get(2).getApellido());
		GridBagConstraints gbc_nombreDiputadosL3 = new GridBagConstraints();
		gbc_nombreDiputadosL3.fill = GridBagConstraints.BOTH;
		gbc_nombreDiputadosL3.insets = new Insets(0, 0, 5, 5);
		gbc_nombreDiputadosL3.gridx = 2;
		gbc_nombreDiputadosL3.gridy = 1;
		panel_2.add(nombreSenadorL3, gbc_nombreDiputadosL3);
		nombreSenadorL3.setEditable(false);
		nombreSenadorL3.setBackground(getBackground());

		JTextPane nombreSenadorL4 = new JTextPane();
		nombreSenadorL4.setText(distrito.getListasAVotar().get(3).getSenador().get(0).getNombre() + "  "
				+ distrito.getListasAVotar().get(3).getSenador().get(0).getApellido() + "\n"
				+ distrito.getListasAVotar().get(3).getSenador().get(1).getNombre() + "  "
				+ distrito.getListasAVotar().get(3).getSenador().get(1).getApellido() + "\n"
				+ distrito.getListasAVotar().get(3).getSenador().get(2).getNombre() + "  "
				+ distrito.getListasAVotar().get(3).getSenador().get(2).getApellido());
		GridBagConstraints gbc_nombreDiputadosL4 = new GridBagConstraints();
		gbc_nombreDiputadosL4.fill = GridBagConstraints.BOTH;
		gbc_nombreDiputadosL4.insets = new Insets(0, 0, 5, 5);
		gbc_nombreDiputadosL4.gridx = 2;
		gbc_nombreDiputadosL4.gridy = 1;
		panel_3.add(nombreSenadorL4, gbc_nombreDiputadosL4);
		nombreSenadorL4.setEditable(false);
		nombreSenadorL4.setBackground(getBackground());

		votoListaCompleta1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if (votoListaCompleta1.isSelected()) {
					votoListaCompleta2.setEnabled(false);
					votoListaCompleta3.setEnabled(false);
					votoListaCompleta4.setEnabled(false);
					btnFinalizar.setEnabled(true);
					checkBlanco.setEnabled(false);
				} else {
					checkBlanco.setEnabled(true);
					btnFinalizar.setEnabled(false);
					votoListaCompleta2.setEnabled(true);
					votoListaCompleta3.setEnabled(true);
					votoListaCompleta4.setEnabled(true);
				}
			}
		});

		votoListaCompleta2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if (votoListaCompleta2.isSelected()) {
					votoListaCompleta1.setEnabled(false);
					votoListaCompleta3.setEnabled(false);
					votoListaCompleta4.setEnabled(false);

					btnFinalizar.setEnabled(true);
					checkBlanco.setEnabled(false);
				} else {
					checkBlanco.setEnabled(true);
					btnFinalizar.setEnabled(false);
					votoListaCompleta1.setEnabled(true);
					votoListaCompleta3.setEnabled(true);
					votoListaCompleta4.setEnabled(true);
				}
			}
		});
		votoListaCompleta3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if (votoListaCompleta3.isSelected()) {
					votoListaCompleta2.setEnabled(false);
					votoListaCompleta1.setEnabled(false);
					votoListaCompleta4.setEnabled(false);

					btnFinalizar.setEnabled(true);
					checkBlanco.setEnabled(false);
				} else {
					checkBlanco.setEnabled(true);
					btnFinalizar.setEnabled(false);
					votoListaCompleta2.setEnabled(true);
					votoListaCompleta1.setEnabled(true);
					votoListaCompleta4.setEnabled(true);
				}
			}
		});

		votoListaCompleta4.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if (votoListaCompleta4.isSelected()) {
					votoListaCompleta2.setEnabled(false);
					votoListaCompleta3.setEnabled(false);
					votoListaCompleta1.setEnabled(false);
					btnFinalizar.setEnabled(true);
					checkBlanco.setEnabled(false);
				} else {
					checkBlanco.setEnabled(true);
					btnFinalizar.setEnabled(false);
					votoListaCompleta2.setEnabled(true);
					votoListaCompleta3.setEnabled(true);
					votoListaCompleta1.setEnabled(true);
				}
			}
		});

		checkBlanco.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if (checkBlanco.isSelected()) {
					votoListaCompleta1.setEnabled(false);
					votoListaCompleta2.setEnabled(false);
					votoListaCompleta3.setEnabled(false);
					votoListaCompleta4.setEnabled(false);
					votoListaCompleta1.setSelected(false);
					votoListaCompleta2.setSelected(false);
					votoListaCompleta3.setSelected(false);
					votoListaCompleta4.setSelected(false);
					btnFinalizar.setEnabled(true);
				} else {
					btnFinalizar.setEnabled(false);
					votoListaCompleta1.setEnabled(true);
					votoListaCompleta2.setEnabled(true);
					votoListaCompleta3.setEnabled(true);
					votoListaCompleta4.setEnabled(true);
				}
			}
		});

		btnFinalizar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				String mensajeConfirmacion = JOptionPane
						.showInputDialog("Escribir ** CONFIRMAR **  para continuar, esta acción es definitiva.");

				if (mensajeConfirmacion != null && mensajeConfirmacion.trim().equalsIgnoreCase("confirmar")) {

					// solo corrientes tiene voto a senadores

					/*
					 * la variable codigoVotacion, guardara: 0= voto nulo 100= voto lista 1 200=
					 * voto lista 2 300= voto lista 3 400= voto lista 5
					 * 
					 */
					int codigo = codigovotacion;

					if (votoListaCompleta1.isSelected()) {
						codigo += 1;
					}
					if (votoListaCompleta2.isSelected()) {
						codigo += 2;
					}
					if (votoListaCompleta3.isSelected()) {
						codigo += 3;
					}
					if (votoListaCompleta4.isSelected()) {
						codigo += 4;
					}

					if (codigo == 100 ) {
						elector.getMesa().addVoto(new Voto(CaracteristicaVoto.BLANCO));
					} else {
						elector.getMesa().addVoto(new Voto(CaracteristicaVoto.VALIDO));
					}

					String codigoString = codigo +""+ elector.getMesa().getId();
					Cliente pusher = new Cliente(codigoString.trim());
					dispose();
					VentanaMenu menu = new VentanaMenu(camara);
				}
			}
		});
		setVisible(true);
	}
}