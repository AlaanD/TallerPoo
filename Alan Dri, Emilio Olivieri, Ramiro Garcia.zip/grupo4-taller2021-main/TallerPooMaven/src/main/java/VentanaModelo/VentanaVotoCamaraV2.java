package VentanaModelo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Optional;
import javax.swing.*;

import CapturarYLeerDNI.CapturarImagen;
import CapturarYLeerDNI.LeerDNI;
import Taller.CamaraElectoral;
import Taller.Elector;

import java.awt.Font;

/**
 * @author Alan Dri, Emilio Olivieri, Ramiro Garcia
 *	Crea una interfaz grafica donde el elector ingresa su DNI.
 *	Controla que estee en el padron electoral, si se encuenta procede a la verificacion por foto, 
 * llamando a la clase CapturaImagen, en caso de no estar en el padron lo de vuelve a la VentanaMenu.
 * 
 */

/**
 *Si el elector ya realizo el voto, lo devuelve al VentanaMenu. 
 */
public class VentanaVotoCamaraV2 extends JFrame implements Runnable {

	/**
	 * panel utilizado en el fram
	 */
	private JPanel panelSup;
	/**
	 * herramienta para tomar dimension de la pantalla
	 */
	private Toolkit kitVoto = Toolkit.getDefaultToolkit();
	/**
	 * elemento dimension de la pantalla
	 */
	private Dimension pantallaVoto = kitVoto.getScreenSize();
	/**
	 * elemento tipo int con el alto de la pantalla
	 */
	private int altoPant = pantallaVoto.height;
	/**
	 * elemento int con el ancho de la pantalla
	 */
	private int anchoPant = pantallaVoto.width;
	/**
	 * lista padron tipo camara electoral
	 */
	private CamaraElectoral padron;
    
	/**
	 * @param padron de tipo camara electoral
	 * Se crea la ventana de votacion, en ella se pide al usuario ingresar su DNI y si este se encuentra
	 * en el padron electoral se llama a las clases del paquete CapturarYLeerDNI para
	 * hacer la verificacion correspondiente
	 */
	public VentanaVotoCamaraV2(CamaraElectoral padron) {
		setLayout(null);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Menu Elecciones Primarias 2021");
		setSize(anchoPant/2,altoPant/2);
		setLocationRelativeTo(null);
		setResizable(false);
		this.padron = padron;
	}
	
	@Override
	public void run() {
		componentesSup(padron);
	}

	/**
	 * @param camara lista utilizada para crear el panel del frame
	 */
	private void componentesSup(CamaraElectoral camara) {
		panelSup = new JPanel();
		panelSup.setLayout(null);
		panelSup.setSize(anchoPant/2,altoPant/2);
		panelSup.setLocation(0, 0);
		panelSup.setBackground(Color.RED);
		Font fuente = new Font("Arial", Font.BOLD, 30);

		JLabel etiqueta1 = new JLabel("Ingrese numero de documento");
		etiqueta1.setBounds(150, 20, (anchoPant / 3), 40);
		etiqueta1.setFont(fuente);
		etiqueta1.setOpaque(true);
		etiqueta1.setHorizontalAlignment(SwingConstants.CENTER);
		etiqueta1.setBackground(Color.WHITE);

		JTextField campoTexto = new JTextField();
		campoTexto.setBounds(150, 80, (anchoPant / 3), 40);
		campoTexto.setFont(fuente);

		JButton botonVerif = new JButton("Verificar");
		botonVerif.setBounds(390, 300, 200, 40);
		botonVerif.setFont(fuente);

		ActionListener eventoSup = new ActionListener() {
			int dniIngresado;

			@Override
			public void actionPerformed(ActionEvent e) {
				int respuesta = -1;
				// controlamos que el casillero no este vacio, luego que solo sean numeros y
				// que la longitud no supere el maximo del tipo de dato int
				if (!campoTexto.getText().isEmpty() && campoTexto.getText().matches("[0-9]*")
						&& campoTexto.getText().length() < 10) {

					dniIngresado = Integer.parseInt(campoTexto.getText());
					Optional<Elector> elector = camara.getPadronGeneral().stream()
							.filter(i -> i.getDni() == dniIngresado).findFirst();
					if (!elector.isEmpty()) {
						if (respuesta < 0) {
							respuesta = JOptionPane.showConfirmDialog(null, "Su DNI es: " + elector.get().getDni());
							if (respuesta == 0 && !elector.get().getRealizoVotacion()) {
								dispose();
								
								CapturarImagen captura = new CapturarImagen(new LeerDNI(camara, elector, campoTexto.getText()));
								Thread hilo1 = new Thread(captura);
								
								hilo1.start();
								
								try {
									hilo1.join();
								} catch (InterruptedException e1) {
									e1.printStackTrace();
								}
							} else {
								if(elector.get().getRealizoVotacion()) {
									JOptionPane.showMessageDialog(null, "El elector ya realizo el voto");
									dispose();
									VentanaMenu menu = new VentanaMenu(camara);
								}
								campoTexto.setText("");
							}
						}
					} else {
						JOptionPane.showMessageDialog(null, "DNI no encontrado");
						campoTexto.setText("");
					}
				} else {// en caso de no ingresar nada
					JOptionPane.showMessageDialog(null, "Ingresar DNI por favor");
					campoTexto.setText("");
				}
			}
		};
		botonVerif.addActionListener(eventoSup);
		panelSup.add(botonVerif);
		panelSup.add(etiqueta1);
		panelSup.add(campoTexto);
		add(panelSup);
		setVisible(true);
	}
}